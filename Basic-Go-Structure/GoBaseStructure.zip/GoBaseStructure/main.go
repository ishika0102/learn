package main

import (
	"fmt"

	"fiber-project/routes"

	"github.com/gofiber/fiber/v2"
)

func main() {
	app := fiber.New()

	// Add all the routes here like below :
	// app.Use(middleware.NewJwtMiddleware)
	routes.UserRoutes(app)
	routes.VersionRoutes(app)
	app.Get("/", func(ctx *fiber.Ctx) error {
		return ctx.SendString("Server is running !!")
	})
	host := "0.0.0.0:9000"
	fmt.Printf("Server is running on %s", host)
	err := app.Listen(host)
	if err != nil {
		fmt.Printf("Error starting the server: %v", err)
	}

}
