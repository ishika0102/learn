package test

import (
	"context"
	"fiber-project/configs"
	"fiber-project/models"
	"fiber-project/services"
	"fmt"
	"testing"

	"github.com/bxcodec/faker/v3"
	"github.com/stretchr/testify/assert"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

var collection = configs.MongoConnection.Database("test-GO").Collection("test-data")

func TestInsertInvalidData(t *testing.T) {

	// Test invalid data insertion
	data := "this is a string, not a map"

	_, err := services.InsertIntoDB(collection, data)
	fmt.Println(err)
	assert.Error(t, err, "Expected an error when inserting invalid data")
}

func TestInsertIntoDB(t *testing.T) {

	data := map[string]interface{}{
		"name": "John Doe",
		"age":  30,
	}

	result, err := services.InsertIntoDB(collection, data)
	assert.NoError(t, err)
	assert.NotNil(t, result)

	// Verify insertion
	var insertedData map[string]interface{}
	err = collection.FindOne(context.Background(), data).Decode(&insertedData)
	assert.NoError(t, err)
	fmt.Println(insertedData)
	fmt.Println(assert.Equal(t, data["name"], insertedData["name"]))
	if age, ok := insertedData["age"].(int32); ok {
		fmt.Println(assert.Equal(t, int32(data["age"].(int)), age))
	} else {
		t.Errorf("Expected int32 but got %T", insertedData["age"])
	}
}

// func TestGetUserByUsername(t *testing.T) {
// 	// Insert a user to fetch later
// 	username := faker.Username()
// 	user := bson.M{"UserName": username, "name": faker.Name()}
// 	_, err := collection.InsertOne(context.Background(), user)
// 	assert.NoError(t, err)

// 	// Test fetching the user by username
// 	result, err := services.GetUserByUsername(collection, username)

// 	assert.NoError(t, err)
// 	assert.NotNil(t, result)

// 	// Test fetching a non-existing user
// 	result, err = services.GetUserByUsername(collection, "nonexisting")
// 	assert.Error(t, err)
// 	assert.Nil(t, result)
// }

// func TestGetUserByUserId(t *testing.T) {
// 	// Insert a user to fetch later
// 	userID := primitive.NewObjectID().Hex()
// 	user := bson.M{"_id": userID, "name": "Test User"}
// 	_, err := collection.InsertOne(context.Background(), user)
// 	assert.NoError(t, err)

// 	// Test fetching the user by user ID
// 	result, err := services.GetUserByUserId(collection, userID)
// 	assert.NoError(t, err)
// 	assert.NotNil(t, result)

// 	// Test fetching a non-existing user
// 	result, err = services.GetUserByUserId(collection, "nonexisting")
// 	assert.Error(t, err)
// 	assert.Nil(t, result)
// }

func TestGetAll(t *testing.T) {
	// Insert users to fetch later
	err := collection.Drop(context.Background())
	users := []interface{}{
		bson.M{"name": faker.Name(), "age": faker.SetRandomNumberBoundaries(20, 40)},
		bson.M{"name": faker.Name(), "age": faker.SetRandomNumberBoundaries(20, 40)},
	}
	_, err = collection.InsertMany(context.Background(), users)
	assert.NoError(t, err)

	// Test fetching all users
	filter := bson.M{}
	projection := bson.M{"_id": 0, "name": 1}
	results, err := services.GetAll(filter, projection, collection)
	assert.NoError(t, err)
	assert.Len(t, results, 2)
}

func TestGetOne(t *testing.T) {
	// Insert a user to fetch later
	userID := primitive.NewObjectID().Hex()
	user := bson.M{"_id": userID, "name": faker.Name()}
	_, err := collection.InsertOne(context.Background(), user)
	assert.NoError(t, err)

	// Test fetching the user
	filter := bson.M{"_id": userID}
	projection := bson.M{"name": 1}
	result, err := services.GetOne(filter, projection, collection)
	assert.NoError(t, err)
	assert.Equal(t, user["name"], result["name"])

	// Test fetching a non-existing user
	filter = bson.M{"_id": "nonexisting"}
	result, err = services.GetOne(filter, projection, collection)
	assert.Error(t, err)
	assert.Nil(t, result)
}

func TestUpdateOne(t *testing.T) {
	// Insert a user to update later
	userID := primitive.NewObjectID().Hex()
	user := bson.M{"_id": userID, "name": "Old Name"}
	_, err := collection.InsertOne(context.Background(), user)
	assert.NoError(t, err)

	// Test updating the user
	filter := bson.M{"_id": userID}
	update := bson.M{"$set": bson.M{"name": "New Name"}}
	result, err := services.UpdateOne(filter, update, collection)
	assert.NoError(t, err)
	assert.Equal(t, "New Name", result.(map[string]interface{})["name"])
}

// func TestCheckEmailExists(t *testing.T) {
// 	// Insert a user to check email later
// 	email := faker.Email()
// 	user := bson.M{"basicuserinfo": bson.M{"Email": email}}
// 	_, err := collection.InsertOne(context.Background(), user)
// 	assert.NoError(t, err)

// 	// Test checking if email exists
// 	exists, err := services.CheckEmailExists(email, collection)
// 	assert.NoError(t, err)
// 	assert.True(t, exists)

// 	// Test checking a non-existing email
// 	exists, err = services.CheckEmailExists("nonexisting@example.com", collection)
// 	assert.NoError(t, err)
// 	assert.False(t, exists)
// }

func TestGetKeycloakId_InvalidId(t *testing.T) {
	// Setup a MongoDB client and collection

	// Insert a valid user for control
	validUser := models.User{
		UserInfo: models.UserInfo{
			UserId:         "valid_id",
			KeycloakUserId: "keycloak_valid_id",
		},
	}
	_, err := collection.InsertOne(context.Background(), validUser)
	assert.Nil(t, err)

	// Test with an invalid id
	invalidId := "invalid_id"
	keycloakId, err := services.GetKeycloakId(invalidId, collection)

	assert.Error(t, err)
	assert.Equal(t, "", keycloakId)

	// Cleanup
	err = collection.Drop(context.Background())
	assert.Nil(t, err)
	assert.Nil(t, err)
}

// func TestFindOne(t *testing.T) {
// 	// Insert a user to fetch later
// 	userID := primitive.NewObjectID().Hex()
// 	user := bson.M{"_id": userID, "name": faker.Name()}
// 	_, err := collection.InsertOne(context.Background(), user)
// 	assert.NoError(t, err)

// 	// Test finding the user
// 	filter := bson.M{"_id": userID}
// 	result, err := services.FindOne(filter, collection)
// 	assert.NoError(t, err)
// 	assert.Equal(t, user["name"], result.(bson.M)["name"])

// 	// Test finding a non-existing user
// 	filter = bson.M{"_id": "nonexisting"}
// 	result, err = services.FindOne(filter, collection)
// 	assert.Error(t, err)
// 	assert.Nil(t, result)
// }
