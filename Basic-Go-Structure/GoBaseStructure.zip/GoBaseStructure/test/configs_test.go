package test

import (
	"context"
	"fiber-project/configs"
	"fiber-project/models"
	"fmt"
	"os"
	"testing"

	"github.com/bxcodec/faker/v3"
	"github.com/gofiber/fiber/v2"
	"github.com/stretchr/testify/assert"
	"github.com/valyala/fasthttp"
	"go.mongodb.org/mongo-driver/bson"
)

func TestAddAuditLog(t *testing.T) {
	user := map[string]string{
		"user_id":  faker.UUIDDigit(),
		"username": faker.Username(),
	}
	fmt.Println(user)
	refId := faker.UUIDDigit()
	data := map[string]interface{}{
		"field1": faker.Word(),
		"field2": faker.Word(),
	}
	fmt.Println(refId, data)
	configs.AddAuditLog(user, refId, data, configs.AuditCollection, "CREATE", "TestRecord")

	var result models.BaseAuditLog
	err := configs.AuditCollection.FindOne(context.Background(), bson.M{"ref_id": refId}).Decode(&result)
	fmt.Println(result)

	fmt.Println(assert.NoError(t, err))
	fmt.Println(assert.Equal(t, "CREATE", result.EventType))
	fmt.Println(assert.Equal(t, refId, result.RefId))
	fmt.Println(assert.Equal(t, data, result.Data))
	fmt.Println(assert.Equal(t, user["username"], result.AuditLogInfo.CreatedBy))

}

func TestDefineLogger(t *testing.T) {
	user := map[string]string{
		"user_id": faker.UUIDDigit(),
	}

	// Create a new Fiber instance
	app := fiber.New()

	// Create a new fasthttp.RequestCtx
	reqCtx := &fasthttp.RequestCtx{}
	reqCtx.Request.Header.SetMethod(fiber.MethodGet)
	reqCtx.URI().SetPath("/test-url")

	// Acquire Fiber context
	c := app.AcquireCtx(reqCtx)
	fmt.Println(c.String())

	body := map[string]interface{}{
		"key1": "value1",
		"key2": "value2",
	}

	configs.DefineLogger(20, user, c, "test.log", 12345, "Test message", body)

	// Check log file contents
	logContents, err := os.ReadFile("logger/backend.log")
	fmt.Println(string(logContents))
	fmt.Println(assert.NoError(t, err))
	fmt.Println(assert.Contains(t, string(logContents), "INFO: - USER: "+user["user_id"]))
	fmt.Println(assert.Contains(t, string(logContents), "- IP: 0.0.0.0 - URL: GET"))
	fmt.Println(assert.Contains(t, string(logContents), "- MESSAGE: Test message"))
	fmt.Println(assert.Contains(t, string(logContents), "- PID: 12345"))
	fmt.Println(assert.Contains(t, string(logContents), "- BODY: map[key1:value1 key2:value2]"))
}

// func TestCreateModuleCollection(t *testing.T) {
// 	// Initialize the configs package
// 	configs.InitViper()
// 	configs.MongoConnection = configs.NewDbConnection()
// 	configs.ModulesCollection = configs.GetCollection(configs.MODULES_COLLECTION)

// 	// Call the function to create the module collection
// 	configs.CreateModuleCollection()

// 	// Verify that the module collection was created or updated
// 	var result map[string]interface{}
// 	err := configs.ModulesCollection.FindOne(context.Background(), bson.M{"Category": "Modules"}).Decode(&result)
// 	assert.NoError(t, err)
// 	assert.Equal(t, "Modules", result["Category"])
// 	assert.NotNil(t, result["Modules"])
// }

func TestCreateRootUser(t *testing.T) {

	// Call the function to create the root user
	configs.CreateRootUser()

	// Verify that the root user was created
	var result models.Root
	err := configs.UserCollection.FindOne(context.Background(), bson.M{"_id": "ROOT"}).Decode(&result)
	fmt.Println(result)
	assert.NoError(t, err)
	assert.Equal(t, configs.RootUserId, result.UserId)
	assert.Equal(t, configs.RootUserName, result.Username)
	assert.Equal(t, configs.RootEmail, result.BasicUserInfo.Email)
}

func TestResponse(t *testing.T) {

	tests := []struct {
		name       string
		statusCode int
		data       interface{}
		errorCode  int
		expected   models.Response
	}{
		{
			name:       "Success response with single item slice",
			statusCode: 200,
			data:       []interface{}{"single item"},
			errorCode:  0,
			expected: models.Response{
				Status:  200,
				Message: "OK",
				Data:    "single item",
			},
		},
		{
			name:       "Success response with empty slice",
			statusCode: 200,
			data:       []interface{}{},
			errorCode:  0,
			expected: models.Response{
				Status:  200,
				Message: "OK",
				Data:    []interface{}{},
			},
		},
		{
			name:       "Success response with multiple items slice",
			statusCode: 200,
			data:       []interface{}{"item1", "item2"},
			errorCode:  0,
			expected: models.Response{
				Status:  200,
				Message: "OK",
				Data:    []interface{}{"item1", "item2"},
			},
		},
		{
			name:       "Success response with non-slice data",
			statusCode: 200,
			data:       "single item",
			errorCode:  0,
			expected: models.Response{
				Status:  200,
				Message: "OK",
				Data:    "single item",
			},
		},
		{
			name:       "Error response",
			statusCode: 400,
			data:       nil,
			errorCode:  1000,
			expected: models.Response{
				Status:  400,
				Message: "Bad Request",
				Error: &models.ErrorDetail{
					ErrorCode: 1000,
					Message:   "An unknown error occurred",
				},
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			response := configs.Response(tt.statusCode, tt.data, tt.errorCode)
			assert.Equal(t, tt.expected, response)
		})
	}
}
