package test

import (
	"fiber-project/helpers"
	"fmt"
	"math/rand"
	"strconv"
	"strings"
	"testing"
	"time"
)

func TestGetCurrentEpochTimeInFormat(t *testing.T) {
	// Test for seconds
	epochTimeInSeconds := helpers.GetCurrentEpochTimeInFormat(false)
	epochIntSeconds, err := strconv.ParseInt(epochTimeInSeconds, 10, 64)
	if err != nil {
		t.Fatalf("Expected a valid integer, got error: %v", err)
	}

	// Allow a tolerance for the time difference
	expectedTimeSeconds := time.Now().UTC().Unix()
	if !(expectedTimeSeconds-1 <= epochIntSeconds && epochIntSeconds <= expectedTimeSeconds+1) {
		t.Errorf("Expected time within %d +/- 1 second, got %d", expectedTimeSeconds, epochIntSeconds)
	}

	// Test for microseconds
	epochTimeInMicroseconds := helpers.GetCurrentEpochTimeInFormat(true)
	epochIntMicroseconds, err := strconv.ParseInt(epochTimeInMicroseconds, 10, 64)
	if err != nil {
		t.Fatalf("Expected a valid integer, got error: %v", err)
	}

	// Allow a tolerance for the time difference
	expectedTimeMicroseconds := time.Now().UTC().UnixMicro()
	if !(expectedTimeMicroseconds-1000000 <= epochIntMicroseconds && epochIntMicroseconds <= expectedTimeMicroseconds+1000000) {
		t.Errorf("Expected time within %d +/- 1000000 microseconds, got %d", expectedTimeMicroseconds, epochIntMicroseconds)
	}
}
func TestGenerateUserID(t *testing.T) {
	prefix := "user"
	userID := helpers.GenerateUserID(prefix)

	if !strings.HasPrefix(userID, prefix+"_") {
		t.Errorf("Expected prefix %s, got %s", prefix, userID)
	}

	// Extract the timestamp part and verify it's a valid UnixMicro timestamp
	timePart := strings.TrimPrefix(userID, prefix+"_")
	_, err := strconv.ParseInt(timePart, 10, 64)
	if err != nil {
		t.Errorf("Expected a valid timestamp, got error: %v", err)
	}
}

func TestGenerateID(t *testing.T) {
	prefix := "order"
	orderID := helpers.GenerateID(prefix)

	if !strings.HasPrefix(orderID, prefix+"_") {
		t.Errorf("Expected prefix %s, got %s", prefix, orderID)
	}

	// Extract the random ID part and verify it's a valid 6-digit number
	randomPart := strings.TrimPrefix(orderID, prefix+"_")
	if len(randomPart) != 6 {
		t.Errorf("Expected 6 digits, got %s", randomPart)
	}
	for _, ch := range randomPart {
		if ch < '0' || ch > '9' {
			t.Errorf("Expected a digit, got %c", ch)
		}
	}
}

func TestGenerateRandomPassword(t *testing.T) {
	rand.Seed(time.Now().UnixNano())

	length := 12
	password := helpers.GenerateRandomPassword(length)
	fmt.Println(password)

	// Check if the length of the generated password is correct
	if len(password) != length {
		t.Errorf("Expected password length %d, got %d", length, len(password))
	}

}
