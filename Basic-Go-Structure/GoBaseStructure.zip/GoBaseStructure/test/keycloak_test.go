package test

import (
	"context"
	"fiber-project/configs"
	"fiber-project/middleware"
	"fiber-project/models"
	"testing"

	"github.com/bxcodec/faker/v3"
)

func TestLoginRestApiClient(t *testing.T) {

	// Call the function
	_, err := configs.LoginRestApiClient(context.Background())

	// Check for errors
	if err != nil {
		t.Errorf("loginRestApiClient failed: %v", err)
	}
}

func TestRegister(t *testing.T) {

	// Create a test user
	testUser := models.User{
		UserInfo: models.UserInfo{
			UserId:     "test-user-id",
			Username:   faker.Name(),
			UserRole:   "admin",
			UserStatus: "active",
			Password:   "test-password",
		},
		BasicUserInfo: models.BasicUserInfo{
			FirstName:    "John",
			LastName:     "Doe",
			Email:        faker.Email(),
			CountryCode:  "+91",
			PhoneNumber:  faker.Phonenumber(),
			MobileNumber: faker.Phonenumber(),
		},
	}

	// Call the function
	keycloakUserId, err := middleware.Register(testUser)

	// Check for errors and validate the result
	if err != nil {
		t.Errorf("Register failed: %v", err)
	} else if keycloakUserId == "" {
		t.Error("Register returned an empty Keycloak user ID")
	}
}

// func TestUpdateKeycloakUser(t *testing.T) {

// 	// Create a test user ID
// 	testUserID := "test-user-id"

// 	// Create test attributes
// 	newAttributes := map[string]interface{}{
// 		"Email":         "updated@example.com",
// 		"ContactNumber": "9876543210",
// 	}

// 	// Call the function
// 	err := middleware.UpdateKeycloakUser(testUserID, newAttributes)

// 	// Check for errors
// 	if err != nil {
// 		t.Errorf("UpdateKeycloakUser failed: %v", err)
// 	}
// }

// func TestDisableKeycloakUser(t *testing.T) {

// 	// Create a test user ID
// 	testUserID := "test-user-id"

// 	// Call the function
// 	err := middleware.DisableKeycloakUser(testUserID)

// 	// Check for errors
// 	if err != nil {
// 		t.Errorf("DisableKeycloakUser failed: %v", err)
// 	}
// }

// func TestDeleteKeycloakUser(t *testing.T) {

// 	// Create a test user ID
// 	testUserID := "test-user-id"

// 	// Call the function
// 	err := middleware.DeleteKeycloakUser(testUserID)

// 	// Check for errors
// 	if err != nil {
// 		t.Errorf("DeleteKeycloakUser failed: %v", err)
// 	}
// }

// func TestGetPublicKey(t *testing.T) {

// 	// Call the function
// 	publicKey, err := middleware.GetPublicKey("test-realm", "test-client", "admin", "admin-password")

// 	// Check for errors and validate the result
// 	if err != nil {
// 		t.Errorf("GetPublicKey failed: %v", err)
// 	} else if publicKey == nil || *publicKey == "" {
// 		t.Error("GetPublicKey returned an empty public key")
// 	}
// }

func TestGenerateRandomCode(t *testing.T) {
	// Call the function
	code := middleware.GenerateRandomCode()

	// Validate the result
	if len(code) != 6 {
		t.Errorf("GenerateRandomCode returned an invalid code length: %d", len(code))
	}
}
