package test

import (
	"bytes"
	"context"
	"encoding/json"
	"fiber-project/configs"
	"fiber-project/controller"
	"fiber-project/models"
	"math/rand"

	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/bxcodec/faker/v3"
	"github.com/gofiber/fiber/v2"
	"github.com/stretchr/testify/assert"
)

var createdUser models.User

func insertTestUser(user models.User) {
	configs.UserCollection.InsertOne(context.Background(), user)
}

func TestCreateUser(t *testing.T) {
	app := fiber.New()

	// Register the CreateUser route
	app.Post("/api/v1/users", controller.CreateUser)

	tests := []struct {
		name           string
		input          models.User
		expectedStatus int
		expectedBody   map[string]interface{}
		setup          func()
	}{
		{
			name: "Successful Creation",
			input: models.User{
				UserInfo: models.UserInfo{
					Username:   faker.Username(),
					Password:   "testpassword",
					UserRole:   "admin",
					UserStatus: "active",
				},
				BasicUserInfo: models.BasicUserInfo{
					FirstName:    faker.FirstName(),
					LastName:     faker.LastName(),
					Email:        faker.Email(),
					CountryCode:  "+91",
					PhoneNumber:  faker.Phonenumber(),
					MobileNumber: faker.Phonenumber(),
				},
			},
			expectedStatus: fiber.StatusCreated,
			expectedBody: map[string]interface{}{
				"status":  float64(201),
				"message": "Created",
			},
			setup: func() {},
		},
		{
			name: "Validation Failure",
			input: models.User{
				UserInfo: models.UserInfo{
					Username:   "invaliduser",
					Password:   "testpassword",
					UserRole:   "admin",
					UserStatus: "active",
				},
				BasicUserInfo: models.BasicUserInfo{
					FirstName:    "John",
					LastName:     "Doe",
					Email:        "invalid-email",
					CountryCode:  "+1",
					PhoneNumber:  "1234567890",
					MobileNumber: "0987654321",
				},
			},
			expectedStatus: fiber.StatusBadRequest,
			expectedBody: map[string]interface{}{
				"status":  float64(400),
				"message": "Bad Request",
			},
			setup: func() {},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tt.setup()

			body, _ := json.Marshal(tt.input)
			createURL := "/api/v1/users"
			req := httptest.NewRequest(http.MethodPost, createURL, bytes.NewReader(body))
			req.Header.Set("Content-Type", "application/json")
			resp, err := app.Test(req)
			assert.Nil(t, err, "Error creating HTTP request")

			var responseBody map[string]interface{}
			json.NewDecoder(resp.Body).Decode(&responseBody)

			assert.Equal(t, tt.expectedStatus, resp.StatusCode)
			for key, value := range tt.expectedBody {
				assert.Equal(t, value, responseBody[key])
			}

			if tt.name == "Successful Creation" {
				if data, ok := responseBody["data"].(map[string]interface{}); ok {
					if userID, ok := data["UserId"].(string); ok {
						tt.input.UserInfo.UserId = userID
						createdUser = tt.input
						t.Logf("UserId: %v", userID)
					} else {
						t.Errorf("UserId not found in response data")
					}
				} else {
					t.Errorf("Data not found in response body")
				}
			}
		})
	}
}

func TestView(t *testing.T) {
	app := fiber.New()

	// Register the View route
	app.Get("/api/v1/users/:id", controller.View)
	// Test cases
	tests := []struct {
		name           string
		userId         string
		expectedStatus int
		expectedBody   map[string]interface{}
	}{
		{
			name:           "User Found",
			userId:         createdUser.UserInfo.UserId,
			expectedStatus: fiber.StatusOK,
			expectedBody: map[string]interface{}{
				"status":  float64(200),
				"message": "OK",
				"data": map[string]interface{}{
					"UserId":        createdUser.UserInfo.UserId,
					"UserName":      createdUser.UserInfo.Username,
					"FirstName":     createdUser.BasicUserInfo.FirstName,
					"LastName":      createdUser.BasicUserInfo.LastName,
					"Email":         createdUser.BasicUserInfo.Email,
					"CountryCode":   createdUser.BasicUserInfo.CountryCode,
					"ContactNumber": createdUser.BasicUserInfo.PhoneNumber,
				},
			},
		},
		{
			name:           "User Not Found",
			userId:         "nonexistentuser",
			expectedStatus: fiber.StatusBadRequest,
			expectedBody: map[string]interface{}{
				"status":  float64(400),
				"message": "Bad Request",
				"error": map[string]interface{}{
					"error_code": float64(3002),
					"message":    "Record not found",
				},
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			viewByIDURL := fmt.Sprintf("/api/v1/users/%s", tt.userId)
			req := httptest.NewRequest(http.MethodGet, viewByIDURL, nil)
			resp, err := app.Test(req)
			assert.Nil(t, err)

			var responseBody map[string]interface{}
			json.NewDecoder(resp.Body).Decode(&responseBody)

			assert.Equal(t, tt.expectedStatus, resp.StatusCode)
			for key, value := range tt.expectedBody {
				assert.Equal(t, value, responseBody[key])
			}
		})
	}
}

func TestViewAllUsers(t *testing.T) {
	app := fiber.New()

	// Register the ViewAllUsers route
	app.Get("/api/v1/users", controller.ViewAllUsers)

	req := httptest.NewRequest(http.MethodGet, "/api/v1/users", nil)
	resp, err := app.Test(req)
	assert.Nil(t, err)
	assert.Equal(t, fiber.StatusOK, resp.StatusCode)

	var responseBody map[string]interface{}
	json.NewDecoder(resp.Body).Decode(&responseBody)
	assert.Equal(t, float64(200), responseBody["status"])

	data, ok := responseBody["data"].([]interface{})
	assert.True(t, ok)
	assert.NotEmpty(t, data)

	t.Logf("Number of users retrieved: %d", len(data))
}

func TestUpdateUser(t *testing.T) {
	app := fiber.New()

	// Register the routes
	app.Get("/api/v1/users", controller.ViewAllUsers)
	app.Put("/api/v1/users", controller.UpdateUser)

	// Retrieve all users
	req := httptest.NewRequest(http.MethodGet, "/api/v1/users", nil)
	resp, err := app.Test(req)
	assert.Nil(t, err)
	assert.Equal(t, fiber.StatusOK, resp.StatusCode)

	var responseBody map[string]interface{}
	json.NewDecoder(resp.Body).Decode(&responseBody)
	assert.Equal(t, float64(200), responseBody["status"])

	data, ok := responseBody["data"].([]interface{})
	assert.True(t, ok)
	assert.NotEmpty(t, data)

	// Randomly select a user to update
	userIndex := rand.Intn(len(data))
	user := data[userIndex].(map[string]interface{})
	userId, ok := user["UserId"].(string)
	fmt.Println(userId)
	assert.True(t, ok)

	// Create an updated user model
	updatedUser := models.User{
		UserInfo: models.UserInfo{
			UserId:     userId,
			Username:   faker.Name(),
			UserRole:   "DA",
			UserStatus: "active",
		},
		BasicUserInfo: models.BasicUserInfo{
			FirstName:    faker.FirstName(),
			LastName:     faker.LastName(),
			Email:        faker.Email(),
			CountryCode:  "+91",
			PhoneNumber:  faker.Phonenumber(),
			MobileNumber: faker.Phonenumber(),
		},
	}
	fmt.Println(updatedUser.BasicUserInfo.Email)
	body, _ := json.Marshal(updatedUser)
	fmt.Println(string(body))
	updateReq := httptest.NewRequest(http.MethodPut, "/api/v1/users", bytes.NewBuffer(body))
	updateReq.Header.Set("Content-Type", "application/json")

	updateResp, err := app.Test(updateReq)
	assert.Nil(t, err)
	assert.Equal(t, fiber.StatusOK, updateResp.StatusCode)

	var updateResponseBody map[string]interface{}
	json.NewDecoder(updateResp.Body).Decode(&updateResponseBody)
	assert.Equal(t, float64(200), updateResponseBody["status"])

	updatedData := updateResponseBody["data"].(map[string]interface{})
	fmt.Println(updatedData["basicuserinfo"].(map[string]interface{})["email"])
	assert.Equal(t, updatedUser.BasicUserInfo.FirstName, updatedData["basicuserinfo"].(map[string]interface{})["first_name"])
	assert.Equal(t, updatedUser.BasicUserInfo.LastName, updatedData["basicuserinfo"].(map[string]interface{})["last_name"])
	assert.Equal(t, updatedUser.BasicUserInfo.Email, updatedData["basicuserinfo"].(map[string]interface{})["email"])
	assert.Equal(t, updatedUser.BasicUserInfo.CountryCode, updatedData["basicuserinfo"].(map[string]interface{})["country_code"])
	assert.Equal(t, updatedUser.BasicUserInfo.PhoneNumber, updatedData["basicuserinfo"].(map[string]interface{})["phone_number"])
}

func TestUpdateStatus(t *testing.T) {
	app := fiber.New()

	// Register the routes
	app.Get("/api/v1/users", controller.ViewAllUsers)
	app.Put("/api/v1/users/:id/:status", controller.UpdateStatus)

	// Retrieve all users
	req := httptest.NewRequest(http.MethodGet, "/api/v1/users", nil)
	resp, err := app.Test(req)
	assert.Nil(t, err)
	assert.Equal(t, fiber.StatusOK, resp.StatusCode)

	var responseBody map[string]interface{}
	json.NewDecoder(resp.Body).Decode(&responseBody)
	assert.Equal(t, float64(200), responseBody["status"])

	data, ok := responseBody["data"].([]interface{})
	assert.True(t, ok)
	assert.NotEmpty(t, data)

	// Randomly select a user to update
	userIndex := rand.Intn(len(data))
	user := data[userIndex].(map[string]interface{})
	userId, ok := user["UserId"].(string)
	fmt.Println(userId)
	assert.True(t, ok)
	// Update the user status to "enable"
	updateURL := fmt.Sprintf("/api/v1/users/%s/enable", userId)
	fmt.Println(updateURL)
	reqEnable := httptest.NewRequest(http.MethodPut, updateURL, nil)
	respEnable, err := app.Test(reqEnable)
	assert.Nil(t, err)
	assert.Equal(t, fiber.StatusOK, respEnable.StatusCode)

	var enableResponseBody map[string]interface{}
	assert.Equal(t, fiber.StatusOK, resp.StatusCode)
	json.NewDecoder(respEnable.Body).Decode(&enableResponseBody)
	fmt.Println(enableResponseBody)
	assert.Equal(t, float64(200), responseBody["status"])
	enableData := enableResponseBody["data"].(map[string]interface{})
	assert.Equal(t, "enable", enableData["user_status"])

	// Update the user status to "disable"
	reqDisable := httptest.NewRequest(http.MethodPut, fmt.Sprintf("/api/v1/users/%s/disable", userId), nil)
	respDisable, err := app.Test(reqDisable)
	assert.Nil(t, err)
	assert.Equal(t, fiber.StatusOK, respDisable.StatusCode)

	var disableResponseBody map[string]interface{}
	json.NewDecoder(respDisable.Body).Decode(&disableResponseBody)
	assert.Equal(t, float64(200), disableResponseBody["status"])
	disableData := disableResponseBody["data"].(map[string]interface{})
	assert.Equal(t, "disable", disableData["user_status"])

	// Update the user status to "delete"
	reqDelete := httptest.NewRequest(http.MethodPut, fmt.Sprintf("/api/v1/users/%s/delete", userId), nil)
	resqDelete, err := app.Test(reqDelete)
	assert.Nil(t, err)
	assert.Equal(t, fiber.StatusOK, resqDelete.StatusCode)

	var deleteResponseBody map[string]interface{}
	json.NewDecoder(resqDelete.Body).Decode(&deleteResponseBody)
	assert.Equal(t, float64(200), deleteResponseBody["status"])
	deleteData := deleteResponseBody["data"].(map[string]interface{})
	assert.Equal(t, "delete", deleteData["user_status"])
}
