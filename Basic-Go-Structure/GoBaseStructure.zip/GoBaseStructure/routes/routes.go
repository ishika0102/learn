package routes

import (
	"fiber-project/controller"

	"github.com/gofiber/fiber/v2"
)

func UserRoutes(app *fiber.App) {
	v1 := app.Group("/api/v1/users")
	v1.Get("/", controller.ViewAllUsers)
	v1.Get("/:id", controller.View)
	v1.Post("/", controller.CreateUser)
	v1.Put("/", controller.UpdateUser)
	v1.Put("/:id/:status", controller.UpdateStatus)
}

func VersionRoutes(app *fiber.App) {
	v := app.Group("/version")
	v.Get("/appinfo", controller.GetLatestAppInfo)
	v.Get("/allappinfo", controller.GetAllAppInfo)
}
