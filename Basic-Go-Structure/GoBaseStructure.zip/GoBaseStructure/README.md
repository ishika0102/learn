# GoBaseStructure

**Starter project for Go APIs utilizing MongoDB &amp; Keycloak**

[![Badge](https://img.shields.io/badge/Version-1.0.0-blue.svg)](https://github.com/ProbePlusDevTeam/Dev_Docker/tree/main)

## Setup of MongoDB and Keycloak

Before starting the docker containers, make sure that `mongodb` service is disabled or purge mongodb from your local system:

**PS : Make sure you have a backup of your data if it's important before proceeding with the removal.**

```bash
# To disable mongodb service
sudo systemctl disable mongod
sudo systemctl status mongod

# OR

# To purge mongodb
sudo systemctl stop mongod
sudo apt-get purge mongodb-org*
sudo rm -r /var/log/mongodb /var/lib/mongodb
```

Run the following command to check if any service is still running in port 27017 that is used by mongodb, if yes, either stop the service or expose a port in docker that is not utilized by any services.

```bash
sudo ss -tuln | grep 27017
```

**Go to the [Mongo-Express_Docker](Mongo-Express_Docker) directory and then the [Keycloak_Docker](Keycloak_Docker) directory:**

* **Start the docker compose:**

    ```bash
    docker compose up -d
    ```

* **If you wish to stop the docker compose:**

    ```bash
    docker compose down
    ```

## Create and Import New Realm

1. Go to [Keycloak Console](http://localhost:3000/)
1. Select `Administration Console`
1. Login using the credentials you gave in Keycloak's [docker-compose.yml](Keycloak_Docker/docker-compose.yml) file
1. In the top-left corner you may see a dropdown with the name `master`. Click on it.
1. Select `Create Realm`
1. Click on `Browse...`
1. Select the Resource file, i.e., [realm-export.json](Keycloak_Docker/realm/realm-export.json)
1. Enter a `Realm name` for your project.
1. Click on `Create`
1. Select `Realm settings`
1. Select `Login` Tab.
1. Under `Email settings`, enable `Login with email`.
1. Select `Themes` Tab.
1. In `Login theme`, select `login-theme`.
1. In `Account theme`, select `keycloak`.
1. In `Admin UI theme`, select `base`.
1. In `Email theme`, select `keycloak`.
1. Click on `Save`

## Download Go

### Download Go from official website and add go extension in VS code (NOTE : install go 1.19 or later)

* **Remove existing Go installations:**

    ```bash
    sudo apt-get purge golang-go
    sudo apt-get autoremove
    ```

* **Download go1.19 or higher version(initially made using Go version go1.22.0 linux/amd64) and open terminal.**

    ```bash
    wget https://go.dev/dl/go1.22.0.linux-amd64.tar.gz
    ```

## Setup the .env File

* **Copy the [sample.env](sample.env) file and create a `.env` file**
* **In the `.env` file:**

    ```properties
    MONGO_URL=mongodb://user:password@localhost:27017/
    # Get the `user` and `password` from
    # `Mongo-Express_Docker/docker-compose.yml`
    # and if the port is different in `docker-compose.yml`
    # then use it instead of `27017`
    DB_NAME=loren_ipsum
    # Use the name of the DB used by your project

    KeyCloakBaseUrl=http://localhost:3000
    # URL of the Keycloak server
    KeyCloakRealm=realm_name
    # Name of the realm that your application will interact with
    KeyCloakRestApiClientId=backend
    # Client identifier for the backend application registered with Keycloak
    KeyCloakRestApiClientSecret=Z1pXXXXXXXXXXXXXXXXXXX
    # Client secret associated with the backend application.
    # Used to authenticate the client application to the Keycloak server
    KeyCloakRealmRS256PublicKey=MIIBXXXXXXXXXXXXXXXXXX
    # This sets the RSA public key for the Keycloak realm,
    # used to verify JWT tokens signed by Keycloak.

    # To get the Client secret(KeyCloakRestApiClientSecret):
    # 1. Go to http://localhost:3000
    # 2. Select `Administration Console`
    # 3. Login using the credentials you gave in Keycloak's docker-compose.yml file
    # 4. In the top-left corner you may see a dropdown with the name `master`. Click on it.
    # 5. Select your realm
    # 6. Click on `Clients`
    # 7. Click on `backend`
    # 8. Select the `Credentials` tab
    # 9. In the `Client secret` column, click on `Regenerate`.
    # 10. Copy the generated `Client secret` and paste it here.
    ```

## Installation and Execution

* **Go to the directory where Go is downloaded, run the following command**

    ```bash
    sudo tar -C /usr/local -xzf go1.22.0.linux-amd64.tar.gz
    ```

* **Set Go environment variables:**

    ```bash
    export PATH=$PATH:/usr/local/go/bin
    export GOPATH=$HOME/go
    export PATH=$PATH:$GOPATH/bin
    ```

* **Verify installation:**

    ```bash
    go version
    ```

* **Initialize Go module**

    ```bash
    go mod init <project-name> # This sets up 'go.mod' that Go uses to manage dependencies.
    go mod tidy # Make sure that 'go.mod' and 'go.sum' reflect the actual dependencies used in the project
    ```

* **Install the required dependencies using the following command:**

    ```bash
    go get -u \
        github.com/gofiber/fiber/v2 \
        go.mongodb.org/mongo-driver/mongo \
        github.com/joho/godotenv \
        github.com/go-playground/validator/v10
    ```

  Here:
  * `github.com/gofiber/fiber/v2` is a framework for building web applications.
  * `go.mongodb.org/mongo-driver/mongo` is a driver for connecting to MongoDB.
  * `github.com/joho/godotenv` is a library for managing environment variables.
  * `github.com/go-playground/validator/v10` is a library for validating structs and fields.

## Staticcheck and Gotest

Staticcheck is designed to help developers catch bugs and improve the quality of their Go code

* **To use Staticcheck, you can install it via the following command:**

    ```bash
    go install honnef.co/go/tools/cmd/staticcheck@2022.1
    ```

* **Then, you can run it on your codebase with:**

    ```bash
    staticcheck ./...
    ```

## Contributors

* **Authors**
  * [Shashank C](https://github.com/Shashankc-probeplus)
  * [Ishika Dubey](https://github.com/ishika-probeplus)
  * [Ciril Biju](https://github.com/ciril-pro)

* **Lead Developers**
  * [Manohar Bangera](https://github.com/mano-pp)
  * [Deepak Baskar](https://github.com/deepak-probe)
