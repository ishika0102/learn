package services

import (
	"context"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

func GetKeycloakId(id string, collection *mongo.Collection) (string, error) {
	var result struct {
		KeycloakUserId string `bson:"keycloak_user_id"`
	}

	filter := bson.M{"_id": id}
	projection := bson.M{"keycloak_user_id": 1}
	options := options.FindOne().SetProjection(projection)

	err := collection.FindOne(context.Background(), filter, options).Decode(&result)
	if err != nil {
		return "", err
	}

	return result.KeycloakUserId, nil
}
