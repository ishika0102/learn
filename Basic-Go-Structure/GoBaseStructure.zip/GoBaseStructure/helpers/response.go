package helpers

// func ErrorResponse(status int, message string) (response models.ErrorResponse) {
// 	result := models.ErrorResponse{Status: status, Message: message}
// 	return result
// }
