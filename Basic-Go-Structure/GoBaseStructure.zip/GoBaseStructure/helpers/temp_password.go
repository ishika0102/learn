package helpers

import (
	"math/rand"
	"time"
)

// Function to generate a random temporary password of a specified length
func GenerateRandomPassword(length int) string {
	rand.Seed(time.Now().UnixNano())

	var letters = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()")

	tempPassword := make([]rune, length)
	for i := range tempPassword {
		tempPassword[i] = letters[rand.Intn(len(letters))]
	}
	return string(tempPassword)
}
