package models

type AuditDetails struct {
	CreatedByUserId    string `json:"CreatedByUserId,omitempty" bson:"created_by_user_id"`
	CreatedByUsername  string `json:"CreatedByUserName,omitempty" bson:"created_by_username"`
	CreatedOn          string `json:"CreatedOn,omitempty" bson:"created_on"`
	ModifiedByUserId   string `json:"ModifiedByUserId,omitempty" bson:"modified_by_user_id,omitempty"`
	ModifiedByUsername string `json:"ModifiedByUsername,omitempty" bson:"modified_by_username,omitempty"`
	ModifiedOn         string `json:"ModifiedOn,omitempty" bson:"modified_on,omitempty"`
}

type BasicUserInfo struct {
	FirstName    string `json:"FirstName" bson:"first_name" validate:"required"`
	LastName     string `json:"LastName" bson:"last_name" validate:"required"`
	Email        string `json:"Email" bson:"email" validate:"required,email"`
	CountryCode  string `json:"CountryCode" bson:"country_code" validate:"required"`
	PhoneNumber  string `json:"PhoneNumber" bson:"phone_number" validate:"required"`
	MobileNumber string `json:"MobileNumber" bson:"mobile_number" validate:"required"`
}

type UserInfo struct {
	UserId         string `json:"UserId" bson:"_id"`
	Username       string `json:"Username" bson:"username"`
	Password       string `json:"Password" bson:"password"`
	UserRole       string `json:"UserRole" bson:"user_role"`
	KeycloakUserId string `json:"KeycloakUserId" bson:"keycloak_user_id"`
	UserStatus     string `json:"UserStatus" bson:"user_status"`
}
