package models

type Response struct {
	Status  int          `json:"status"`
	Message string       `json:"message"`
	Data    interface{}  `json:"data,omitempty"`
	Error   *ErrorDetail `json:"error,omitempty"`
}

type ErrorDetail struct {
	ErrorCode int    `json:"error_code"`
	Message   string `json:"message"`
}
