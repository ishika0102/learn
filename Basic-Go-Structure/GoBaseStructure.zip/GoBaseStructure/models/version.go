package models

type AppInfo struct {
	Version     string `json:"Version"`
	ReleaseDate string `json:"ReleaseDate"`
}
