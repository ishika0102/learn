package models

type Root struct {
	UserInfo `bson:",inline"`
	BasicUserInfo
	AuditDetails
}

type User struct {
	UserInfo `bson:",inline"`
	BasicUserInfo
	AuditDetails
}
