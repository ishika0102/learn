# README.md Guide

[![Badge](https://img.shields.io/badge/Version-1.0.0-blue.svg)](https://github.com/ProbePlusDevTeam/Dev_Docker/tree/main)

*****

## Headings
  To create a heading, add one to six `#` symbols before your heading text. The number of `#` you use will determine the hierarchy level and typeface size of the heading.

```markdown
# A first-level heading
## A second-level heading
### A third-level heading
```

*****

## Styling text

1. Bold : `**`text`**` or `__`text`__`
1. Italic : `*`text`*` or `_`text`_`
1. Strikethrough : `~~`text`~~`
1. Subscript : `<sub>`text`</sub>`
1. Subscript : `<sup>`text`</sup>`

*****

## Quoting text

You can quote text with a `>`. For example:
> Text that is a quote

*****

## Quoting code

You can quote code with  **\` \`**. For example:

* \`ls -al\` : `ls -al`

## Supported color models

Here are the currently supported color models:

| Color  | Syntax | Example | Output |
| ------------- | ------------- | ------------- | ------------- |
| HEX  | \`#RRGGBB\`  | \`#0969DA\`  | `#0969DA`  |
| RGB  | \`rgb(R,G,B)\`  | \`rgb(9, 105, 218)\`  | `rgb(9, 105, 218)`  |
| HSL  | \`hsl(H,S,L)\`  | \`hsl(212, 92%, 45%)\`  | `hsl(212, 92%, 45%)`  |

## Links
You can create an inline link by wrapping link text in brackets `[ ]`, and then wrapping the URL in parentheses `( )`.

| Example  | Output |
| -------- | ------ |
| `[`Google`](`https://www.google.com/`)` | [Google](https://www.google.com/) |

## Relative links

You can define relative links and image paths in your rendered files to help readers navigate to other files in your repository.

| Example  | Output |
| -------- | ------ |
| `[`Click to refresh!`](`docs/readme-helper.md`)` | [Click to refresh!](./readme-helper.md) |

## Lists

You can make an unordered list by preceding one or more lines of text with `-`, `*`, or `+`.

```markdown
- One
* Two
+ Three
```

* One
* Two
* Three

To order your list, precede each line with a number.

```markdown
1. One
2. Two
3. Three
```

1. One
2. Two
3. Three

## Nested Lists

You can create a nested list by indenting one or more list items below another item.

```markdown
1. First list item
   - First nested list item
     - Second nested list item
```

1. First list item
   - First nested list item
     - Second nested list item

## Task lists

To create a task list, preface list items with a hyphen and space followed by `[ ]`. To mark a task as complete, use `[x]`.

```markdown
- [x] Task One
- [ ] Task Two
```

- [x] Task One
- [ ] Task Two

## Alerts

To add an alert, use a special blockquote line specifying the alert type, followed by the alert information in a standard blockquote. Five types of alerts are available:

```markdown
> [!NOTE]
> Useful information that users should know, even when skimming content.

> [!TIP]
> Helpful advice for doing things better or more easily.

> [!IMPORTANT]
> Key information users need to know to achieve their goal.

> [!WARNING]
> Urgent info that needs immediate user attention to avoid problems.

> [!CAUTION]
> Advises about risks or negative outcomes of certain actions.
```

> [!NOTE]
> Useful information that users should know, even when skimming content.

> [!TIP]
> Helpful advice for doing things better or more easily.

> [!IMPORTANT]
> Key information users need to know to achieve their goal.

> [!WARNING]
> Urgent info that needs immediate user attention to avoid problems.

> [!CAUTION]
> Advises about risks or negative outcomes of certain actions.

## Ignoring Markdown formatting

You can tell GitHub to ignore (or escape) Markdown formatting by using `\` before the Markdown character.

```markdown
Let's rename \*our-old-project\* to \*our-old-project\*.
```

Let's rename \*our-old-project\* to \*our-old-project\*.
