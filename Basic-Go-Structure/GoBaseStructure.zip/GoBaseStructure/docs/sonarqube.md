# SonarQube

## SonarQube User Guide

[![Badge](https://img.shields.io/badge/Version-1.0.0-blue.svg)](https://github.com/ProbePlusDevTeam/Dev_Docker/tree/main)

## Setup SonarQube Server

### Pre-installation Steps

* **Configure the maximum number of open files and other limits:**

  * *Run the following commands as* **root**:

    ```bash
    sysctl -w vm.max_map_count=524288
    sysctl -w fs.file-max=131072
    ulimit -n 131072
    ulimit -u 8192
    ```

* **Enable seccomp on the Linux kernel:**

  By default, Elasticsearch uses the seccomp filter. Make sure you use a kernel with seccomp enabled.

  To check that seccomp is available on your kernel, use:

  ```bash
  grep SECCOMP /boot/config-$(uname -r)
  ```

  If your kernel has seccomp, you'll see the following:

  ```bash
  CONFIG_HAVE_ARCH_SECCOMP_FILTER=y
  CONFIG_SECCOMP_FILTER=y
  CONFIG_SECCOMP=y
  ```

### Go to the [SonarQube_Docker](SonarQube_Docker) directory

* **Start the docker compose:**

    ```bash
    docker compose up -d
    ```

* **If you wish to stop the docker compose:**

    ```bash
    docker compose down
    ```

### Login to SonarQube Server

  * **Once the instance is up and running, Log in to http://localhost:9000 using System Administrator credentials:**

    ```text
    login: admin
    password: admin
    ```

### Analyzing a project

**Now that you're logged in to your local SonarQube instance, let's analyze a project:**

1. Select **Create new project**.
2. Give your project a **Project key** and a **Display name** and select **Set up**.
3. Under **Provide a token**, select **Generate a token**. Give your token a name, select **Generate**, and click **Continue**.
4. Select your project's main language under **Run analysis on your project**, and follow the instructions to analyze your project. Here you'll download and execute a scanner on your code.

## SonarScanner

**The SonarScanner is the scanner to use when there is no specific scanner for your build system. The SonarScanner does not support ARM architecture.**

* **Create a configuration file in your project's root directory called `sonar-project.properties`:**

    ```properties
    # must be unique in a given SonarQube instance

    # Project Name
    sonar.projectKey=PythonBaseStructure

    # Project Analysis Token
    sonar.login=sqa_789c9c5axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

    # --- optional properties ---

    # defaults to project key
    #sonar.projectName=My project

    # defaults to 'not provided'
    sonar.projectVersion=1.0
    
    # Path is relative to the sonar-project.properties file. Defaults to .
    #sonar.sources=.
    
    # Encoding of the source code. Default is default system encoding
    #sonar.sourceEncoding=UTF-8
    ```

* **Running SonarScanner from the Docker image**

    ```bash
    docker run \
        --rm --network host\
        -e SONAR_HOST_URL="http://localhost:9000" \
        -v "/home/ubuntu/PythonBaseStructure:/usr/src" \
        -w="/usr/src" \
        sonarsource/sonar-scanner-cli
    ```

    Here, `/home/ubuntu/PythonBaseStructure` is the Project's root directory

### After successfully analyzing your code, you'll see your first analysis on SonarQube:

<picture>
  <img alt="SonarQube Analysis Summary Image." src="https://github.com/ProbePlusDevTeam/PythonBaseStructure/blob/main/docs/analysis_image.png">
</picture>
