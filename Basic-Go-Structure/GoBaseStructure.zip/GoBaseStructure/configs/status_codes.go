package configs

import (
	"encoding/json"
	"fiber-project/models"
	"log"
)

// http  statusCode codes
const (
	// 200 - Success Codes
	OK         = 200
	CREATED    = 201
	NO_CONTENT = 204

	// 400 - Client Error Codes
	BAD_REQUEST    = 400
	UNAUTHORIZED   = 401
	FORBIDDEN      = 403
	NOT_FOUND      = 404
	NOT_ACCEPTABLE = 406 //Server cannot produce response as not matching the acceptable values in the list
	CONFLICT       = 409 // User alreasy exists in the system

	// 500 - Server Error Codes
	INTERNAL_SERVER_ERROR = 500
	BAD_GATEWAY           = 502 // While acting as gateway received an invalid response form the upstream server while trying to fulfill the request.
)

var StatusMessages = map[int]string{
	OK:                    "OK",
	CREATED:               "Created",
	NO_CONTENT:            "No Content",
	BAD_REQUEST:           "Bad Request",
	UNAUTHORIZED:          "Unauthorized",
	FORBIDDEN:             "Forbidden",
	NOT_FOUND:             "Not Found",
	NOT_ACCEPTABLE:        "Not Acceptable",
	CONFLICT:              "Conflict Already Exists",
	INTERNAL_SERVER_ERROR: "Internal Server Error",
	BAD_GATEWAY:           "Bad Gateway",
}

// error codes
const (
	// General Errors
	ERR_UNKNOWN          = 1000
	ERR_INVALID_INPUT    = 1001
	ERR_OPERATION_FAILED = 1002

	// Validation Errors
	ERR_VALIDATION_FAILED    = 2000
	ERR_MISSING_FIELD        = 2001
	ERR_INVALID_FIELD_FORMAT = 2002

	// Database Errors
	ERR_DATABASE            = 3000
	ERR_DATABASE_CONNECTION = 3001
	ERR_RECORD_NOT_FOUND    = 3002
	ERR_DUPLICATE_RECORD    = 3003
	ERR_QUERY_FAILED        = 3004

	// Authentication/Authorization Errors
	ERR_AUTHENTICATION_FAILED = 4000
	ERR_ACCESS_DENIED         = 4001
	ERR_TOKEN_EXPIRED         = 4002
	ERR_TOKEN_INVALID         = 4003

	// External Service Errors
	ERR_EXTERNAL_SERVICE    = 5000
	ERR_SERVICE_UNAVAILABLE = 5001
	ERR_SERVICE_TIMEOUT     = 5002
	ERR_SERVICE_ERROR       = 5003

	//Keyclocck errors
	ERR_CLIENT_LOGIN_FAILED   = 6000
	ERR_FAILED_CREATE_USER    = 6001
	ERR_FAILED_SET_PASSWORD   = 6002
	ERR_FAILED_GET_USER_BY_ID = 6003
	ERR_FAILED_UPDATE_USER    = 6004
	ERR_FAILED_DELETE_FAILED  = 6005
	ERR_ADMIN_LOGIN_FAILED    = 6006
	DISABLED_USER_STATUS      = 6007
)

var ErrorMessages = map[int]string{
	// General Errors
	ERR_UNKNOWN:          "An unknown error occurred",
	ERR_INVALID_INPUT:    "Invalid input provided",
	ERR_OPERATION_FAILED: "Operation failed",

	// Validation Errors
	ERR_VALIDATION_FAILED:    "Validation failed",
	ERR_MISSING_FIELD:        "Required field is missing",
	ERR_INVALID_FIELD_FORMAT: "Field format is invalid",

	// Database Errors
	ERR_DATABASE:            "Database error",
	ERR_DATABASE_CONNECTION: "Database connection failed",
	ERR_RECORD_NOT_FOUND:    "Record not found",
	ERR_DUPLICATE_RECORD:    "Duplicate record exists",
	ERR_QUERY_FAILED:        "Database query failed",

	// Authentication/Authorization Errors
	ERR_AUTHENTICATION_FAILED: "Authentication failed",
	ERR_ACCESS_DENIED:         "Access denied",
	ERR_TOKEN_EXPIRED:         "Token has expired",
	ERR_TOKEN_INVALID:         "Token is invalid",

	// External Service Errors
	ERR_EXTERNAL_SERVICE:    "External service error",
	ERR_SERVICE_UNAVAILABLE: "Service is unavailable",
	ERR_SERVICE_TIMEOUT:     "Service request timed out",

	//Keyclocck errors
	ERR_CLIENT_LOGIN_FAILED:   "Failed to log in to Keycloak.",
	ERR_FAILED_CREATE_USER:    "Failed to create user in Keycloak.",
	ERR_FAILED_SET_PASSWORD:   "Failed to set password for user in Keycloak.",
	ERR_FAILED_GET_USER_BY_ID: "Failed to get user by ID in Keycloak.",
	ERR_FAILED_UPDATE_USER:    "Failed to update user in Keycloak.",
	ERR_FAILED_DELETE_FAILED:  "Failed to delete user from Keycloak.",
	ERR_ADMIN_LOGIN_FAILED:    "Failed to log in as admin.",
	DISABLED_USER_STATUS:      "User is disabled",
}

// above function is used to create error response like below:
// return configs.ErrorResponse(configs.ERR_MISSING_FIELD)
func Response(statusCode int, data interface{}, errorCode int) models.Response {
	var response models.Response

	if statusCode >= 200 && statusCode < 300 {
		// Success response
		// If the data is a slice with only one item, unwrap it
		if slice, ok := data.([]interface{}); ok {
			if len(slice) == 1 {
				data = slice[0]
			} else if len(slice) == 0 {
				data = []interface{}{}
			}
		}
		response = models.Response{
			Status:  statusCode,
			Message: StatusMessages[statusCode],
			Data:    data,
		}
	} else {
		// Error response
		response = models.Response{
			Status:  statusCode,
			Message: StatusMessages[statusCode],
			Error: &models.ErrorDetail{
				ErrorCode: errorCode,
				Message:   ErrorMessages[errorCode],
			},
		}
	}

	return response
}

// PrintResponse marshals the response to JSON and prints it
func PrintResponse(response models.Response) {
	responseJSON, err := json.MarshalIndent(response, "", "  ")
	if err != nil {
		log.Fatalf("Failed to marshal response: %v", err)
	}
	log.Printf("Response: %s\n", responseJSON)
}
