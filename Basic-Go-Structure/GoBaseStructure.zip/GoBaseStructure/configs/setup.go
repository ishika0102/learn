package configs

import (
	"context"
	"fmt"
	"log"
	"os"
	"strconv"
	"time"

	"github.com/Nerzal/gocloak/v13"
	"github.com/joho/godotenv"
	"github.com/pkg/errors"
	"github.com/spf13/viper"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"

	"fiber-project/models"
)

var MongoConnection *mongo.Client
var UserCollection *mongo.Collection
var AuditCollection *mongo.Collection
var KC *models.KeycloakConfig

func init() {
	// Call all the setup funcitons here :
	//To setup .env variables using viper library
	InitViper()
	//To setup keycloak
	KC = models.NewIdentityManager()
	//To get mongodb collections and get all default collections
	SetUpMongoDb()
	//To insert default values in the db at the start of server
	InitialDbSetup()
	//To set new unique indexes in the default collections
	// InitUniqueIndexes()

}
func SetUpMongoDb() {
	// To establish db connection
	MongoConnection = NewDbConnection()
	// call GetCollection  for each collection in the project here :

	UserCollection = GetCollection(USER_COLLECTION)
	AuditCollection = GetCollection(AUDIT_COLLECTION)

}

func InitialDbSetup() {
	// creating default users, modules etc according to the project which is needed at the time of server start
	CreateRootUser()
}

func NewDbConnection() *mongo.Client {
	clientOptions := options.Client().ApplyURI(viper.GetString("mongoURI"))
	client, err := mongo.Connect(context.Background(), clientOptions)
	if err != nil {
		log.Fatal("newdbconnection", err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	// TODO: FUTURE : handle error if not able to connect to mongodb below
	err = client.Ping(ctx, nil)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println("Connected to MongoDB")

	return client
}

// GetCollection returns a collection from the database
func GetCollection(collectionName string) *mongo.Collection {
	return MongoConnection.Database(os.Getenv("DB_NAME")).Collection(collectionName)
}

func InitViper() {
	fmt.Println("Initializing Viper")
	// Load .env
	err := godotenv.Load()
	if err != nil {
		log.Fatal("Error loading .env file")
	}
	// Set individual config values
	viper.Set("mongoURI", os.Getenv("MONGO_URL"))
	// Set individual config values in Viper
	viper.Set("ListenIP", os.Getenv("KeyCloakListenIP"))
	viper.Set("ListenPort", os.Getenv("KeyccloakListenPort"))
	viper.Set("Realm", os.Getenv("KeyCloakRealm"))
	viper.Set("BaseUrl", os.Getenv("KeyCloakBaseUrl"))
	viper.Set("ClientID", os.Getenv("KeyCloakRestApiClientId"))
	viper.Set("ClientSecret", os.Getenv("KeyCloakRestApiClientSecret"))
	viper.Set("PublicKey", os.Getenv("KeyCloakRealmRS256PublicKey"))

}

// Create unique index on  field in  collection
// func CreateUniqueIndex(field bson.M, collection *mongo.Collection) {
// 	indexModel := mongo.IndexModel{
// 		Keys:    field, // Specify the field and the index type (1 for ascending, -1 for descending)
// 		Options: options.Index().SetUnique(true),
// 	}
// 	_, err := collection.Indexes().CreateOne(context.Background(), indexModel)
// 	if err != nil {
// 		log.Fatal(err)
// 	}
// }

// // Initialize unique indexes
// func InitUniqueIndexes() {
// 	// Call the CreateUniqueIndex function to create unique indexes for which ever collection needed here:
// 	CreateUniqueIndex(bson.M{"UserId": 1}, UserCollection)

// }

// Function to add the default root user into the db
func CreateRootUser() {
	rootData := models.Root{
		UserInfo: models.UserInfo{
			UserId:   RootUserId,
			Username: RootUserName,
			Password: RootUserPassword,
			UserRole: RootUserRole,
		},
		BasicUserInfo: models.BasicUserInfo{
			FirstName:   RootFirstName,
			LastName:    RootLastName,
			Email:       RootEmail,
			CountryCode: RootCountryCode,
			PhoneNumber: RootMobileNumber,
		},
		AuditDetails: models.AuditDetails{
			CreatedByUserId: RootCreatedByUserId,
			CreatedOn:       strconv.FormatInt(time.Now().UTC().Unix(), 10),
		},
	}

	filter := bson.M{"_id": RootUserId}
	result := UserCollection.FindOne(context.Background(), filter)
	if result.Err() == mongo.ErrNoDocuments {
		// userid, er := RegisterRoot(rootData)
		// if er != nil {
		// 	fmt.Println("register", er)
		// 	fmt.Println("err in register")
		// 	return
		// }
		// rootData.KeycloakUserId = userid

		_, err := UserCollection.InsertOne(context.Background(), rootData)
		if err != nil {
			err_response := models.Response{
				Status:  500,
				Message: err.Error(),
			}
			fmt.Println(err_response)
			return
		}
		return
	}

}

// Function to register root user in keycloak
func RegisterRoot(user models.Root) (string, error) {

	newUser := gocloak.User{
		Username:      gocloak.StringP(user.Username),
		Enabled:       gocloak.BoolP(true),
		Email:         gocloak.StringP(user.Email),
		EmailVerified: gocloak.BoolP(true),
		FirstName:     gocloak.StringP(user.FirstName),
		LastName:      gocloak.StringP(user.LastName),
		Credentials: &[]gocloak.CredentialRepresentation{
			{
				Type:      gocloak.StringP("password"), // Using a fixed type for password
				Value:     gocloak.StringP(user.Password),
				Temporary: gocloak.BoolP(false),
			},
		},
		Attributes: &map[string][]string{
			"MobileNumber": {user.MobileNumber},
			"UserRole":     {user.UserRole},
			"UserId":       {user.UserId},
		},
	}
	token, err := LoginRestApiClient(context.Background())
	if err != nil {
		fmt.Println("error in loginRestApiClient of register")
		return "", err
	}
	client := gocloak.NewClient(KC.BaseURL)
	keycloakUserId, err := client.CreateUser(context.Background(), token.AccessToken, KC.Realm, newUser)
	if err != nil {
		fmt.Println("error in CreateUser of register", err)
		return "", err
	}
	// err = client.SetPassword(context.Background(), token.AccessToken, keycloakUserId, kc.Realm, password, true)
	// if err != nil {
	// 	fmt.Println("error in SetPassword of register")
	// 	return "", err
	// }
	return keycloakUserId, nil

}

//	func loginRestApiClient(ctx context.Context) (*gocloak.JWT, error) {
//		fmt.Println(KC.BaseURL)
//		client := gocloak.NewClient(KC.BaseURL)
//		token, err := client.LoginClient(ctx, KC.ClientID, KC.ClientSecret, KC.Realm)
//		if err != nil {
//			return nil, errors.Wrap(err, "unable to login the rest client")
//		}
//		return token, nil
//	}
func LoginRestApiClient(ctx context.Context) (*gocloak.JWT, error) {
	client := gocloak.NewClient(KC.BaseURL)
	fmt.Println("*******************************")
	fmt.Println(KC.BaseURL)
	fmt.Println(KC.ClientID)
	fmt.Println(KC.ClientSecret)
	fmt.Println(KC.Realm)
	token, err := client.LoginClient(ctx, KC.ClientID, KC.ClientSecret, KC.Realm)
	if err != nil {
		fmt.Println("****************")
		fmt.Println(err)
		return nil, errors.Wrap(err, "unable to login the rest client")
	}
	return token, nil
}
