package configs

// add all project constants here :
// collection names
// project specific constants

const USER_COLLECTION = "users"
const AUDIT_COLLECTION = "audit_logs"

const (
	RootUserId          = "ROOT"
	RootUserPassword    = "root"
	RootUserName        = "root"
	RootFirstName       = "Default"
	RootLastName        = "Root"
	RootEmail           = "root@gmail.com"
	RootCountryCode     = "+91"
	RootMobileNumber    = "9090898000"
	RootUserRole        = "RA"
	RootCreatedByUserId = "default"
)

const (
	USER_PREFIX = "USR"
)

const (
	PWD_LENGTH = 10
)
