package configs

import (
	"context"
	"fiber-project/models"
	"fmt"
	"log"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/natefinch/lumberjack"
	"go.mongodb.org/mongo-driver/mongo"
)

// Define logger
var logger *log.Logger

func GetLogger() *log.Logger {
	if logger == nil {
		logFile := &lumberjack.Logger{
			Filename:   "backend.log",
			MaxSize:    19, // megabytes
			MaxBackups: 20,
			Compress:   true, // disabled by default
		}
		logger = log.New(logFile, "", log.LstdFlags)
		logger.SetOutput(logFile)
	}
	return logger
}

func init() {
	log.SetFlags(log.LstdFlags | log.Lshortfile)
	log.SetOutput(&lumberjack.Logger{
		Filename:   "logger/backend.log",
		MaxSize:    19, // megabytes
		MaxBackups: 20,
		Compress:   true, // disabled by default
	})
}

// Add an audit log entry to MongoDB
func AddAuditLog(user map[string]string, refId string, data map[string]interface{}, collection *mongo.Collection, eventType string, recordType string) {
	timestamp := time.Now().UTC()
	var auditLogInfo models.AuditLogInfoType

	if user != nil {
		switch eventType {
		case "CREATE":
			auditLogInfo = models.AuditLogInfoType{CreatedBy: user["username"], CreatedById: user["user_id"], CreatedDateTime: timestamp}
		case "UPDATE", "DELETE":
			auditLogInfo = models.AuditLogInfoType{ModifiedBy: user["username"], ModifiedById: user["user_id"], ModifiedDateTime: timestamp}
		}
	}

	auditLogData := models.BaseAuditLog{
		EventType:    eventType,
		RefId:        refId,
		Data:         data,
		RecordType:   recordType,
		AuditLogInfo: auditLogInfo,
	}

	_, err := collection.InsertOne(context.Background(), auditLogData)
	if err != nil {
		log.Printf("Error inserting audit log: %v", err)
	}
}

// Define logger function
func DefineLogger(level int, user map[string]string, c *fiber.Ctx, loggName string, pid int, message string, body map[string]interface{}) {
	txt := ""

	if user != nil {
		txt += fmt.Sprintf("- USER: %s ", user["user_id"])
	}
	if c != nil {
		txt += fmt.Sprintf("- IP: %s - URL: %s %s ", c.IP(), c.Method(), c.OriginalURL())
	}
	if message != "" {
		txt += fmt.Sprintf("- MESSAGE: %s ", message)
	}
	if pid != 0 {
		txt += fmt.Sprintf("- PID: %d ", pid)
	}
	if loggName != "" {
		txt += fmt.Sprintf("- FILE: %s ", loggName)
	}
	if body != nil {
		txt += fmt.Sprintf("- BODY: %v ", body)
	}

	switch level {
	case 10:
		log.Println("DEBUG: " + txt)
	case 20:
		log.Println("INFO: " + txt)
	case 30:
		log.Println("WARNING: " + txt)
	case 40:
		log.Println("ERROR: " + txt)
	case 50:
		log.Println("CRITICAL: " + txt)
	default:
		log.Println("DEBUG: " + txt)
	}
}

// db audit function

// error log function
