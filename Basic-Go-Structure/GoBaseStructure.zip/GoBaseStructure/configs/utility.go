package configs

import (
	"fiber-project/models"
	"fmt"

	"github.com/gofiber/fiber/v2"
)

// Define roles
const (
	DA   = "DA"   //DistributorAdmin
	FA   = "FA"   //FacilityAdmin
	ROOT = "ROOT" //Root user
)

// Define a map to store allowed roles for each API endpoint

var apiPermissions = map[string][]string{
	//Here we are using Function Names as a map index Along with the Permissions they have as there value
	"CreateUser":   {ROOT, DA},
	"View":         {ROOT},
	"ViewAllUsers": {ROOT, DA}, // TODO: if da then he should only be able to see oa not other da add this check
	"UpdateStatus": {ROOT},
	"UpdateUser":   {ROOT, DA, FA},
}

// function to check if the user has access to the requested endpoint
func CheckAccess(funcName string, userRole string) error {
	// Check if the endpoint exists in permissions map
	allowedMethods, ok := apiPermissions[funcName]
	fmt.Println(funcName)
	if !ok {
		fmt.Println(ok)
		// Endpoint not found in permissions map, deny access
		return fiber.NewError(fiber.StatusUnauthorized, "Unauthorized endpoint")
	}
	// Check if the user's role is allowed
	for _, role := range allowedMethods {
		fmt.Println("************************************************************************")
		fmt.Println(role)
		fmt.Println(userRole)
		fmt.Println(funcName)
		fmt.Println("************************************************************************")
		if role == userRole {
			// User has access
			fmt.Println("inside if check access")
			return nil
		}
	}

	// User's role is not allowed, deny access
	return fiber.NewError(fiber.StatusForbidden, "Forbidden, user has no access")
}

var APP_INFO = []models.AppInfo{
	{Version: "1.0.0", ReleaseDate: "27/05/2024"},
	{Version: "1.0.1", ReleaseDate: "28/05/2024"},
	{Version: "2.0.1", ReleaseDate: "30/05/2024"},
}
