package middleware

import (
	"context"
	"fiber-project/configs"
	"fiber-project/models"
	"fmt"
	"math/rand"
	"time"

	"github.com/Nerzal/gocloak/v13"
	"github.com/pkg/errors"
)

func loginRestApiClient(ctx context.Context) (*gocloak.JWT, error) {
	client := gocloak.NewClient(configs.KC.BaseURL)
	fmt.Println("*******************************")
	fmt.Println(configs.KC.BaseURL)
	fmt.Println(configs.KC.ClientID)
	fmt.Println(configs.KC.ClientSecret)
	fmt.Println(configs.KC.Realm)
	token, err := client.LoginClient(ctx, configs.KC.ClientID, configs.KC.ClientSecret, configs.KC.Realm)
	if err != nil {
		fmt.Println("****************")
		fmt.Println(err)
		return nil, errors.Wrap(err, "unable to login the rest client")
	}
	return token, nil
}

func Register(user models.User) (string, error) {
	// tempPasswordStr := GenerateRandomCode()
	var email, firstName, lastName, contactNumber, userRole, belongToOrgId, userId, userStatus, password string
	email = user.Email
	firstName = user.FirstName
	lastName = user.LastName
	contactNumber = user.PhoneNumber
	userRole = user.UserRole
	userId = user.UserId
	userStatus = user.UserStatus
	password = user.Password

	fmt.Println(userId)

	newUser := gocloak.User{
		Username:      gocloak.StringP(contactNumber),
		Enabled:       gocloak.BoolP(true),
		Email:         gocloak.StringP(email),
		EmailVerified: gocloak.BoolP(true),
		FirstName:     gocloak.StringP(firstName),
		LastName:      gocloak.StringP(lastName),
		Credentials: &[]gocloak.CredentialRepresentation{
			{
				Type:      gocloak.StringP("password"), // Using a fixed type for password
				Value:     gocloak.StringP(password),
				Temporary: gocloak.BoolP(true),
			},
		},
		Attributes: &map[string][]string{
			"ContactNumber": {contactNumber},
			"UserRole":      {userRole},
			"BelongToOrgId": {belongToOrgId},
			"UserStatus":    {userStatus},
			"UserId":        {userId},
		},
	}
	token, err := loginRestApiClient(context.Background())
	if err != nil {
		fmt.Println("error in loginRestApiClient of register")
		return "", err
	}
	client := gocloak.NewClient(configs.KC.BaseURL)
	fmt.Println(client)
	// fmt.Println("this is token in register", token.AccessToken)
	fmt.Println("this is realm in register", configs.KC.Realm)
	keycloakUserId, err := client.CreateUser(context.Background(), token.AccessToken, configs.KC.Realm, newUser)
	if err != nil {
		fmt.Println("error in CreateUser of register", err)
		return "", err
	}
	err = client.SetPassword(context.Background(), token.AccessToken, keycloakUserId, configs.KC.Realm, password, true)
	if err != nil {
		fmt.Println("error in SetPassword of register")
		return "", err
	}
	return keycloakUserId, nil
}

func UpdateKeycloakUser(userId string, newAttributes map[string]interface{}) error {

	client := gocloak.NewClient(configs.KC.BaseURL)

	// Obtain an admin token
	token, err := client.LoginClient(context.Background(), configs.KC.ClientID, configs.KC.ClientSecret, configs.KC.Realm)
	if err != nil {
		fmt.Println("error-in-login", err)
		return err
	}
	fmt.Println("userid ", userId)
	// Get the user by ID
	user, err := client.GetUserByID(context.Background(), token.AccessToken, configs.KC.Realm, userId)
	if err != nil {
		fmt.Println("error in get user by id ", err)
		return err
	}
	// fmt.Println("user ", user)
	// Update user attributes based on newAttributes
	// if username, ok := newAttributes["username"].(string); ok {
	// 	user.Username = &username
	// }
	if email, ok := newAttributes["Email"].(string); ok {
		user.Email = &email
	}
	if contactNumber, ok := newAttributes["ContactNumber"].(string); ok {
		(*user.Attributes)["ContactNumber"] = []string{contactNumber}
	}

	// Update the user
	err = client.UpdateUser(context.Background(), token.AccessToken, configs.KC.Realm, *user)
	if err != nil {
		fmt.Println("error in update user", err)
		return err
	}

	return nil
}

func DisableKeycloakUser(userID string) error {

	client := gocloak.NewClient(configs.KC.BaseURL)

	// Obtain an admin token
	token, err := client.LoginClient(context.Background(), configs.KC.ClientID, configs.KC.ClientSecret, configs.KC.Realm)
	if err != nil {
		fmt.Println("error-in-login", err)
		return err
	}

	// Get the user by ID
	user, err := client.GetUserByID(context.Background(), token.AccessToken, configs.KC.Realm, userID)
	if err != nil {
		fmt.Println("error in get user by id ", err)
		return err
	}

	// Disable the user
	user.Enabled = gocloak.BoolP(false)

	// Update the user
	err = client.UpdateUser(context.Background(), token.AccessToken, configs.KC.Realm, *user)
	if err != nil {
		fmt.Println("error in update user", err)
		return err
	}

	return nil
}
func DeleteKeycloakUser(userID string) error {

	client := gocloak.NewClient(configs.KC.BaseURL)

	// Obtain an admin token
	token, err := client.LoginClient(context.Background(), configs.KC.ClientID, configs.KC.ClientSecret, configs.KC.Realm)
	if err != nil {
		fmt.Println("error-in-login", err)
		return err
	}

	// Delete the user
	err = client.DeleteUser(context.Background(), token.AccessToken, configs.KC.Realm, userID)
	if err != nil {
		fmt.Println("error in delete user", err)
		return err
	}

	return nil
}

// getClientSecret retrieves the client secret key for the specified client ID.
func getClientSecret(keycloak *gocloak.GoCloak, ctx context.Context, realmName, clientID, adminUsername, adminPassword string) (*string, error) {
	// Authenticate as admin
	token, err := keycloak.LoginAdmin(ctx, adminUsername, adminPassword, clientID)
	if err != nil {
		return nil, fmt.Errorf("error logging in as admin: %v", err)
	}

	// Get client secret
	clientSecretObj, err := keycloak.GetClientSecret(ctx, token.AccessToken, realmName, clientID)
	if err != nil {
		return nil, fmt.Errorf("error getting client secret: %v", err)
	}

	return clientSecretObj.Value, nil
}

// getPublicKey retrieves the public key for the specified attribute (e.g., `public-key`) of a client.
func GetPublicKey(realmName, clientID, adminUsername, adminPassword string) (*string, error) {
	fmt.Println("inside get public key")
	client := gocloak.NewClient(configs.KC.BaseURL)
	// Authenticate as admin
	_, err := client.LoginAdmin(context.Background(), adminUsername, adminPassword, realmName)
	if err != nil {
		return nil, fmt.Errorf("error logging in as admin: %v", err)
	}

	// Get public key
	publicKeyObj, err := client.GetIssuer(context.Background(), realmName)
	if err != nil {
		return nil, fmt.Errorf("error getting public key: %v", err)
	}
	fmt.Println(publicKeyObj.PublicKey)

	return publicKeyObj.PublicKey, nil
}

func GenerateRandomCode() string {
	r := rand.New(rand.NewSource(time.Now().UnixNano()))

	// Generate a random 6-digit code
	code := fmt.Sprintf("%06d", r.Intn(1000000))

	return code
}
