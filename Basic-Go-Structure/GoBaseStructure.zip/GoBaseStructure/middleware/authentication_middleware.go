package middleware

import (
	"context"
	"crypto/rsa"
	"crypto/x509"
	"encoding/base64"
	"fiber-project/configs"
	"fmt"

	"github.com/Nerzal/gocloak/v13"
	"github.com/dgrijalva/jwt-go"
	"github.com/gofiber/fiber/v2"
	"github.com/pkg/errors"
)

func NewJwtMiddleware(ctx *fiber.Ctx) error {
	fmt.Println("inside jwt middleware")
	// Get JWT token from request header
	token := ctx.Get("Authorization")
	if token == "" {
		return ctx.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "JWT token not provided",
		})
	}

	// Parse Keycloak public key
	base64Str := configs.KC.PublicKey
	publicKey, err := parseKeycloakRSAPublicKey(base64Str)
	if err != nil {
		fmt.Println(err)
		return ctx.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"error": "Failed to parse public key",
		})
	}

	// Validate token
	_, err = jwt.ParseWithClaims(token, &jwt.StandardClaims{}, func(token *jwt.Token) (interface{}, error) {
		return publicKey, nil
	})
	if err != nil {
		fmt.Println("NewJWTMiddleware error :", err)
		return ctx.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
			"error": "Invalid or expired token",
		})
	}

	// // Optionally retrospect token if needed
	// rptResult, err := retrospectToken(token)
	// if err != nil || !*rptResult.Active {
	// 	return ctx.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
	// 		"error": "Token retrospection failed or token is not active",
	// 	})
	// }

	// Proceed with successful token processing
	return ctx.Next() // Success, move to the next middleware or controller
}

func retrospectToken(token string) (*gocloak.IntroSpectTokenResult, error) {
	fmt.Println("inside retrospect token")

	client := gocloak.NewClient(configs.KC.BaseURL)
	rptResult, err := client.RetrospectToken(context.Background(), token, configs.KC.ClientID, configs.KC.ClientSecret, configs.KC.Realm)
	if err != nil {
		return nil, errors.Wrap(err, "unable to retrospect token")
	}
	if !*rptResult.Active {
		return nil, errors.New("token is not active")
	}

	return rptResult, nil
}

func parseKeycloakRSAPublicKey(base64Str string) (*rsa.PublicKey, error) {

	buf, err := base64.StdEncoding.DecodeString(base64Str)
	if err != nil {
		fmt.Println("decode string", err)
		return nil, err
	}
	parsedKey, err := x509.ParsePKIXPublicKey(buf)
	if err != nil {
		fmt.Println("parse public key", err)
		return nil, err
	}
	publicKey, ok := parsedKey.(*rsa.PublicKey)
	if ok {
		// fmt.Println("public key ", publicKey)
		return publicKey, nil
	}
	return nil, fmt.Errorf("unexpected key type %T", publicKey)
}
