package controller

import (
	"fiber-project/configs"
	"fiber-project/helpers"
	"fiber-project/middleware"
	"fiber-project/models"
	"fiber-project/services"
	"fmt"
	"os"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
	"go.mongodb.org/mongo-driver/bson"
)

func CreateUser(ctx *fiber.Ctx) error {
	var user models.User
	if err := ctx.BodyParser(&user); err != nil {
		configs.DefineLogger(40, nil, ctx, "CreateUser", os.Getpid(), "Failed to parse request body", map[string]interface{}{"error": err.Error()})
		errResponse := configs.Response(400, nil, 1002)
		return ctx.Status(configs.BAD_REQUEST).JSON(errResponse)
	}
	err := validator.New().Struct(user)
	if err != nil {
		configs.DefineLogger(40, nil, ctx, "CreateUser", os.Getpid(), "Validation failed", map[string]interface{}{"error": err.Error()})
		errResponse := configs.Response(400, nil, 2001)
		return ctx.Status(configs.BAD_REQUEST).JSON(errResponse)
	}
	user.UserId = helpers.GenerateUserID(configs.USER_PREFIX)
	fmt.Println(user.UserId)
	temp_pwd := helpers.GenerateRandomPassword(configs.PWD_LENGTH)
	fmt.Println(temp_pwd)

	// Call register function to create user in Keycloak
	userid, err := middleware.Register(user)
	if err != nil {
		configs.DefineLogger(40, nil, ctx, "admins.go", os.Getpid(), "Failed to register user in Keycloak", map[string]interface{}{"error": err.Error()})
		errResponse := configs.Response(409, nil, 6001)
		return ctx.Status(fiber.StatusConflict).JSON(errResponse)
	}
	user.KeycloakUserId = userid
	fmt.Println(user.KeycloakUserId)
	user.CreatedOn = helpers.GetCurrentEpochTimeInFormat(false)
	result, err := services.InsertIntoDB(configs.UserCollection, user)
	fmt.Println(result)
	if err != nil {
		configs.DefineLogger(40, nil, ctx, "CreateUser", os.Getpid(), "Failed to insert user into database", map[string]interface{}{"error": err.Error()})
		errResponse := configs.Response(500, nil, 3004)
		return ctx.Status(fiber.StatusInternalServerError).JSON(errResponse)
	}
	configs.AddAuditLog(map[string]string{"username": "admin", "user_id": "1"}, user.UserId, map[string]interface{}{"user": user}, configs.AuditCollection, "CREATE", "CreateUser")

	configs.DefineLogger(20, map[string]string{"username": "admin", "user_id": "1"}, ctx, "CreateUser", os.Getpid(), "Successfully created distributor admin", map[string]interface{}{"user": user})
	response := configs.Response(201, user, 0)
	return ctx.Status(fiber.StatusCreated).JSON(response)
}

func View(ctx *fiber.Ctx) error {
	userid := ctx.Params("id")

	Projection := bson.M{
		"UserId":        "$_id",
		"_id":           0,
		"UserName":      "$username",
		"FirstName":     "$basicuserinfo.first_name",
		"LastName":      "$basicuserinfo.last_name",
		"Email":         "$basicuserinfo.email",
		"CountryCode":   "$basicuserinfo.country_code",
		"ContactNumber": "$basicuserinfo.phone_number",
	}
	filter := bson.M{"_id": userid}
	// var resultModel models.Users
	result, err := services.GetOne(filter, Projection, configs.UserCollection)
	if err != nil {
		configs.DefineLogger(40, nil, ctx, "admins.go", os.Getpid(), "Failed to retrieve user", map[string]interface{}{"error": err.Error(), "user_id": userid})
		errResponse := configs.Response(400, nil, 3002)
		return ctx.Status(fiber.StatusBadRequest).JSON(errResponse)
	}
	fmt.Println("result ", result)
	configs.DefineLogger(20, nil, ctx, "admins.go", os.Getpid(), "Successfully retrieved user", map[string]interface{}{"user_id": userid, "result": result})
	response := configs.Response(200, result, 0)
	// fiber.StatusOK - code 200 - indicates that success of GET, PUT, and DELETE requests
	return ctx.Status(fiber.StatusOK).JSON(response)
}

func ViewAllUsers(ctx *fiber.Ctx) error {

	filter := bson.M{"user_status": bson.M{"$ne": "delete"}} // Exclude documents where userstatus is "delete"}

	projection := bson.M{
		"FirstName":   "$basicuserinfo.first_name",
		"PhoneNumber": "$basicuserinfo.phone_number",
		"Email":       "$basicuserinfo.email",
		"UserStatus":  "$user_status",
		"_id":         0,
		"UserId":      "$_id",
	}
	// var resultModel []models.Users
	result, err := services.GetAll(filter, projection, configs.UserCollection)
	if err != nil {
		configs.DefineLogger(40, nil, ctx, "ViewAllUsers", os.Getpid(), "Failed to retrieve all users", map[string]interface{}{"error": err.Error()})
		errResponse := configs.Response(500, nil, 3004)
		return ctx.Status(fiber.StatusInternalServerError).JSON(errResponse)

	}
	configs.DefineLogger(20, nil, ctx, "ViewAllUsers", os.Getpid(), "Successfully retrieved all users", map[string]interface{}{"result": result})
	response := configs.Response(200, result, 0)
	// fiber.StatusOK - code 200 - indicates that success of GET, PUT, and DELETE requests
	return ctx.Status(fiber.StatusOK).JSON(response)
}

func UpdateStatus(ctx *fiber.Ctx) error {

	userid := ctx.Params("id")
	status := ctx.Params("status")

	filter := bson.M{"_id": userid}
	updateProjection := bson.M{
		"$set": bson.M{
			"user_status":                   status,
			"auditdetails.ModifiedByUserId": "root", // TODO: JWT : after jwt token use that to add value here
			"auditdetails.ModifiedOn":       helpers.GetCurrentEpochTimeInFormat(false),
		},
	}

	keycloakUserId, err := services.GetKeycloakId(userid, configs.UserCollection)
	if err != nil {
		configs.DefineLogger(40, nil, ctx, "UpdateStatus", os.Getpid(), "Failed to get Keycloak ID", map[string]interface{}{"error": err.Error(), "userid": userid})
		fmt.Println("get in keycloak", err)
		errResponse := configs.Response(500, nil, 6003)
		return ctx.Status(fiber.StatusInternalServerError).JSON(errResponse)
	}

	if status == "delete" {
		err = middleware.DeleteKeycloakUser(keycloakUserId)
		if err != nil {
			configs.DefineLogger(40, nil, ctx, "UpdateStatus", os.Getpid(), "Failed to delete Keycloak user", map[string]interface{}{"error": err.Error(), "keycloakUserId": keycloakUserId})
			errResponse := configs.Response(500, nil, 6005)
			return ctx.Status(fiber.StatusInternalServerError).JSON(errResponse)
		}
		result, err := services.UpdateOne(filter, updateProjection, configs.UserCollection)
		if err != nil {
			configs.DefineLogger(40, nil, ctx, "UpdateStatus", os.Getpid(), "Failed to update user status in database", map[string]interface{}{"error": err.Error(), "userid": userid, "status": status})
			errResponse := configs.Response(500, nil, 3004)
			return ctx.Status(fiber.StatusBadRequest).JSON(errResponse)
		}

		response := configs.Response(200, result, 0)
		return ctx.Status(fiber.StatusOK).JSON(response)
	}
	err1 := middleware.DisableKeycloakUser(keycloakUserId)
	if err1 != nil {
		configs.DefineLogger(40, nil, ctx, "UpdateStatus", os.Getpid(), "Failed to Disable Keycloak user", map[string]interface{}{"error": err1.Error(), "keycloakUserId": keycloakUserId})
		fmt.Println("update in keycloak", err1)
		errResponse := configs.Response(500, nil, 6007)
		return ctx.Status(fiber.StatusInternalServerError).JSON(errResponse)

	}
	result, err := services.UpdateOne(filter, updateProjection, configs.UserCollection)
	if err != nil {
		configs.DefineLogger(40, nil, ctx, "UpdateStatus", os.Getpid(), "Failed to update user status in database", map[string]interface{}{"error": err.Error(), "userid": userid, "status": status})
		errResponse := configs.Response(500, nil, 3004)
		return ctx.Status(fiber.StatusBadRequest).JSON(errResponse)

	}
	configs.DefineLogger(20, nil, ctx, "UpdateStatus", os.Getpid(), "User status updated successfully", map[string]interface{}{"userid": userid, "status": status})
	configs.AddAuditLog(nil, userid, map[string]interface{}{"status": status}, configs.AuditCollection, "UPDATE", "User")
	response := configs.Response(200, result, 0)
	// return ctx.Status(fiber.StatusOK).JSON(result)
	return ctx.JSON(response)
}

func UpdateUser(ctx *fiber.Ctx) error {
	var newUser models.User
	// TODO: validation
	if err := ctx.BodyParser(&newUser); err != nil {
		errResponse := configs.Response(400, nil, 1002)
		return ctx.Status(fiber.StatusBadRequest).JSON(errResponse)
	}
	fmt.Println(newUser)
	filter := bson.M{"_id": newUser.UserId}
	updateProjection := bson.M{
		"$set": bson.M{
			"basicuserinfo.first_name":      newUser.FirstName,
			"basicuserinfo.last_name":       newUser.LastName,
			"basicuserinfo.country_code":    newUser.CountryCode,
			"basicuserinfo.phone_number":    newUser.PhoneNumber,
			"user_status":                   newUser.UserStatus,
			"basicuserinfo.email":           newUser.Email,
			"auditdetails.ModifiedByUserId": "User_ID", // Using the Keyclock get the user that is Trying to Modifiy the data
			"auditdetails.ModifiedOn":       helpers.GetCurrentEpochTimeInFormat(false),
		},
	}
	new := map[string]interface{}{
		"basicuserinfo.email": newUser.Email,
		// "username":      daUser.Username,
		"basicuserinfo.phone_number": newUser.PhoneNumber,
	}
	keycloakUserId, err := services.GetKeycloakId(newUser.UserId, configs.UserCollection)
	if err != nil {
		configs.DefineLogger(40, nil, ctx, "UpadteUser", os.Getpid(), "Failed to get Keycloak user ID", map[string]interface{}{"error": err.Error()})
		fmt.Println("get in keycloak", err)
		errResponse := configs.Response(500, nil, 6003)
		return ctx.Status(fiber.StatusBadRequest).JSON(errResponse)
	}

	err1 := middleware.UpdateKeycloakUser(keycloakUserId, new)
	if err1 != nil {
		fmt.Println("update in keycloak", err1)
		configs.DefineLogger(40, nil, ctx, "UpadteUser", os.Getpid(), "Failed to update Keycloak user", map[string]interface{}{"error": err1.Error()})
		errResponse := configs.Response(500, nil, 6004)
		return ctx.Status(fiber.StatusInternalServerError).JSON(errResponse)
	}
	_, err = services.UpdateOne(filter, updateProjection, configs.UserCollection)
	if err != nil {
		configs.DefineLogger(40, nil, ctx, "UpadteUser", os.Getpid(), "Failed to update user in database", map[string]interface{}{"error": err.Error()})
		errResponse := configs.Response(500, nil, 3004)
		return ctx.Status(fiber.StatusBadRequest).JSON(errResponse)

	}
	updated, err := services.GetOne(filter, nil, configs.UserCollection)

	configs.AddAuditLog(map[string]string{"username": "admin", "user_id": "1"}, newUser.UserId, map[string]interface{}{"user": newUser}, configs.AuditCollection, "UPDATE", "UpadteUser")
	configs.DefineLogger(20, map[string]string{"username": "admin", "user_id": "1"}, ctx, "UpadteUser", os.Getpid(), "Successfully updated distributor admin", map[string]interface{}{"user": updated})
	response := configs.Response(200, updated, 0)
	// return ctx.Status(fiber.StatusOK).JSON(result)
	return ctx.JSON(response)
}
