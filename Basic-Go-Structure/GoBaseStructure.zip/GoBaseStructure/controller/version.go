package controller

import (
	"fiber-project/configs"

	"github.com/gofiber/fiber/v2"
)

func GetLatestAppInfo(c *fiber.Ctx) error {
	latestAppInfo := configs.APP_INFO[len(configs.APP_INFO)-1]
	return c.JSON(latestAppInfo)
}

func GetAllAppInfo(c *fiber.Ctx) error {
	return c.JSON(configs.APP_INFO)
}
