# AngularSdkExample - Angular UI

## Development
- go to `.../angular-sdk-example/angular-sdk-example-ui`

### Install Packages
- run `npm i` to install packages

### Run
- run `ng serve` to build and serve the application
- open the browser and navigate to *http://localhost:4200*
