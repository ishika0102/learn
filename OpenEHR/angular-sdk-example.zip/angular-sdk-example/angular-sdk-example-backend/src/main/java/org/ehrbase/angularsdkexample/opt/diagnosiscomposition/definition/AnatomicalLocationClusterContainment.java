package org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import com.nedap.archie.rm.datastructures.Cluster;
import java.lang.String;
import org.ehrbase.openehr.sdk.generator.commons.aql.containment.Containment;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.AqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.ListAqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.ListSelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.SelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

public class AnatomicalLocationClusterContainment extends Containment {
  public SelectAqlField<AnatomicalLocationCluster> ANATOMICAL_LOCATION_CLUSTER = new AqlFieldImp<AnatomicalLocationCluster>(
      AnatomicalLocationCluster.class, "", "AnatomicalLocationCluster", AnatomicalLocationCluster.class, this);

  public SelectAqlField<String> NAME_OF_BODY_PART_VALUE = new AqlFieldImp<String>(AnatomicalLocationCluster.class,
      "/items[at0001]/value|value", "nameOfBodyPartValue", String.class, this);

  public SelectAqlField<NullFlavour> NAME_OF_BODY_PART_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      AnatomicalLocationCluster.class, "/items[at0001]/null_flavour|defining_code",
      "nameOfBodyPartNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<LateralityDefiningCode> LATERALITY_DEFINING_CODE = new AqlFieldImp<LateralityDefiningCode>(
      AnatomicalLocationCluster.class, "/items[at0002]/value|defining_code", "lateralityDefiningCode",
      LateralityDefiningCode.class, this);

  public SelectAqlField<NullFlavour> LATERALITY_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      AnatomicalLocationCluster.class, "/items[at0002]/null_flavour|defining_code", "lateralityNullFlavourDefiningCode",
      NullFlavour.class, this);

  public ListSelectAqlField<Cluster> ALTERNATIVE_STRUCTURE = new ListAqlFieldImp<Cluster>(
      AnatomicalLocationCluster.class, "/items[at0053]", "alternativeStructure", Cluster.class, this);

  public ListSelectAqlField<Cluster> MULTIMEDIA_PRESENTATION = new ListAqlFieldImp<Cluster>(
      AnatomicalLocationCluster.class, "/items[at0054]", "multimediaPresentation", Cluster.class, this);

  public SelectAqlField<FeederAudit> FEEDER_AUDIT = new AqlFieldImp<FeederAudit>(AnatomicalLocationCluster.class,
      "/feeder_audit", "feederAudit", FeederAudit.class, this);

  private AnatomicalLocationClusterContainment() {
    super("openEHR-EHR-CLUSTER.anatomical_location.v1");
  }

  public static AnatomicalLocationClusterContainment getInstance() {
    return new AnatomicalLocationClusterContainment();
  }
}
