package org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition;

import java.lang.String;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.EnumValueSet;

public enum EtiologyOfTheDiseaseDefiningCode implements EnumValueSet {
   OTHER("Other", "Other causes that cannot be represented with given values", "local", "at0018"),

   PHYSICAL_INJURY("Physical injury", "e.g. head trauma, heat exhaustion, injury from radiation exposure", "local",
         "at0012"),

   OCCUPATIONAL_RISK_FACTORS("Occupational risk factors", "e.g. asbestos exposure", "local", "at0005"),

   INFECTION("Infection", "e.g. Hepatitis C", "local", "at0011"),

   NUTRITIONAL_FACTORS("Nutritional factors", "e.g. iron deficiency, carbohydrate-rich diet", "local", "at0008"),

   METABOLIC_ENDOCRINE_ORIGIN("Metabolic-endocrine origin", "e.g. B. Acromegaly, diabetes", "local", "at0014"),

   ORGANIC("Organic", "e.g. age, gender", "local", "at0006"),

   ENVIRONMENTAL_EXPOSURE("Environmental exposure", "e.g. exposure to UV radiation, fine dust exposure", "local",
         "at0016"),

   NEUROPSYCHIATRIC_ORIGIN("Neuropsychiatric origin", "e.g. Alzheimer's disease, depression", "local", "at0015"),

   CHEMICAL_INJURY("Chemical injury", "e.g. B. Poison, Medicine", "local", "at0007"),

   GENETIC_ORIGIN("Genetic origin", "e.g. sickle cell anemia", "local", "at0009"),

   IMMUNOLOGICAL_ORIGIN("Immunological origin",
         "e.g. systemic lupus erythematosus, AIDS (as the underlying cause of Kaposi's sarcoma)", "local", "at0010"),

   LIFESTYLE_RELATED_FACTORS("Lifestyle-related factors", "e.g. smoking, alcoholism", "local", "at0013");

   private String value;

   private String description;

   private String terminologyId;

   private String code;

   EtiologyOfTheDiseaseDefiningCode(String value, String description, String terminologyId,
         String code) {
      this.value = value;
      this.description = description;
      this.terminologyId = terminologyId;
      this.code = code;
   }

   public String getValue() {
      return this.value;
   }

   public String getDescription() {
      return this.description;
   }

   public String getTerminologyId() {
      return this.terminologyId;
   }

   public String getCode() {
      return this.code;
   }
}
