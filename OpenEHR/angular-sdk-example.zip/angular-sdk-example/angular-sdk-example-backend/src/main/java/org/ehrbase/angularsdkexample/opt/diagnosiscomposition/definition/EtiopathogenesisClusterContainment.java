package org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import org.ehrbase.openehr.sdk.generator.commons.aql.containment.Containment;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.AqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.ListAqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.ListSelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.SelectAqlField;

public class EtiopathogenesisClusterContainment extends Containment {
  public SelectAqlField<EtiopathogenesisCluster> ETIOPATHOGENESIS_CLUSTER = new AqlFieldImp<EtiopathogenesisCluster>(
      EtiopathogenesisCluster.class, "", "EtiopathogenesisCluster", EtiopathogenesisCluster.class, this);

  public ListSelectAqlField<EtiopathogenesisEtiologyOfTheDiseaseElement> ETIOLOGY_OF_THE_DISEASE = new ListAqlFieldImp<EtiopathogenesisEtiologyOfTheDiseaseElement>(
      EtiopathogenesisCluster.class, "/items[at0001]", "etiologyOfTheDisease",
      EtiopathogenesisEtiologyOfTheDiseaseElement.class, this);

  public ListSelectAqlField<EtiopathogenesisDescriptionOfTheCreationElement> DESCRIPTION_OF_THE_CREATION = new ListAqlFieldImp<EtiopathogenesisDescriptionOfTheCreationElement>(
      EtiopathogenesisCluster.class, "/items[at0017]", "descriptionOfTheCreation",
      EtiopathogenesisDescriptionOfTheCreationElement.class, this);

  public SelectAqlField<FeederAudit> FEEDER_AUDIT = new AqlFieldImp<FeederAudit>(EtiopathogenesisCluster.class,
      "/feeder_audit", "feederAudit", FeederAudit.class, this);

  private EtiopathogenesisClusterContainment() {
    super("openEHR-EHR-CLUSTER.etiology.v1");
  }

  public static EtiopathogenesisClusterContainment getInstance() {
    return new EtiopathogenesisClusterContainment();
  }
}
