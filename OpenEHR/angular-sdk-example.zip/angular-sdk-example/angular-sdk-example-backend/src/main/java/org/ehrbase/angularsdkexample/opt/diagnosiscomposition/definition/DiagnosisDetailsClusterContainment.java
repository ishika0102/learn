package org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import java.lang.Boolean;
import java.lang.String;
import org.ehrbase.openehr.sdk.generator.commons.aql.containment.Containment;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.AqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.SelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

public class DiagnosisDetailsClusterContainment extends Containment {
  public SelectAqlField<DiagnosisDetailsCluster> DIAGNOSIS_DETAILS_CLUSTER = new AqlFieldImp<DiagnosisDetailsCluster>(
      DiagnosisDetailsCluster.class, "", "DiagnosisDetailsCluster", DiagnosisDetailsCluster.class, this);

  public SelectAqlField<String> JUSTIFICATION_FOR_EXCEPTIONS_VALUE = new AqlFieldImp<String>(
      DiagnosisDetailsCluster.class, "/items[at0001]/value|value", "justificationForExceptionsValue", String.class,
      this);

  public SelectAqlField<NullFlavour> JUSTIFICATION_FOR_EXCEPTIONS_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      DiagnosisDetailsCluster.class, "/items[at0001]/null_flavour|defining_code",
      "justificationForExceptionsNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<String> DIAGNOSIS_TYPE_VALUE = new AqlFieldImp<String>(DiagnosisDetailsCluster.class,
      "/items[at0002]/value|value", "diagnosisTypeValue", String.class, this);

  public SelectAqlField<NullFlavour> DIAGNOSIS_TYPE_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      DiagnosisDetailsCluster.class, "/items[at0002]/null_flavour|defining_code",
      "diagnosisTypeNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<Boolean> AVAILABLE_AT_TIME_OF_RECORDING_VALUE = new AqlFieldImp<Boolean>(
      DiagnosisDetailsCluster.class, "/items[at0016]/value|value", "availableAtTimeOfRecordingValue", Boolean.class,
      this);

  public SelectAqlField<NullFlavour> AVAILABLE_AT_TIME_OF_RECORDING_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      DiagnosisDetailsCluster.class, "/items[at0016]/null_flavour|defining_code",
      "availableAtTimeOfRecordingNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<Boolean> PRESENT_AT_DISCHARGE_VALUE = new AqlFieldImp<Boolean>(DiagnosisDetailsCluster.class,
      "/items[at0017]/value|value", "presentAtDischargeValue", Boolean.class, this);

  public SelectAqlField<NullFlavour> PRESENT_AT_DISCHARGE_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      DiagnosisDetailsCluster.class, "/items[at0017]/null_flavour|defining_code",
      "presentAtDischargeNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<FeederAudit> FEEDER_AUDIT = new AqlFieldImp<FeederAudit>(DiagnosisDetailsCluster.class,
      "/feeder_audit", "feederAudit", FeederAudit.class, this);

  private DiagnosisDetailsClusterContainment() {
    super("openEHR-EHR-CLUSTER.diagnose_details.v0");
  }

  public static DiagnosisDetailsClusterContainment getInstance() {
    return new DiagnosisDetailsClusterContainment();
  }
}
