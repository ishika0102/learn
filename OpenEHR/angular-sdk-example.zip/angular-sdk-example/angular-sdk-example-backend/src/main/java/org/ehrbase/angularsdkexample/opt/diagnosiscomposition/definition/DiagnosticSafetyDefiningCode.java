package org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition;

import java.lang.String;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.EnumValueSet;

public enum DiagnosticSafetyDefiningCode implements EnumValueSet {
   PROBABLY("Probably", "The diagnosis was made with a high degree of certainty.", "local", "at0075"),

   CONFIRMED("Confirmed", "The diagnosis was confirmed using recognized criteria.", "local", "at0076"),

   SUSPECTED("Suspected", "The diagnosis was made with a low degree of certainty.", "local", "at0074");

   private String value;

   private String description;

   private String terminologyId;

   private String code;

   DiagnosticSafetyDefiningCode(String value, String description, String terminologyId,
         String code) {
      this.value = value;
      this.description = description;
      this.terminologyId = terminologyId;
      this.code = code;
   }

   public String getValue() {
      return this.value;
   }

   public String getDescription() {
      return this.description;
   }

   public String getTerminologyId() {
      return this.terminologyId;
   }

   public String getCode() {
      return this.code;
   }
}
