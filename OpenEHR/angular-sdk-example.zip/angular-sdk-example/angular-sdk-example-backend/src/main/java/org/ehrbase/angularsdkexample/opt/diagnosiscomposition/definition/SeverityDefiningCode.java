package org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition;

import java.lang.String;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.EnumValueSet;

public enum SeverityDefiningCode implements EnumValueSet {
   HARD("Hard",
         "The problem or diagnosis prevents normal activity or causes serious health problems if left untreated.",
         "local", "at0049"),

   MODERATE("Moderate",
         "The problem or diagnosis interferes with normal activity or causes permanent health problems if not treated.",
         "local", "at0048"),

   EASY("Easy",
         "The problem or diagnosis does not interfere with normal activity or cause permanent harm if left untreated.",
         "local", "at0047");

   private String value;

   private String description;

   private String terminologyId;

   private String code;

   SeverityDefiningCode(String value, String description, String terminologyId, String code) {
      this.value = value;
      this.description = description;
      this.terminologyId = terminologyId;
      this.code = code;
   }

   public String getValue() {
      return this.value;
   }

   public String getDescription() {
      return this.description;
   }

   public String getTerminologyId() {
      return this.terminologyId;
   }

   public String getCode() {
      return this.code;
   }
}
