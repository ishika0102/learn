package org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import java.lang.Boolean;
import java.lang.String;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Archetype;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Archetype("openEHR-EHR-CLUSTER.diagnose_details.v0")
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-16T13:15:12.199070413+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class DiagnosisDetailsCluster implements LocatableEntity {
   /**
    * Path: Diagnosis/Problem/Diagnosis/Diagnosis details/Justification for
    * exceptions
    * Description: The occurrence of a diagnosis must in some cases be justified
    * for billing purposes, e.g. for gender-specific plausibility checks.
    */
   @Path("/items[at0001]/value|value")
   private String justificationForExceptionsValue;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Structure/Diagnosis details/Justification
    * for exceptions/null_flavour
    */
   @Path("/items[at0001]/null_flavour|defining_code")
   private NullFlavour justificationForExceptionsNullFlavourDefiningCode;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Diagnosis details/Diagnosis type
    * Description: Type of diagnosis. When specifying the diagnosis type, it is
    * important to ensure that it is used in the correct context. For example, when
    * describing a diagnosis as part of a referral, there will not be a diagnosis
    * type of "discharge diagnosis".
    */
   @Path("/items[at0002]/value|value")
   private String diagnosisTypeValue;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Structure/Diagnosis details/Diagnosis
    * type/null_flavour
    */
   @Path("/items[at0002]/null_flavour|defining_code")
   private NullFlavour diagnosisTypeNullFlavourDefiningCode;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Diagnosis details/Available at time of
    * recording
    * Description: Is the diagnosis present upon admission to the health facility?
    */
   @Path("/items[at0016]/value|value")
   private Boolean availableAtTimeOfRecordingValue;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Structure/Diagnosis details/Available at
    * time of recording/null_flavour
    */
   @Path("/items[at0016]/null_flavour|defining_code")
   private NullFlavour availableAtTimeOfRecordingNullFlavourDefiningCode;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Diagnosis details/Present at discharge
    * Description: Is the diagnosis present upon discharge from the health
    * facility?
    */
   @Path("/items[at0017]/value|value")
   private Boolean presentAtDischargeValue;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Structure/Diagnosis details/Present at
    * discharge/null_flavour
    */
   @Path("/items[at0017]/null_flavour|defining_code")
   private NullFlavour presentAtDischargeNullFlavourDefiningCode;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Diagnosis details/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   public void setJustificationForExceptionsValue(String justificationForExceptionsValue) {
      this.justificationForExceptionsValue = justificationForExceptionsValue;
   }

   public String getJustificationForExceptionsValue() {
      return this.justificationForExceptionsValue;
   }

   public void setJustificationForExceptionsNullFlavourDefiningCode(
         NullFlavour justificationForExceptionsNullFlavourDefiningCode) {
      this.justificationForExceptionsNullFlavourDefiningCode = justificationForExceptionsNullFlavourDefiningCode;
   }

   public NullFlavour getJustificationForExceptionsNullFlavourDefiningCode() {
      return this.justificationForExceptionsNullFlavourDefiningCode;
   }

   public void setDiagnosisTypeValue(String diagnosisTypeValue) {
      this.diagnosisTypeValue = diagnosisTypeValue;
   }

   public String getDiagnosisTypeValue() {
      return this.diagnosisTypeValue;
   }

   public void setDiagnosisTypeNullFlavourDefiningCode(
         NullFlavour diagnosisTypeNullFlavourDefiningCode) {
      this.diagnosisTypeNullFlavourDefiningCode = diagnosisTypeNullFlavourDefiningCode;
   }

   public NullFlavour getDiagnosisTypeNullFlavourDefiningCode() {
      return this.diagnosisTypeNullFlavourDefiningCode;
   }

   public void setAvailableAtTimeOfRecordingValue(Boolean availableAtTimeOfRecordingValue) {
      this.availableAtTimeOfRecordingValue = availableAtTimeOfRecordingValue;
   }

   public Boolean isAvailableAtTimeOfRecordingValue() {
      return this.availableAtTimeOfRecordingValue;
   }

   public void setAvailableAtTimeOfRecordingNullFlavourDefiningCode(
         NullFlavour availableAtTimeOfRecordingNullFlavourDefiningCode) {
      this.availableAtTimeOfRecordingNullFlavourDefiningCode = availableAtTimeOfRecordingNullFlavourDefiningCode;
   }

   public NullFlavour getAvailableAtTimeOfRecordingNullFlavourDefiningCode() {
      return this.availableAtTimeOfRecordingNullFlavourDefiningCode;
   }

   public void setPresentAtDischargeValue(Boolean presentAtDischargeValue) {
      this.presentAtDischargeValue = presentAtDischargeValue;
   }

   public Boolean isPresentAtDischargeValue() {
      return this.presentAtDischargeValue;
   }

   public void setPresentAtDischargeNullFlavourDefiningCode(
         NullFlavour presentAtDischargeNullFlavourDefiningCode) {
      this.presentAtDischargeNullFlavourDefiningCode = presentAtDischargeNullFlavourDefiningCode;
   }

   public NullFlavour getPresentAtDischargeNullFlavourDefiningCode() {
      return this.presentAtDischargeNullFlavourDefiningCode;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }
}
