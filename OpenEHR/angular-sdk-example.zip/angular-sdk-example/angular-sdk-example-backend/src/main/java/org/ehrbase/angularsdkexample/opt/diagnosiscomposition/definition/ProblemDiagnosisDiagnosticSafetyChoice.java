package org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition;

import javax.annotation.processing.Generated;

@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-16T13:15:12.222770660+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public interface ProblemDiagnosisDiagnosticSafetyChoice {
}
