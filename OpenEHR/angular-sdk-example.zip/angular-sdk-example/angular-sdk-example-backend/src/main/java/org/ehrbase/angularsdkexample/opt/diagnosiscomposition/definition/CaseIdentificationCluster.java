package org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import java.lang.String;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Archetype;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Archetype("openEHR-EHR-CLUSTER.case_identification.v0")
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-16T13:15:12.180361820+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class CaseIdentificationCluster implements LocatableEntity {
   /**
    * Path: Diagnosis/context/Case identification/Case ID
    * Description: The identifier of this case.
    */
   @Path("/items[at0001]/value|value")
   private String caseIdValue;

   /**
    * Path: Diagnosis/context/Tree/Case identification/Case ID/null_flavour
    */
   @Path("/items[at0001]/null_flavour|defining_code")
   private NullFlavour caseIdNullFlavourDefiningCode;

   /**
    * Path: Diagnosis/context/Case identification/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   public void setCaseIdValue(String caseIdValue) {
      this.caseIdValue = caseIdValue;
   }

   public String getCaseIdValue() {
      return this.caseIdValue;
   }

   public void setCaseIdNullFlavourDefiningCode(NullFlavour caseIdNullFlavourDefiningCode) {
      this.caseIdNullFlavourDefiningCode = caseIdNullFlavourDefiningCode;
   }

   public NullFlavour getCaseIdNullFlavourDefiningCode() {
      return this.caseIdNullFlavourDefiningCode;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }
}
