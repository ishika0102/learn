package org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition;

import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-16T13:15:12.204483861+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_CODED_TEXT")
public class EtiopathogenesisEtiologyOfTheDiseaseDvCodedText
    implements RMEntity, EtiopathogenesisEtiologyOfTheDiseaseChoice {
  /**
   * Path: Diagnosis/Problem/Diagnosis/Etiopathogenesis/Etiology of the
   * disease/Etiology of the disease
   * Description: Identification of the cause of the disease or abnormal
   * condition.
   * Comment: This could be another disease, an unhealthy behavior, a gene, or
   * another root cause of the disease the patient has.
   * It is possible to repeat this element for a disease that has multiple causes.
   * Where possible, coding this element via a terminology database is preferable.
   * Examples of input could be: alcoholism (in liver cirrhosis), diabetes
   * mellitus (in chronic kidney disease), respiratory infection (in fever) or
   * smoking (in lung cancer).
   */
  @Path("|defining_code")
  private EtiologyOfTheDiseaseDefiningCode etiologyOfTheDiseaseDefiningCode;

  public void setEtiologyOfTheDiseaseDefiningCode(
      EtiologyOfTheDiseaseDefiningCode etiologyOfTheDiseaseDefiningCode) {
    this.etiologyOfTheDiseaseDefiningCode = etiologyOfTheDiseaseDefiningCode;
  }

  public EtiologyOfTheDiseaseDefiningCode getEtiologyOfTheDiseaseDefiningCode() {
    return this.etiologyOfTheDiseaseDefiningCode;
  }
}
