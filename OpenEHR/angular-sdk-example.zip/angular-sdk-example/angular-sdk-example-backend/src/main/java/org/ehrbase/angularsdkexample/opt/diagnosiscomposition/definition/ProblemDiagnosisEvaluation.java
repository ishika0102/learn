package org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import com.nedap.archie.rm.datastructures.Cluster;
import com.nedap.archie.rm.generic.PartyProxy;
import java.lang.String;
import java.time.temporal.TemporalAccessor;
import java.util.List;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Archetype;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Choice;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.EntryEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.Language;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Archetype("openEHR-EHR-EVALUATION.problem_diagnosis.v1")
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-16T13:15:12.187125476+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class ProblemDiagnosisEvaluation implements EntryEntity {
   /**
    * Path: Diagnosis/Problem/Diagnosis/Name of problem/diagnosis
    * Description: Name identification of the problem or diagnosis.
    * Comment: Where possible, coding of the problem or diagnosis over terminology
    * is preferable.
    */
   @Path("/data[at0001]/items[at0002]/value|value")
   private String nameOfProblemDiagnosisValue;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Structure/Name of
    * problem/diagnosis/null_flavour
    */
   @Path("/data[at0001]/items[at0002]/null_flavour|defining_code")
   private NullFlavour nameOfProblemDiagnosisNullFlavourDefiningCode;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Free text description
    * Description: Description of the problem or diagnosis.
    * Comment: Used to provide background and context, including evolution,
    * episodes or worsening, progress, and other relevant details about the problem
    * or diagnosis.
    */
   @Path("/data[at0001]/items[at0009 and name/value='Free text description']/value|value")
   private String freeTextDescriptionValue;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Structure/Free text
    * description/null_flavour
    */
   @Path("/data[at0001]/items[at0009 and name/value='Free text description']/null_flavour|defining_code")
   private NullFlavour freeTextDescriptionNullFlavourDefiningCode;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Localization
    * Description: Identification of a simple body part to localize the problem or
    * diagnosis.
    * Comment: Where possible, coding of the anatomical location using a
    * terminology is preferable. Use this data element to record pre-coordinated
    * anatomical locations. If the requirements for recordingthe anatomical
    * location is to be determined at runtime by the application or more complex
    * modelling, such as relative locations, is required, then use the
    * CLUSTER.anatomical_location or CLUSTER.relative_location within the SLOT
    * 'Structured anatomical location' in this archetype. The number of this data
    * element is unlimited to allow clinical scenarios such as describing a rash in
    * multiple locations, but with all other attributes being identical. If the
    * anatomical location is included in the name of the problem/diagnosis via
    * precoordinated codes, this data element becomes redundant.
    */
   @Path("/data[at0001]/items[at0012 and name/value='Localization']/value|value")
   private String localizationValue;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Structure/Localization/null_flavour
    */
   @Path("/data[at0001]/items[at0012 and name/value='Localization']/null_flavour|defining_code")
   private NullFlavour localizationNullFlavourDefiningCode;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Anatomical location
    * Description: A physical location on or within the human body.
    */
   @Path("/data[at0001]/items[openEHR-EHR-CLUSTER.anatomical_location.v1]")
   private List<AnatomicalLocationCluster> anatomicalLocation;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Date of onset/first diagnosis
    * Description: Estimated or exact time (or date) when the signs or symptoms
    * were first observed.
    * Comment: Date values ​​captured/imported as "age at start" should be
    * converted to a date based on the person's date of birth.
    */
   @Path("/data[at0001]/items[at0077 and name/value='Date of onset/first diagnosis']/value|value")
   private TemporalAccessor dateOfOnsetFirstDiagnosisValue;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Structure/Date of onset/first
    * diagnosis/null_flavour
    */
   @Path("/data[at0001]/items[at0077 and name/value='Date of onset/first diagnosis']/null_flavour|defining_code")
   private NullFlavour dateOfOnsetFirstDiagnosisNullFlavourDefiningCode;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Date of determination
    * Description: Estimated or exact time (or date) when the diagnosis or problem
    * was determined by a healthcare professional.
    * Comment: Incomplete dates are acceptable. If the patient is under one year
    * old, then the full date or a minimum of the month and year is necessary to
    * enable accurate age calculations - e.g. when used for decision support. Date
    * values ​​captured/imported as "age at clinical assessment" should be
    * converted to a date using the person's date of birth.
    */
   @Path("/data[at0001]/items[at0003 and name/value='Date of determination']/value|value")
   private TemporalAccessor dateOfDeterminationValue;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Structure/Date of
    * determination/null_flavour
    */
   @Path("/data[at0001]/items[at0003 and name/value='Date of determination']/null_flavour|defining_code")
   private NullFlavour dateOfDeterminationNullFlavourDefiningCode;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Structure/Severity/null_flavour
    */
   @Path("/data[at0001]/items[at0005]/null_flavour|defining_code")
   private NullFlavour severityNullFlavourDefiningCode;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Diagnosis details
    * Description: Diagnosis-related information.
    */
   @Path("/data[at0001]/items[openEHR-EHR-CLUSTER.diagnose_details.v0]")
   private DiagnosisDetailsCluster diagnosisDetails;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Etiopathogenesis
    * Description: The causes, reasons or explanation for the emergence of a
    * particular problem/diagnosis, its triggering factors and development.
    */
   @Path("/data[at0001]/items[openEHR-EHR-CLUSTER.etiology.v1]")
   private EtiopathogenesisCluster etiopathogenesis;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Date/time of recovery
    * Description: Estimated or exact time (or date) when recovery or remission of
    * the problem or diagnosis was determined by a healthcare professional.
    * Comment: Incomplete dates are acceptable. If the patient is under one year
    * old, then the full date or a minimum of the month and year is necessary to
    * enable accurate age calculations - e.g. when used for decision support. Date
    * values ​​captured/imported as "age at recovery" should be converted to a date
    * using the person's date of birth.
    */
   @Path("/data[at0001]/items[at0030]/value|value")
   private TemporalAccessor dateTimeOfRecoveryValue;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Structure/Date/time of
    * recovery/null_flavour
    */
   @Path("/data[at0001]/items[at0030]/null_flavour|defining_code")
   private NullFlavour dateTimeOfRecoveryNullFlavourDefiningCode;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Status
    * Description: Structured information on site-, domain-, episode- or
    * workflow-specific aspects of the diagnostic process.
    * Comment: Use status or context features with caution, as they are used
    * variably in practice and interoperability cannot be guaranteed unless their
    * use is clearly agreed upon with the user community. Example:active status -
    * active, inactive, recovered, in remission; developmental status - initial,
    * interim/working, final; temporal status - current, past; episode status -
    * initial, new, ongoing; admission status - admission, discharge; or priority
    * status - primary, secondary.
    */
   @Path("/data[at0001]/items[at0046]")
   private List<Cluster> status;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Structure/Diagnostic Safety/null_flavour
    */
   @Path("/data[at0001]/items[at0073]/null_flavour|defining_code")
   private NullFlavour diagnosticSafetyNullFlavourDefiningCode;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Diagnosis explanation
    * Description: Additional description of the problem or diagnosis not otherwise
    * recorded.
    */
   @Path("/data[at0001]/items[at0069 and name/value='Diagnosis explanation']/value|value")
   private String diagnosisExplanationValue;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Structure/Diagnosis
    * explanation/null_flavour
    */
   @Path("/data[at0001]/items[at0069 and name/value='Diagnosis explanation']/null_flavour|defining_code")
   private NullFlavour diagnosisExplanationNullFlavourDefiningCode;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Last Documentation Date
    * Description: Date the diagnosis or problem was last updated.
    */
   @Path("/protocol[at0032]/items[at0070 and name/value='Last Documentation Date']/value|value")
   private TemporalAccessor lastDocumentationDateValue;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Tree/Last Documentation Date/null_flavour
    */
   @Path("/protocol[at0032]/items[at0070 and name/value='Last Documentation Date']/null_flavour|defining_code")
   private NullFlavour lastDocumentationDateNullFlavourDefiningCode;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Extension
    * Description: Additional information for capturing local content or adapting
    * to other reference models/formalisms.
    * Comment: For example: local information needs or additional metadata to adapt
    * to FHIR resources or CIMI models.
    */
   @Path("/protocol[at0032]/items[at0071]")
   private List<Cluster> extension;

   /**
    * Path: Diagnosis/Problem/Diagnosis/subject
    */
   @Path("/subject")
   private PartyProxy subject;

   /**
    * Path: Diagnosis/Problem/Diagnosis/language
    */
   @Path("/language")
   private Language language;

   /**
    * Path: Diagnosis/Problem/Diagnosis/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Diagnostic Safety
    * Description: Degree of certainty with which the diagnosis was made.
    */
   @Path("/data[at0001]/items[at0073]/value")
   @Choice
   private ProblemDiagnosisDiagnosticSafetyChoice diagnosticSafety;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Severity
    * Description: An overall assessment of the severity of the problem or
    * diagnosis.
    * Comment: If the severity is contained in the "Problem/Diagnosis Name" element
    * using predefined codes, this data element is superfluous. Note: A more
    * specific severity classification can be specified using the "Specific
    * Information" SLOT.
    */
   @Path("/data[at0001]/items[at0005]/value")
   @Choice
   private ProblemDiagnosisSeverityChoice severity;

   public void setNameOfProblemDiagnosisValue(String nameOfProblemDiagnosisValue) {
      this.nameOfProblemDiagnosisValue = nameOfProblemDiagnosisValue;
   }

   public String getNameOfProblemDiagnosisValue() {
      return this.nameOfProblemDiagnosisValue;
   }

   public void setNameOfProblemDiagnosisNullFlavourDefiningCode(
         NullFlavour nameOfProblemDiagnosisNullFlavourDefiningCode) {
      this.nameOfProblemDiagnosisNullFlavourDefiningCode = nameOfProblemDiagnosisNullFlavourDefiningCode;
   }

   public NullFlavour getNameOfProblemDiagnosisNullFlavourDefiningCode() {
      return this.nameOfProblemDiagnosisNullFlavourDefiningCode;
   }

   public void setFreeTextDescriptionValue(String freeTextDescriptionValue) {
      this.freeTextDescriptionValue = freeTextDescriptionValue;
   }

   public String getFreeTextDescriptionValue() {
      return this.freeTextDescriptionValue;
   }

   public void setFreeTextDescriptionNullFlavourDefiningCode(
         NullFlavour freeTextDescriptionNullFlavourDefiningCode) {
      this.freeTextDescriptionNullFlavourDefiningCode = freeTextDescriptionNullFlavourDefiningCode;
   }

   public NullFlavour getFreeTextDescriptionNullFlavourDefiningCode() {
      return this.freeTextDescriptionNullFlavourDefiningCode;
   }

   public void setLocalizationValue(String localizationValue) {
      this.localizationValue = localizationValue;
   }

   public String getLocalizationValue() {
      return this.localizationValue;
   }

   public void setLocalizationNullFlavourDefiningCode(
         NullFlavour localizationNullFlavourDefiningCode) {
      this.localizationNullFlavourDefiningCode = localizationNullFlavourDefiningCode;
   }

   public NullFlavour getLocalizationNullFlavourDefiningCode() {
      return this.localizationNullFlavourDefiningCode;
   }

   public void setAnatomicalLocation(List<AnatomicalLocationCluster> anatomicalLocation) {
      this.anatomicalLocation = anatomicalLocation;
   }

   public List<AnatomicalLocationCluster> getAnatomicalLocation() {
      return this.anatomicalLocation;
   }

   public void setDateOfOnsetFirstDiagnosisValue(TemporalAccessor dateOfOnsetFirstDiagnosisValue) {
      this.dateOfOnsetFirstDiagnosisValue = dateOfOnsetFirstDiagnosisValue;
   }

   public TemporalAccessor getDateOfOnsetFirstDiagnosisValue() {
      return this.dateOfOnsetFirstDiagnosisValue;
   }

   public void setDateOfOnsetFirstDiagnosisNullFlavourDefiningCode(
         NullFlavour dateOfOnsetFirstDiagnosisNullFlavourDefiningCode) {
      this.dateOfOnsetFirstDiagnosisNullFlavourDefiningCode = dateOfOnsetFirstDiagnosisNullFlavourDefiningCode;
   }

   public NullFlavour getDateOfOnsetFirstDiagnosisNullFlavourDefiningCode() {
      return this.dateOfOnsetFirstDiagnosisNullFlavourDefiningCode;
   }

   public void setDateOfDeterminationValue(TemporalAccessor dateOfDeterminationValue) {
      this.dateOfDeterminationValue = dateOfDeterminationValue;
   }

   public TemporalAccessor getDateOfDeterminationValue() {
      return this.dateOfDeterminationValue;
   }

   public void setDateOfDeterminationNullFlavourDefiningCode(
         NullFlavour dateOfDeterminationNullFlavourDefiningCode) {
      this.dateOfDeterminationNullFlavourDefiningCode = dateOfDeterminationNullFlavourDefiningCode;
   }

   public NullFlavour getDateOfDeterminationNullFlavourDefiningCode() {
      return this.dateOfDeterminationNullFlavourDefiningCode;
   }

   public void setSeverityNullFlavourDefiningCode(NullFlavour severityNullFlavourDefiningCode) {
      this.severityNullFlavourDefiningCode = severityNullFlavourDefiningCode;
   }

   public NullFlavour getSeverityNullFlavourDefiningCode() {
      return this.severityNullFlavourDefiningCode;
   }

   public void setDiagnosisDetails(DiagnosisDetailsCluster diagnosisDetails) {
      this.diagnosisDetails = diagnosisDetails;
   }

   public DiagnosisDetailsCluster getDiagnosisDetails() {
      return this.diagnosisDetails;
   }

   public void setEtiopathogenesis(EtiopathogenesisCluster etiopathogenesis) {
      this.etiopathogenesis = etiopathogenesis;
   }

   public EtiopathogenesisCluster getEtiopathogenesis() {
      return this.etiopathogenesis;
   }

   public void setDateTimeOfRecoveryValue(TemporalAccessor dateTimeOfRecoveryValue) {
      this.dateTimeOfRecoveryValue = dateTimeOfRecoveryValue;
   }

   public TemporalAccessor getDateTimeOfRecoveryValue() {
      return this.dateTimeOfRecoveryValue;
   }

   public void setDateTimeOfRecoveryNullFlavourDefiningCode(
         NullFlavour dateTimeOfRecoveryNullFlavourDefiningCode) {
      this.dateTimeOfRecoveryNullFlavourDefiningCode = dateTimeOfRecoveryNullFlavourDefiningCode;
   }

   public NullFlavour getDateTimeOfRecoveryNullFlavourDefiningCode() {
      return this.dateTimeOfRecoveryNullFlavourDefiningCode;
   }

   public void setStatus(List<Cluster> status) {
      this.status = status;
   }

   public List<Cluster> getStatus() {
      return this.status;
   }

   public void setDiagnosticSafetyNullFlavourDefiningCode(
         NullFlavour diagnosticSafetyNullFlavourDefiningCode) {
      this.diagnosticSafetyNullFlavourDefiningCode = diagnosticSafetyNullFlavourDefiningCode;
   }

   public NullFlavour getDiagnosticSafetyNullFlavourDefiningCode() {
      return this.diagnosticSafetyNullFlavourDefiningCode;
   }

   public void setDiagnosisExplanationValue(String diagnosisExplanationValue) {
      this.diagnosisExplanationValue = diagnosisExplanationValue;
   }

   public String getDiagnosisExplanationValue() {
      return this.diagnosisExplanationValue;
   }

   public void setDiagnosisExplanationNullFlavourDefiningCode(
         NullFlavour diagnosisExplanationNullFlavourDefiningCode) {
      this.diagnosisExplanationNullFlavourDefiningCode = diagnosisExplanationNullFlavourDefiningCode;
   }

   public NullFlavour getDiagnosisExplanationNullFlavourDefiningCode() {
      return this.diagnosisExplanationNullFlavourDefiningCode;
   }

   public void setLastDocumentationDateValue(TemporalAccessor lastDocumentationDateValue) {
      this.lastDocumentationDateValue = lastDocumentationDateValue;
   }

   public TemporalAccessor getLastDocumentationDateValue() {
      return this.lastDocumentationDateValue;
   }

   public void setLastDocumentationDateNullFlavourDefiningCode(
         NullFlavour lastDocumentationDateNullFlavourDefiningCode) {
      this.lastDocumentationDateNullFlavourDefiningCode = lastDocumentationDateNullFlavourDefiningCode;
   }

   public NullFlavour getLastDocumentationDateNullFlavourDefiningCode() {
      return this.lastDocumentationDateNullFlavourDefiningCode;
   }

   public void setExtension(List<Cluster> extension) {
      this.extension = extension;
   }

   public List<Cluster> getExtension() {
      return this.extension;
   }

   public void setSubject(PartyProxy subject) {
      this.subject = subject;
   }

   public PartyProxy getSubject() {
      return this.subject;
   }

   public void setLanguage(Language language) {
      this.language = language;
   }

   public Language getLanguage() {
      return this.language;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }

   public void setDiagnosticSafety(ProblemDiagnosisDiagnosticSafetyChoice diagnosticSafety) {
      this.diagnosticSafety = diagnosticSafety;
   }

   public ProblemDiagnosisDiagnosticSafetyChoice getDiagnosticSafety() {
      return this.diagnosticSafety;
   }

   public void setSeverity(ProblemDiagnosisSeverityChoice severity) {
      this.severity = severity;
   }

   public ProblemDiagnosisSeverityChoice getSeverity() {
      return this.severity;
   }
}
