package org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import com.nedap.archie.rm.datastructures.Cluster;
import java.lang.String;
import java.util.List;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Archetype;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Archetype("openEHR-EHR-CLUSTER.anatomical_location.v1")
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-16T13:15:12.191528720+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class AnatomicalLocationCluster implements LocatableEntity {
   /**
    * Path: Diagnosis/Problem/Diagnosis/Anatomical location/Name of body part
    * Description: Identification of a single physical location either on or within
    * the human body.
    * Comment: This data element is the only required data point in this archetype
    * and should be used as the primary data point to record an anatomical location
    * with a commonly used name. It is strongly recommended that the name of the
    * body location be recorded as accurately as is anatomically possible. For
    * example: record "upper eyelid" rather than "eyelid" with "upper" as the
    * qualifier; "fifth rib" rather than "rib" with a numeric qualifier. UseUse the
    * other data elements for laterality, viewpoint, region, and anatomical line to
    * provide more details.
    *
    * This data element should be coded using terminology that can, where possible,
    * trigger decision support - an appropriate term set for use here could be
    * composed of individual concepts or a list of pre-agreed terms. Free text
    * should only be used if appropriate terminology is not available.
    *
    * If the body part name is already specified in the parent archetype, this data
    * element may be redundant. Alternatively, a use case has been identified where
    * the value could be duplicated in this element to support semantic queries
    * using this archetype rather than the data element within the parent element.
    */
   @Path("/items[at0001]/value|value")
   private String nameOfBodyPartValue;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Structure/Anatomical location/Name of body
    * part/null_flavour
    */
   @Path("/items[at0001]/null_flavour|defining_code")
   private NullFlavour nameOfBodyPartNullFlavourDefiningCode;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Anatomical location/Laterality
    * Description: The side of the body where the identified body part is located.
    * Comment: If the identified body part does not have a lateral location, this
    * data element should have no value. If the body part name data element uses
    * precoordinate labels that include a lateral location, then this data element
    * is redundant.
    */
   @Path("/items[at0002]/value|defining_code")
   private LateralityDefiningCode lateralityDefiningCode;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Structure/Anatomical
    * location/Laterality/null_flavour
    */
   @Path("/items[at0002]/null_flavour|defining_code")
   private NullFlavour lateralityNullFlavourDefiningCode;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Anatomical location/Alternative structure
    * Description: Additional information about the anatomical location with
    * alternative approaches to describing the same body part.
    * Comment: For example, relative or exact positions using coordinates.
    */
   @Path("/items[at0053]")
   private List<Cluster> alternativeStructure;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Anatomical location/Multimedia presentation
    * Description: Images or other media used to identify the body part.
    */
   @Path("/items[at0054]")
   private List<Cluster> multimediaPresentation;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Anatomical location/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   public void setNameOfBodyPartValue(String nameOfBodyPartValue) {
      this.nameOfBodyPartValue = nameOfBodyPartValue;
   }

   public String getNameOfBodyPartValue() {
      return this.nameOfBodyPartValue;
   }

   public void setNameOfBodyPartNullFlavourDefiningCode(
         NullFlavour nameOfBodyPartNullFlavourDefiningCode) {
      this.nameOfBodyPartNullFlavourDefiningCode = nameOfBodyPartNullFlavourDefiningCode;
   }

   public NullFlavour getNameOfBodyPartNullFlavourDefiningCode() {
      return this.nameOfBodyPartNullFlavourDefiningCode;
   }

   public void setLateralityDefiningCode(LateralityDefiningCode lateralityDefiningCode) {
      this.lateralityDefiningCode = lateralityDefiningCode;
   }

   public LateralityDefiningCode getLateralityDefiningCode() {
      return this.lateralityDefiningCode;
   }

   public void setLateralityNullFlavourDefiningCode(NullFlavour lateralityNullFlavourDefiningCode) {
      this.lateralityNullFlavourDefiningCode = lateralityNullFlavourDefiningCode;
   }

   public NullFlavour getLateralityNullFlavourDefiningCode() {
      return this.lateralityNullFlavourDefiningCode;
   }

   public void setAlternativeStructure(List<Cluster> alternativeStructure) {
      this.alternativeStructure = alternativeStructure;
   }

   public List<Cluster> getAlternativeStructure() {
      return this.alternativeStructure;
   }

   public void setMultimediaPresentation(List<Cluster> multimediaPresentation) {
      this.multimediaPresentation = multimediaPresentation;
   }

   public List<Cluster> getMultimediaPresentation() {
      return this.multimediaPresentation;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }
}
