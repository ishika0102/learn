package org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition;

import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-16T13:15:12.224398128+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_CODED_TEXT")
public class ProblemDiagnosisSeverityDvCodedText implements RMEntity, ProblemDiagnosisSeverityChoice {
   /**
    * Path: Diagnosis/Problem/Diagnosis/Severity/Severity
    * Description: An overall assessment of the severity of the problem or
    * diagnosis.
    * Comment: If the severity is contained in the "Problem/Diagnosis Name" element
    * using predefined codes, this data element is superfluous. Note: A more
    * specific severity classification can be specified using the "Specific
    * Information" SLOT.
    */
   @Path("|defining_code")
   private SeverityDefiningCode severityDefiningCode;

   public void setSeverityDefiningCode(SeverityDefiningCode severityDefiningCode) {
      this.severityDefiningCode = severityDefiningCode;
   }

   public SeverityDefiningCode getSeverityDefiningCode() {
      return this.severityDefiningCode;
   }
}
