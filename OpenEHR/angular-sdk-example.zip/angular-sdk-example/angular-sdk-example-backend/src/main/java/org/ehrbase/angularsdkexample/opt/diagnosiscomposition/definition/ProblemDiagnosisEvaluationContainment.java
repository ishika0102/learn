package org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import com.nedap.archie.rm.datastructures.Cluster;
import com.nedap.archie.rm.generic.PartyProxy;
import java.lang.String;
import java.time.temporal.TemporalAccessor;
import org.ehrbase.openehr.sdk.generator.commons.aql.containment.Containment;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.AqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.ListAqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.ListSelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.SelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.Language;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

public class ProblemDiagnosisEvaluationContainment extends Containment {
  public SelectAqlField<ProblemDiagnosisEvaluation> PROBLEM_DIAGNOSIS_EVALUATION = new AqlFieldImp<ProblemDiagnosisEvaluation>(
      ProblemDiagnosisEvaluation.class, "", "ProblemDiagnosisEvaluation", ProblemDiagnosisEvaluation.class, this);

  public SelectAqlField<String> NAME_OF_PROBLEM_DIAGNOSIS_VALUE = new AqlFieldImp<String>(
      ProblemDiagnosisEvaluation.class, "/data[at0001]/items[at0002]/value|value", "nameOfProblemDiagnosisValue",
      String.class, this);

  public SelectAqlField<NullFlavour> NAME_OF_PROBLEM_DIAGNOSIS_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      ProblemDiagnosisEvaluation.class, "/data[at0001]/items[at0002]/null_flavour|defining_code",
      "nameOfProblemDiagnosisNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<String> FREE_TEXT_DESCRIPTION_VALUE = new AqlFieldImp<String>(ProblemDiagnosisEvaluation.class,
      "/data[at0001]/items[at0009]/value|value", "freeTextDescriptionValue", String.class, this);

  public SelectAqlField<NullFlavour> FREE_TEXT_DESCRIPTION_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      ProblemDiagnosisEvaluation.class, "/data[at0001]/items[at0009]/null_flavour|defining_code",
      "freeTextDescriptionNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<String> LOCALIZATION_VALUE = new AqlFieldImp<String>(ProblemDiagnosisEvaluation.class,
      "/data[at0001]/items[at0012]/value|value", "localizationValue", String.class, this);

  public SelectAqlField<NullFlavour> LOCALIZATION_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      ProblemDiagnosisEvaluation.class, "/data[at0001]/items[at0012]/null_flavour|defining_code",
      "localizationNullFlavourDefiningCode", NullFlavour.class, this);

  public ListSelectAqlField<AnatomicalLocationCluster> ANATOMICAL_LOCATION = new ListAqlFieldImp<AnatomicalLocationCluster>(
      ProblemDiagnosisEvaluation.class, "/data[at0001]/items[openEHR-EHR-CLUSTER.anatomical_location.v1]",
      "anatomicalLocation", AnatomicalLocationCluster.class, this);

  public SelectAqlField<TemporalAccessor> DATE_OF_ONSET_FIRST_DIAGNOSIS_VALUE = new AqlFieldImp<TemporalAccessor>(
      ProblemDiagnosisEvaluation.class, "/data[at0001]/items[at0077]/value|value", "dateOfOnsetFirstDiagnosisValue",
      TemporalAccessor.class, this);

  public SelectAqlField<NullFlavour> DATE_OF_ONSET_FIRST_DIAGNOSIS_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      ProblemDiagnosisEvaluation.class, "/data[at0001]/items[at0077]/null_flavour|defining_code",
      "dateOfOnsetFirstDiagnosisNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<TemporalAccessor> DATE_OF_DETERMINATION_VALUE = new AqlFieldImp<TemporalAccessor>(
      ProblemDiagnosisEvaluation.class, "/data[at0001]/items[at0003]/value|value", "dateOfDeterminationValue",
      TemporalAccessor.class, this);

  public SelectAqlField<NullFlavour> DATE_OF_DETERMINATION_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      ProblemDiagnosisEvaluation.class, "/data[at0001]/items[at0003]/null_flavour|defining_code",
      "dateOfDeterminationNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<NullFlavour> SEVERITY_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      ProblemDiagnosisEvaluation.class, "/data[at0001]/items[at0005]/null_flavour|defining_code",
      "severityNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<DiagnosisDetailsCluster> DIAGNOSIS_DETAILS = new AqlFieldImp<DiagnosisDetailsCluster>(
      ProblemDiagnosisEvaluation.class, "/data[at0001]/items[openEHR-EHR-CLUSTER.diagnose_details.v0]",
      "diagnosisDetails", DiagnosisDetailsCluster.class, this);

  public SelectAqlField<EtiopathogenesisCluster> ETIOPATHOGENESIS = new AqlFieldImp<EtiopathogenesisCluster>(
      ProblemDiagnosisEvaluation.class, "/data[at0001]/items[openEHR-EHR-CLUSTER.etiology.v1]", "etiopathogenesis",
      EtiopathogenesisCluster.class, this);

  public SelectAqlField<TemporalAccessor> DATE_TIME_OF_RECOVERY_VALUE = new AqlFieldImp<TemporalAccessor>(
      ProblemDiagnosisEvaluation.class, "/data[at0001]/items[at0030]/value|value", "dateTimeOfRecoveryValue",
      TemporalAccessor.class, this);

  public SelectAqlField<NullFlavour> DATE_TIME_OF_RECOVERY_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      ProblemDiagnosisEvaluation.class, "/data[at0001]/items[at0030]/null_flavour|defining_code",
      "dateTimeOfRecoveryNullFlavourDefiningCode", NullFlavour.class, this);

  public ListSelectAqlField<Cluster> STATUS = new ListAqlFieldImp<Cluster>(ProblemDiagnosisEvaluation.class,
      "/data[at0001]/items[at0046]", "status", Cluster.class, this);

  public SelectAqlField<NullFlavour> DIAGNOSTIC_SAFETY_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      ProblemDiagnosisEvaluation.class, "/data[at0001]/items[at0073]/null_flavour|defining_code",
      "diagnosticSafetyNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<String> DIAGNOSIS_EXPLANATION_VALUE = new AqlFieldImp<String>(ProblemDiagnosisEvaluation.class,
      "/data[at0001]/items[at0069]/value|value", "diagnosisExplanationValue", String.class, this);

  public SelectAqlField<NullFlavour> DIAGNOSIS_EXPLANATION_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      ProblemDiagnosisEvaluation.class, "/data[at0001]/items[at0069]/null_flavour|defining_code",
      "diagnosisExplanationNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<TemporalAccessor> LAST_DOCUMENTATION_DATE_VALUE = new AqlFieldImp<TemporalAccessor>(
      ProblemDiagnosisEvaluation.class, "/protocol[at0032]/items[at0070]/value|value", "lastDocumentationDateValue",
      TemporalAccessor.class, this);

  public SelectAqlField<NullFlavour> LAST_DOCUMENTATION_DATE_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      ProblemDiagnosisEvaluation.class, "/protocol[at0032]/items[at0070]/null_flavour|defining_code",
      "lastDocumentationDateNullFlavourDefiningCode", NullFlavour.class, this);

  public ListSelectAqlField<Cluster> EXTENSION = new ListAqlFieldImp<Cluster>(ProblemDiagnosisEvaluation.class,
      "/protocol[at0032]/items[at0071]", "extension", Cluster.class, this);

  public SelectAqlField<PartyProxy> SUBJECT = new AqlFieldImp<PartyProxy>(ProblemDiagnosisEvaluation.class, "/subject",
      "subject", PartyProxy.class, this);

  public SelectAqlField<Language> LANGUAGE = new AqlFieldImp<Language>(ProblemDiagnosisEvaluation.class, "/language",
      "language", Language.class, this);

  public SelectAqlField<FeederAudit> FEEDER_AUDIT = new AqlFieldImp<FeederAudit>(ProblemDiagnosisEvaluation.class,
      "/feeder_audit", "feederAudit", FeederAudit.class, this);

  public SelectAqlField<ProblemDiagnosisDiagnosticSafetyChoice> DIAGNOSTIC_SAFETY = new AqlFieldImp<ProblemDiagnosisDiagnosticSafetyChoice>(
      ProblemDiagnosisEvaluation.class, "/data[at0001]/items[at0073]/value", "diagnosticSafety",
      ProblemDiagnosisDiagnosticSafetyChoice.class, this);

  public SelectAqlField<ProblemDiagnosisSeverityChoice> SEVERITY = new AqlFieldImp<ProblemDiagnosisSeverityChoice>(
      ProblemDiagnosisEvaluation.class, "/data[at0001]/items[at0005]/value", "severity",
      ProblemDiagnosisSeverityChoice.class, this);

  private ProblemDiagnosisEvaluationContainment() {
    super("openEHR-EHR-EVALUATION.problem_diagnosis.v1");
  }

  public static ProblemDiagnosisEvaluationContainment getInstance() {
    return new ProblemDiagnosisEvaluationContainment();
  }
}
