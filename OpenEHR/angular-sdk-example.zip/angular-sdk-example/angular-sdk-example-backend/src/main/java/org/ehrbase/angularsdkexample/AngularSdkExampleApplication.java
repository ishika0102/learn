package org.ehrbase.angularsdkexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AngularSdkExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(AngularSdkExampleApplication.class, args);
    }

}
