package org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import java.lang.String;
import org.ehrbase.openehr.sdk.generator.commons.aql.containment.Containment;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.AqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.SelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

public class CaseIdentificationClusterContainment extends Containment {
  public SelectAqlField<CaseIdentificationCluster> CASE_IDENTIFICATION_CLUSTER = new AqlFieldImp<CaseIdentificationCluster>(
      CaseIdentificationCluster.class, "", "CaseIdentificationCluster", CaseIdentificationCluster.class, this);

  public SelectAqlField<String> CASE_ID_VALUE = new AqlFieldImp<String>(CaseIdentificationCluster.class,
      "/items[at0001]/value|value", "caseIdValue", String.class, this);

  public SelectAqlField<NullFlavour> CASE_ID_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      CaseIdentificationCluster.class, "/items[at0001]/null_flavour|defining_code", "caseIdNullFlavourDefiningCode",
      NullFlavour.class, this);

  public SelectAqlField<FeederAudit> FEEDER_AUDIT = new AqlFieldImp<FeederAudit>(CaseIdentificationCluster.class,
      "/feeder_audit", "feederAudit", FeederAudit.class, this);

  private CaseIdentificationClusterContainment() {
    super("openEHR-EHR-CLUSTER.case_identification.v0");
  }

  public static CaseIdentificationClusterContainment getInstance() {
    return new CaseIdentificationClusterContainment();
  }
}
