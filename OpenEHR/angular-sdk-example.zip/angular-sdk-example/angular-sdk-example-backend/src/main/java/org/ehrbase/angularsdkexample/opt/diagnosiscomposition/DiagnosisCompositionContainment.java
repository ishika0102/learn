package org.ehrbase.angularsdkexample.opt.diagnosiscomposition;

import org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition.CaseIdentificationCluster;
import org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition.ProblemDiagnosisEvaluation;
import com.nedap.archie.rm.archetyped.FeederAudit;
import com.nedap.archie.rm.generic.Participation;
import com.nedap.archie.rm.generic.PartyIdentified;
import com.nedap.archie.rm.generic.PartyProxy;
import java.lang.String;
import java.time.temporal.TemporalAccessor;
import org.ehrbase.openehr.sdk.generator.commons.aql.containment.Containment;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.AqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.ListAqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.ListSelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.SelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.Category;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.Language;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.Setting;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.Territory;

public class DiagnosisCompositionContainment extends Containment {
  public SelectAqlField<DiagnosisComposition> DIAGNOSIS_COMPOSITION = new AqlFieldImp<DiagnosisComposition>(
      DiagnosisComposition.class, "", "DiagnosisComposition", DiagnosisComposition.class, this);

  public SelectAqlField<Category> CATEGORY_DEFINING_CODE = new AqlFieldImp<Category>(DiagnosisComposition.class,
      "/category|defining_code", "categoryDefiningCode", Category.class, this);

  public SelectAqlField<String> REPORT_ID_VALUE = new AqlFieldImp<String>(DiagnosisComposition.class,
      "/context/other_context[at0001]/items[at0002]/value|value", "reportIdValue", String.class, this);

  public SelectAqlField<NullFlavour> REPORT_ID_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      DiagnosisComposition.class, "/context/other_context[at0001]/items[at0002]/null_flavour|defining_code",
      "reportIdNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<CaseIdentificationCluster> CASE_IDENTIFICATION = new AqlFieldImp<CaseIdentificationCluster>(
      DiagnosisComposition.class, "/context/other_context[at0001]/items[openEHR-EHR-CLUSTER.case_identification.v0]",
      "caseIdentification", CaseIdentificationCluster.class, this);

  public SelectAqlField<TemporalAccessor> START_TIME_VALUE = new AqlFieldImp<TemporalAccessor>(
      DiagnosisComposition.class, "/context/start_time|value", "startTimeValue", TemporalAccessor.class, this);

  public ListSelectAqlField<Participation> PARTICIPATIONS = new ListAqlFieldImp<Participation>(
      DiagnosisComposition.class, "/context/participations", "participations", Participation.class, this);

  public SelectAqlField<TemporalAccessor> END_TIME_VALUE = new AqlFieldImp<TemporalAccessor>(DiagnosisComposition.class,
      "/context/end_time|value", "endTimeValue", TemporalAccessor.class, this);

  public SelectAqlField<String> LOCATION = new AqlFieldImp<String>(DiagnosisComposition.class, "/context/location",
      "location", String.class, this);

  public SelectAqlField<PartyIdentified> HEALTH_CARE_FACILITY = new AqlFieldImp<PartyIdentified>(
      DiagnosisComposition.class, "/context/health_care_facility", "healthCareFacility", PartyIdentified.class, this);

  public SelectAqlField<Setting> SETTING_DEFINING_CODE = new AqlFieldImp<Setting>(DiagnosisComposition.class,
      "/context/setting|defining_code", "settingDefiningCode", Setting.class, this);

  public SelectAqlField<ProblemDiagnosisEvaluation> PROBLEM_DIAGNOSIS = new AqlFieldImp<ProblemDiagnosisEvaluation>(
      DiagnosisComposition.class, "/content[openEHR-EHR-EVALUATION.problem_diagnosis.v1]", "problemDiagnosis",
      ProblemDiagnosisEvaluation.class, this);

  public SelectAqlField<PartyProxy> COMPOSER = new AqlFieldImp<PartyProxy>(DiagnosisComposition.class, "/composer",
      "composer", PartyProxy.class, this);

  public SelectAqlField<Language> LANGUAGE = new AqlFieldImp<Language>(DiagnosisComposition.class, "/language",
      "language", Language.class, this);

  public SelectAqlField<FeederAudit> FEEDER_AUDIT = new AqlFieldImp<FeederAudit>(DiagnosisComposition.class,
      "/feeder_audit", "feederAudit", FeederAudit.class, this);

  public SelectAqlField<Territory> TERRITORY = new AqlFieldImp<Territory>(DiagnosisComposition.class, "/territory",
      "territory", Territory.class, this);

  private DiagnosisCompositionContainment() {
    super("openEHR-EHR-COMPOSITION.report.v1");
  }

  public static DiagnosisCompositionContainment getInstance() {
    return new DiagnosisCompositionContainment();
  }
}
