package org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition;

import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-16T13:15:12.221333488+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_CODED_TEXT")
public class ProblemDiagnosisDiagnosticSafetyDvCodedText implements RMEntity, ProblemDiagnosisDiagnosticSafetyChoice {
  /**
   * Path: Diagnosis/Problem/Diagnosis/Diagnostic Safety/Diagnostic Safety
   * Description: Degree of certainty with which the diagnosis was made.
   */
  @Path("|defining_code")
  private DiagnosticSafetyDefiningCode diagnosticSafetyDefiningCode;

  public void setDiagnosticSafetyDefiningCode(
      DiagnosticSafetyDefiningCode diagnosticSafetyDefiningCode) {
    this.diagnosticSafetyDefiningCode = diagnosticSafetyDefiningCode;
  }

  public DiagnosticSafetyDefiningCode getDiagnosticSafetyDefiningCode() {
    return this.diagnosticSafetyDefiningCode;
  }
}
