package org.ehrbase.angularsdkexample.opt.diagnosiscomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import java.util.List;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Archetype;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;

@Entity
@Archetype("openEHR-EHR-CLUSTER.etiology.v1")
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-16T13:15:12.202493422+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class EtiopathogenesisCluster implements LocatableEntity {
   /**
    * Path: Diagnosis/Problem/Diagnosis/Etiopathogenesis/Etiology of the disease
    * Description: Identification of the cause of the disease or abnormal
    * condition.
    * Comment: This could be another disease, an unhealthy behavior, a gene, or
    * another root cause of the disease the patient has.
    * It is possible to repeat this element for a disease that has multiple causes.
    * Where possible, coding this element via a terminology database is preferable.
    * Examples of input could be: alcoholism (in liver cirrhosis), diabetes
    * mellitus (in chronic kidney disease), respiratory infection (in fever) or
    * smoking (in lung cancer).
    */
   @Path("/items[at0001]")
   private List<EtiopathogenesisEtiologyOfTheDiseaseElement> etiologyOfTheDisease;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Etiopathogenesis/Description of the
    * creation
    * Description: Further description of the causes or reasons for the occurrence
    * (etiology) of a specific problem/diagnosis.
    * Comment: e.g. local inflammatory reaction with damage and destruction of
    * liver cells.
    */
   @Path("/items[at0017]")
   private List<EtiopathogenesisDescriptionOfTheCreationElement> descriptionOfTheCreation;

   /**
    * Path: Diagnosis/Problem/Diagnosis/Etiopathogenesis/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   public void setEtiologyOfTheDisease(
         List<EtiopathogenesisEtiologyOfTheDiseaseElement> etiologyOfTheDisease) {
      this.etiologyOfTheDisease = etiologyOfTheDisease;
   }

   public List<EtiopathogenesisEtiologyOfTheDiseaseElement> getEtiologyOfTheDisease() {
      return this.etiologyOfTheDisease;
   }

   public void setDescriptionOfTheCreation(
         List<EtiopathogenesisDescriptionOfTheCreationElement> descriptionOfTheCreation) {
      this.descriptionOfTheCreation = descriptionOfTheCreation;
   }

   public List<EtiopathogenesisDescriptionOfTheCreationElement> getDescriptionOfTheCreation() {
      return this.descriptionOfTheCreation;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }
}
