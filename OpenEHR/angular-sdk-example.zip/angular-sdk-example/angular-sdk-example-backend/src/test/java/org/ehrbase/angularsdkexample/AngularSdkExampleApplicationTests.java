package org.ehrbase.angularsdkexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AngularSdkExampleApplicationTests {

    @Test
    void contextLoads() {
    }

}
