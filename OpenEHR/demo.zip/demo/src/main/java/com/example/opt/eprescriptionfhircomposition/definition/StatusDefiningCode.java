package com.example.opt.eprescriptionfhircomposition.definition;

import java.lang.String;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.EnumValueSet;

public enum StatusDefiningCode implements EnumValueSet {
   STOPPED("Stopped",
         "This is a medication that has previously been issued, dispensed or administered but has now been discontinued.",
         "local", "at0022"),

   DRAFT("Draft",
         "The medication order has been made but further processes e.g. sign-off or verification are required before it becomes actionable.",
         "local", "at0027"),

   SUSPENDED("Suspended",
         "Actions reuulting from the order are to be temporarily halted, but are expected to continue later. May also be called 'on-hold'.",
         "local", "at0026"),

   NEVER_ACTIVE("Never active",
         "A medication which was ordered or authorised but has been cancelled prior to being issued, dispensed or adiminstered.",
         "local", "at0023"),

   COMPLETED("Completed", "The medication course has been completed.", "local", "at0024"),

   OBSOLETE("Obsolete", "This medication order has been superseded by another.", "local", "at0025"),

   ACTIVE("Active", "This is an active medication.", "local", "at0021");

   private String value;

   private String description;

   private String terminologyId;

   private String code;

   StatusDefiningCode(String value, String description, String terminologyId, String code) {
      this.value = value;
      this.description = description;
      this.terminologyId = terminologyId;
      this.code = code;
   }

   public String getValue() {
      return this.value;
   }

   public String getDescription() {
      return this.description;
   }

   public String getTerminologyId() {
      return this.terminologyId;
   }

   public String getCode() {
      return this.code;
   }
}
