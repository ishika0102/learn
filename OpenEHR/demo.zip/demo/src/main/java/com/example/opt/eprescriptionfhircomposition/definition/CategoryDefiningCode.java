package com.example.opt.eprescriptionfhircomposition.definition;

import java.lang.String;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.EnumValueSet;

public enum CategoryDefiningCode implements EnumValueSet {
   AD_HOC_MIXTURE("Ad-hoc mixture",
         "The substance is composed of a mixture of ingredients specificied within this order.", "local", "at0143"),

   SINGLE_SUBSTANCE_PRODUCT("Single-substance  product",
         "The substance is a manufactured product containing a single ingredient.", "local", "at0145"),

   PRODUCT("Product", "The substance is a manufactured product, containing one or more ingredients.", "local",
         "at0147"),

   COMBINATION_PRODUCT("Combination product",
         "The preparation consists of a number of ingredients which are pre-combined by the manufacturer.", "local",
         "at0144"),

   INGREDIENT("Ingredient", "The substance is an individual ingredient of the medication.", "local", "at0146");

   private String value;

   private String description;

   private String terminologyId;

   private String code;

   CategoryDefiningCode(String value, String description, String terminologyId, String code) {
      this.value = value;
      this.description = description;
      this.terminologyId = terminologyId;
      this.code = code;
   }

   public String getValue() {
      return this.value;
   }

   public String getDescription() {
      return this.description;
   }

   public String getTerminologyId() {
      return this.terminologyId;
   }

   public String getCode() {
      return this.code;
   }
}
