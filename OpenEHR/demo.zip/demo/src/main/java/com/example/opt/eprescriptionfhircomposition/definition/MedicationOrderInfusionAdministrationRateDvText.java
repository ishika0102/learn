package com.example.opt.eprescriptionfhircomposition.definition;

import java.lang.String;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.848846892+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_TEXT")
public class MedicationOrderInfusionAdministrationRateDvText
      implements RMEntity, MedicationOrderInfusionAdministrationRateChoice {
   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose
    * pattern/Infusion administration rate/Infusion administration rate
    * Description: The rate at which the medication infusion is to be administered.
    * Comment: For example: 1 drop per minute. Use the text data type to record
    * non- or semi-quantifiable instructions.
    */
   @Path("|value")
   private String infusionAdministrationRateValue;

   public void setInfusionAdministrationRateValue(String infusionAdministrationRateValue) {
      this.infusionAdministrationRateValue = infusionAdministrationRateValue;
   }

   public String getInfusionAdministrationRateValue() {
      return this.infusionAdministrationRateValue;
   }
}
