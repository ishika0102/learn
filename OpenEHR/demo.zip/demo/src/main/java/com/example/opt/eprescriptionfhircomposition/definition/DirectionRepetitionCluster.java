package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import java.time.temporal.TemporalAmount;
import java.util.List;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Archetype;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Archetype("openEHR-EHR-CLUSTER.timing_repetition.v0")
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.850106450+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class DirectionRepetitionCluster implements LocatableEntity {
   /**
    * Path: Prescription/Medication order/Order/Dose direction/Direction
    * repetition/Repetition interval
    * Description: The interval between repetitions of the activity.
    * Comment: e.g. 'Every 3 weeks'
    */
   @Path("/items[at0002]/value|value")
   private TemporalAmount repetitionIntervalValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Dose direction/Direction
    * repetition/Repetition interval/null_flavour
    */
   @Path("/items[at0002]/null_flavour|defining_code")
   private NullFlavour repetitionIntervalNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Direction
    * repetition/Specific date
    * Description: The activity should take place on a specific date.
    * Comment: e.g. 'on 12 Jan 2017'
    */
   @Path("/items[at0001]")
   private List<DirectionRepetitionSpecificDateElement> specificDate;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Direction
    * repetition/Specific day of week
    * Description: The activity should take place on a specific day of the week,
    * with 0 representing Sunday.
    * Comment: e.g. 'On Mondays, Wednesdays and Fridays'.
    */
   @Path("/items[at0003]")
   private List<DirectionRepetitionSpecificDayOfWeekElement> specificDayOfWeek;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Direction
    * repetition/Specific day of month
    * Description: The activity should take place on a specific day of the month.
    * Comment: e.g. 'on the 3rd, 13th and 23rd of each month'.
    */
   @Path("/items[at0004]")
   private List<DirectionRepetitionSpecificDayOfMonthElement> specificDayOfMonth;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Direction
    * repetition/Specific event
    * Description: The activity should take place in relation to a specific named
    * event.
    */
   @Path("/items[at0006]")
   private List<DirectionRepetitionSpecificEventCluster> specificEvent;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Direction
    * repetition/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   public void setRepetitionIntervalValue(TemporalAmount repetitionIntervalValue) {
      this.repetitionIntervalValue = repetitionIntervalValue;
   }

   public TemporalAmount getRepetitionIntervalValue() {
      return this.repetitionIntervalValue;
   }

   public void setRepetitionIntervalNullFlavourDefiningCode(
         NullFlavour repetitionIntervalNullFlavourDefiningCode) {
      this.repetitionIntervalNullFlavourDefiningCode = repetitionIntervalNullFlavourDefiningCode;
   }

   public NullFlavour getRepetitionIntervalNullFlavourDefiningCode() {
      return this.repetitionIntervalNullFlavourDefiningCode;
   }

   public void setSpecificDate(List<DirectionRepetitionSpecificDateElement> specificDate) {
      this.specificDate = specificDate;
   }

   public List<DirectionRepetitionSpecificDateElement> getSpecificDate() {
      return this.specificDate;
   }

   public void setSpecificDayOfWeek(
         List<DirectionRepetitionSpecificDayOfWeekElement> specificDayOfWeek) {
      this.specificDayOfWeek = specificDayOfWeek;
   }

   public List<DirectionRepetitionSpecificDayOfWeekElement> getSpecificDayOfWeek() {
      return this.specificDayOfWeek;
   }

   public void setSpecificDayOfMonth(
         List<DirectionRepetitionSpecificDayOfMonthElement> specificDayOfMonth) {
      this.specificDayOfMonth = specificDayOfMonth;
   }

   public List<DirectionRepetitionSpecificDayOfMonthElement> getSpecificDayOfMonth() {
      return this.specificDayOfMonth;
   }

   public void setSpecificEvent(List<DirectionRepetitionSpecificEventCluster> specificEvent) {
      this.specificEvent = specificEvent;
   }

   public List<DirectionRepetitionSpecificEventCluster> getSpecificEvent() {
      return this.specificEvent;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }
}
