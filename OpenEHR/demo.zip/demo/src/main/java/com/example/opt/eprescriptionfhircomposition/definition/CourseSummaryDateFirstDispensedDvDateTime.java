package com.example.opt.eprescriptionfhircomposition.definition;

import java.time.temporal.TemporalAccessor;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.892517601+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_DATE_TIME")
public class CourseSummaryDateFirstDispensedDvDateTime implements RMEntity, CourseSummaryDateFirstDispensedChoice {
   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * first dispensed/Date first dispensed
    * Description: Key medication event dates.
    */
   @Path("|value")
   private TemporalAccessor dateFirstDispensedValue;

   public void setDateFirstDispensedValue(TemporalAccessor dateFirstDispensedValue) {
      this.dateFirstDispensedValue = dateFirstDispensedValue;
   }

   public TemporalAccessor getDateFirstDispensedValue() {
      return this.dateFirstDispensedValue;
   }
}
