package com.example.controller;

import java.util.Collections;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;
import com.example.service.PrescriptionService;

@RestController
@RequestMapping(path = "/api")
@CrossOrigin(origins = "*")
public class PrescriptionController {
        private final PrescriptionService service;

        @Autowired
        public PrescriptionController(PrescriptionService service) {
                this.service = service;

        }

        @PostMapping(path = "/ehr")
        public ResponseEntity<Map<String, UUID>> postEhr() {
                UUID ehrId = service.createEhr();
                return ResponseEntity.ok(Collections.singletonMap("ehr_id", ehrId));
        }

}
