package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import java.lang.Boolean;
import java.lang.String;
import java.time.temporal.TemporalAmount;
import org.ehrbase.openehr.sdk.generator.commons.aql.containment.Containment;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.AqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.ListAqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.ListSelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.SelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

public class DoseTimingClusterContainment extends Containment {
  public SelectAqlField<DoseTimingCluster> DOSE_TIMING_CLUSTER = new AqlFieldImp<DoseTimingCluster>(
      DoseTimingCluster.class, "", "DoseTimingCluster", DoseTimingCluster.class, this);

  public SelectAqlField<NullFlavour> FREQUENCY_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      DoseTimingCluster.class, "/items[at0003]/null_flavour|defining_code", "frequencyNullFlavourDefiningCode",
      NullFlavour.class, this);

  public SelectAqlField<TemporalAmount> INTERVAL_VALUE = new AqlFieldImp<TemporalAmount>(DoseTimingCluster.class,
      "/items[at0014]/value|value", "intervalValue", TemporalAmount.class, this);

  public SelectAqlField<NullFlavour> INTERVAL_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      DoseTimingCluster.class, "/items[at0014]/null_flavour|defining_code", "intervalNullFlavourDefiningCode",
      NullFlavour.class, this);

  public ListSelectAqlField<DoseTimingSpecificTimeElement> SPECIFIC_TIME = new ListAqlFieldImp<DoseTimingSpecificTimeElement>(
      DoseTimingCluster.class, "/items[at0004]", "specificTime", DoseTimingSpecificTimeElement.class, this);

  public ListSelectAqlField<DoseTimingNamedTimeEventElement> NAMED_TIME_EVENT = new ListAqlFieldImp<DoseTimingNamedTimeEventElement>(
      DoseTimingCluster.class, "/items[at0026]", "namedTimeEvent", DoseTimingNamedTimeEventElement.class, this);

  public SelectAqlField<Boolean> EXACT_TIMING_CRITICAL_VALUE = new AqlFieldImp<Boolean>(DoseTimingCluster.class,
      "/items[at0023]/value|value", "exactTimingCriticalValue", Boolean.class, this);

  public SelectAqlField<NullFlavour> EXACT_TIMING_CRITICAL_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      DoseTimingCluster.class, "/items[at0023]/null_flavour|defining_code",
      "exactTimingCriticalNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<Boolean> AS_REQUIRED_VALUE = new AqlFieldImp<Boolean>(DoseTimingCluster.class,
      "/items[at0024]/value|value", "asRequiredValue", Boolean.class, this);

  public SelectAqlField<NullFlavour> AS_REQUIRED_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      DoseTimingCluster.class, "/items[at0024]/null_flavour|defining_code", "asRequiredNullFlavourDefiningCode",
      NullFlavour.class, this);

  public SelectAqlField<String> AS_REQUIRED_CRITERION_VALUE = new AqlFieldImp<String>(DoseTimingCluster.class,
      "/items[at0025]/value|value", "asRequiredCriterionValue", String.class, this);

  public SelectAqlField<NullFlavour> AS_REQUIRED_CRITERION_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      DoseTimingCluster.class, "/items[at0025]/null_flavour|defining_code",
      "asRequiredCriterionNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<FeederAudit> FEEDER_AUDIT = new AqlFieldImp<FeederAudit>(DoseTimingCluster.class,
      "/feeder_audit", "feederAudit", FeederAudit.class, this);

  public SelectAqlField<DoseTimingFrequencyChoice> FREQUENCY = new AqlFieldImp<DoseTimingFrequencyChoice>(
      DoseTimingCluster.class, "/items[at0003]/value", "frequency", DoseTimingFrequencyChoice.class, this);

  private DoseTimingClusterContainment() {
    super("openEHR-EHR-CLUSTER.timing_daily.v0");
  }

  public static DoseTimingClusterContainment getInstance() {
    return new DoseTimingClusterContainment();
  }
}
