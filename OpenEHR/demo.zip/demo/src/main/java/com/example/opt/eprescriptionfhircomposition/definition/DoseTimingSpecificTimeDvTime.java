package com.example.opt.eprescriptionfhircomposition.definition;

import java.time.temporal.TemporalAccessor;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.838134620+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_TIME")
public class DoseTimingSpecificTimeDvTime implements RMEntity, DoseTimingSpecificTimeChoice {
   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Specific time/Specific time
    * Description: A specific time or interval of time during a single day when the
    * activity should occur.
    * Comment: e.g "at 0800, 1400, 15.25."
    */
   @Path("|value")
   private TemporalAccessor specificTimeValue;

   public void setSpecificTimeValue(TemporalAccessor specificTimeValue) {
      this.specificTimeValue = specificTimeValue;
   }

   public TemporalAccessor getSpecificTimeValue() {
      return this.specificTimeValue;
   }
}
