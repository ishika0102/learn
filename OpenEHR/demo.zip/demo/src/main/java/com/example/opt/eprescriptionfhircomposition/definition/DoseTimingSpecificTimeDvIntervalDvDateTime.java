package com.example.opt.eprescriptionfhircomposition.definition;

import java.lang.Boolean;
import java.time.temporal.TemporalAccessor;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.838390364+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_INTERVAL<DV_DATE_TIME>")
public class DoseTimingSpecificTimeDvIntervalDvDateTime implements RMEntity, DoseTimingSpecificTimeChoice {
   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Specific time/upper
    */
   @Path("/upper|value")
   private TemporalAccessor upperValue;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Specific time/lower
    */
   @Path("/lower|value")
   private TemporalAccessor lowerValue;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Specific time/lower_included
    */
   @Path("/lower_included")
   private Boolean lowerIncluded;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Specific time/upper_included
    */
   @Path("/upper_included")
   private Boolean upperIncluded;

   public void setUpperValue(TemporalAccessor upperValue) {
      this.upperValue = upperValue;
   }

   public TemporalAccessor getUpperValue() {
      return this.upperValue;
   }

   public void setLowerValue(TemporalAccessor lowerValue) {
      this.lowerValue = lowerValue;
   }

   public TemporalAccessor getLowerValue() {
      return this.lowerValue;
   }

   public void setLowerIncluded(Boolean lowerIncluded) {
      this.lowerIncluded = lowerIncluded;
   }

   public Boolean isLowerIncluded() {
      return this.lowerIncluded;
   }

   public void setUpperIncluded(Boolean upperIncluded) {
      this.upperIncluded = upperIncluded;
   }

   public Boolean isUpperIncluded() {
      return this.upperIncluded;
   }
}
