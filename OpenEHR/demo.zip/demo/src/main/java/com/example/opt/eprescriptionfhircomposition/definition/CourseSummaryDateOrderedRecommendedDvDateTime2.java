package com.example.opt.eprescriptionfhircomposition.definition;

import java.time.temporal.TemporalAccessor;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.875068770+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_DATE_TIME")
public class CourseSummaryDateOrderedRecommendedDvDateTime2
      implements RMEntity, CourseSummaryDateOrderedRecommendedChoice {
   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * ordered/recommended/Date ordered/recommended
    * Description: Key medication event dates.
    */
   @Path("|value")
   private TemporalAccessor dateOrderedRecommendedValue;

   public void setDateOrderedRecommendedValue(TemporalAccessor dateOrderedRecommendedValue) {
      this.dateOrderedRecommendedValue = dateOrderedRecommendedValue;
   }

   public TemporalAccessor getDateOrderedRecommendedValue() {
      return this.dateOrderedRecommendedValue;
   }
}
