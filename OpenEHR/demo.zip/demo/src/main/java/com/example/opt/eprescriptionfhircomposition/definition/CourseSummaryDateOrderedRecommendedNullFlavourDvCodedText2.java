package com.example.opt.eprescriptionfhircomposition.definition;

import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.884306607+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_CODED_TEXT")
public class CourseSummaryDateOrderedRecommendedNullFlavourDvCodedText2
    implements RMEntity, CourseSummaryDateOrderedRecommendedNullFlavourChoice {
  /**
   * Path: Prescription/Medication order/Order/Tree/Order details/Course
   * summary/Date ordered/recommended/null_flavour/null_flavour
   */
  @Path("|defining_code")
  private NullFlavour dateOrderedRecommendedNullFlavourDefiningCode;

  public void setDateOrderedRecommendedNullFlavourDefiningCode(
      NullFlavour dateOrderedRecommendedNullFlavourDefiningCode) {
    this.dateOrderedRecommendedNullFlavourDefiningCode = dateOrderedRecommendedNullFlavourDefiningCode;
  }

  public NullFlavour getDateOrderedRecommendedNullFlavourDefiningCode() {
    return this.dateOrderedRecommendedNullFlavourDefiningCode;
  }
}
