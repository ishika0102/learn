package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import com.nedap.archie.rm.datastructures.Cluster;
import java.lang.Double;
import java.lang.String;
import java.util.List;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Archetype;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Archetype("openEHR-EHR-CLUSTER.medication_substance.v0")
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.810484530+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class PreparationCluster implements LocatableEntity {
   /**
    * Path: Prescription/Medication order/Order/Preparation/Substance name
    * Description: The name of the medication substance. This item should be coded
    * if possible.
    * Comment: Usage of substance name will vary according to context of use.
    */
   @Path("/items[at0132]/value|value")
   private String substanceNameValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Preparation/Substance
    * name/null_flavour
    */
   @Path("/items[at0132]/null_flavour|defining_code")
   private NullFlavour substanceNameNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Preparation/Form
    * Description: The formulation or presentation of the medication.
    * Comment: e.g. 'Tablet', 'Capsule', 'Liquid'.
    */
   @Path("/items[at0071]")
   private List<PreparationFormElement> form;

   /**
    * Path: Prescription/Medication order/Order/Preparation/Strength
    * Description: The value of the strength of medication as a real number.
    * Comment: e.g. 1, 1.5, 0.125
    */
   @Path("/items[at0115]/value|magnitude")
   private Double strengthMagnitude;

   /**
    * Path: Prescription/Medication order/Order/Preparation/Strength
    * Description: The value of the strength of medication as a real number.
    * Comment: e.g. 1, 1.5, 0.125
    */
   @Path("/items[at0115]/value|units")
   private String strengthUnits;

   /**
    * Path: Prescription/Medication
    * order/Order/Tree/Preparation/Strength/null_flavour
    */
   @Path("/items[at0115]/null_flavour|defining_code")
   private NullFlavour strengthNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Preparation/Strength unit
    * Description: The dose unit of the medication substance strength.
    * Comment: e.g 'tablet','mg'. Often coded using a reference terminology such as
    * SNOMED CT.
    */
   @Path("/items[at0116]/value|value")
   private String strengthUnitValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Preparation/Strength
    * unit/null_flavour
    */
   @Path("/items[at0116]/null_flavour|defining_code")
   private NullFlavour strengthUnitNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Preparation/Diluent/Diluent amount
    * Description: The value of the amount of diluent as a real number.
    * Comment: e.g 1, 1.5, 0.125 or 1-2, 12.5-20.5
    */
   @Path("/items[at0117]/items[at0124]/value|magnitude")
   private Double diluentAmountMagnitude;

   /**
    * Path: Prescription/Medication order/Order/Preparation/Diluent/Diluent amount
    * Description: The value of the amount of diluent as a real number.
    * Comment: e.g 1, 1.5, 0.125 or 1-2, 12.5-20.5
    */
   @Path("/items[at0117]/items[at0124]/value|units")
   private String diluentAmountUnits;

   /**
    * Path: Prescription/Medication order/Order/Tree/Preparation/Diluent/Diluent
    * amount/null_flavour
    */
   @Path("/items[at0117]/items[at0124]/null_flavour|defining_code")
   private NullFlavour diluentAmountNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Preparation/Diluent/Diluent unit
    * Description: The unit for the preparation diluent.
    * Comment: e.g. 'ml'.
    */
   @Path("/items[at0117]/items[at0125]/value|value")
   private String diluentUnitValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Preparation/Diluent/Diluent
    * unit/null_flavour
    */
   @Path("/items[at0117]/items[at0125]/null_flavour|defining_code")
   private NullFlavour diluentUnitNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Preparation/Ingredient
    * Description: Details of an ingredient used to make up a mixed preparation or
    * infuson.
    * Comment: This is not normally required other than where an ad-hoc mixture or
    * infusion is being described.
    */
   @Path("/items[at0126]")
   private List<PreparationIngredientCluster> ingredient;

   /**
    * Path: Prescription/Medication order/Order/Preparation/Description
    * Description: A text description of the substance where it is not possible to
    * describe this fully using numerical strengths and amounts.
    */
   @Path("/items[at0133]/value|value")
   private String descriptionValue;

   /**
    * Path: Prescription/Medication
    * order/Order/Tree/Preparation/Description/null_flavour
    */
   @Path("/items[at0133]/null_flavour|defining_code")
   private NullFlavour descriptionNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Preparation/Substance details
    * Description: Further details about the medicatin preparation.
    * Comment: e.g. detailed information about the drug class or intended routes.
    */
   @Path("/items[at0141]")
   private List<Cluster<?>> substanceDetails;

   /**
    * Path: Prescription/Medication order/Order/Preparation/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   public void setSubstanceNameValue(String substanceNameValue) {
      this.substanceNameValue = substanceNameValue;
   }

   public String getSubstanceNameValue() {
      return this.substanceNameValue;
   }

   public void setSubstanceNameNullFlavourDefiningCode(
         NullFlavour substanceNameNullFlavourDefiningCode) {
      this.substanceNameNullFlavourDefiningCode = substanceNameNullFlavourDefiningCode;
   }

   public NullFlavour getSubstanceNameNullFlavourDefiningCode() {
      return this.substanceNameNullFlavourDefiningCode;
   }

   public void setForm(List<PreparationFormElement> form) {
      this.form = form;
   }

   public List<PreparationFormElement> getForm() {
      return this.form;
   }

   public void setStrengthMagnitude(Double strengthMagnitude) {
      this.strengthMagnitude = strengthMagnitude;
   }

   public Double getStrengthMagnitude() {
      return this.strengthMagnitude;
   }

   public void setStrengthUnits(String strengthUnits) {
      this.strengthUnits = strengthUnits;
   }

   public String getStrengthUnits() {
      return this.strengthUnits;
   }

   public void setStrengthNullFlavourDefiningCode(NullFlavour strengthNullFlavourDefiningCode) {
      this.strengthNullFlavourDefiningCode = strengthNullFlavourDefiningCode;
   }

   public NullFlavour getStrengthNullFlavourDefiningCode() {
      return this.strengthNullFlavourDefiningCode;
   }

   public void setStrengthUnitValue(String strengthUnitValue) {
      this.strengthUnitValue = strengthUnitValue;
   }

   public String getStrengthUnitValue() {
      return this.strengthUnitValue;
   }

   public void setStrengthUnitNullFlavourDefiningCode(
         NullFlavour strengthUnitNullFlavourDefiningCode) {
      this.strengthUnitNullFlavourDefiningCode = strengthUnitNullFlavourDefiningCode;
   }

   public NullFlavour getStrengthUnitNullFlavourDefiningCode() {
      return this.strengthUnitNullFlavourDefiningCode;
   }

   public void setDiluentAmountMagnitude(Double diluentAmountMagnitude) {
      this.diluentAmountMagnitude = diluentAmountMagnitude;
   }

   public Double getDiluentAmountMagnitude() {
      return this.diluentAmountMagnitude;
   }

   public void setDiluentAmountUnits(String diluentAmountUnits) {
      this.diluentAmountUnits = diluentAmountUnits;
   }

   public String getDiluentAmountUnits() {
      return this.diluentAmountUnits;
   }

   public void setDiluentAmountNullFlavourDefiningCode(
         NullFlavour diluentAmountNullFlavourDefiningCode) {
      this.diluentAmountNullFlavourDefiningCode = diluentAmountNullFlavourDefiningCode;
   }

   public NullFlavour getDiluentAmountNullFlavourDefiningCode() {
      return this.diluentAmountNullFlavourDefiningCode;
   }

   public void setDiluentUnitValue(String diluentUnitValue) {
      this.diluentUnitValue = diluentUnitValue;
   }

   public String getDiluentUnitValue() {
      return this.diluentUnitValue;
   }

   public void setDiluentUnitNullFlavourDefiningCode(
         NullFlavour diluentUnitNullFlavourDefiningCode) {
      this.diluentUnitNullFlavourDefiningCode = diluentUnitNullFlavourDefiningCode;
   }

   public NullFlavour getDiluentUnitNullFlavourDefiningCode() {
      return this.diluentUnitNullFlavourDefiningCode;
   }

   public void setIngredient(List<PreparationIngredientCluster> ingredient) {
      this.ingredient = ingredient;
   }

   public List<PreparationIngredientCluster> getIngredient() {
      return this.ingredient;
   }

   public void setDescriptionValue(String descriptionValue) {
      this.descriptionValue = descriptionValue;
   }

   public String getDescriptionValue() {
      return this.descriptionValue;
   }

   public void setDescriptionNullFlavourDefiningCode(
         NullFlavour descriptionNullFlavourDefiningCode) {
      this.descriptionNullFlavourDefiningCode = descriptionNullFlavourDefiningCode;
   }

   public NullFlavour getDescriptionNullFlavourDefiningCode() {
      return this.descriptionNullFlavourDefiningCode;
   }

   public void setSubstanceDetails(List<Cluster<?>> substanceDetails) {
      this.substanceDetails = substanceDetails;
   }

   public List<Cluster<?>> getSubstanceDetails() {
      return this.substanceDetails;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }
}
