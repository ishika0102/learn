package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import java.lang.Long;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.851240774+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class DirectionRepetitionSpecificDayOfWeekElement implements LocatableEntity {
   /**
    * Path: Prescription/Medication order/Order/Dose direction/Direction
    * repetition/Specific day of week
    * Description: The activity should take place on a specific day of the week,
    * with 0 representing Sunday.
    * Comment: e.g. 'On Mondays, Wednesdays and Fridays'.
    */
   @Path("/value|magnitude")
   private Long value;

   /**
    * Path: Prescription/Medication order/Order/Tree/Dose direction/Direction
    * repetition/Specific day of week/null_flavour
    */
   @Path("/null_flavour|defining_code")
   private NullFlavour value2;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Direction
    * repetition/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   public void setValue(Long value) {
      this.value = value;
   }

   public Long getValue() {
      return this.value;
   }

   public void setValue2(NullFlavour value2) {
      this.value2 = value2;
   }

   public NullFlavour getValue2() {
      return this.value2;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }
}
