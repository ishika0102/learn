package com.example.opt.eprescriptionfhircomposition.definition;

import java.lang.Double;
import java.lang.String;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.842939970+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_QUANTITY")
public class DoseTimingFrequencyDvQuantity implements RMEntity, DoseTimingFrequencyChoice {
   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Frequency/Frequency
    * Description: The frequency as number of times per time period (limited to a
    * single day) that the activity is to take place.
    * Comment: e.g. "4 times per day" or ""3 to 4 times per hour"
    */
   @Path("|magnitude")
   private Double frequencyMagnitude;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Frequency/Frequency
    * Description: The frequency as number of times per time period (limited to a
    * single day) that the activity is to take place.
    * Comment: e.g. "4 times per day" or ""3 to 4 times per hour"
    */
   @Path("|units")
   private String frequencyUnits;

   public void setFrequencyMagnitude(Double frequencyMagnitude) {
      this.frequencyMagnitude = frequencyMagnitude;
   }

   public Double getFrequencyMagnitude() {
      return this.frequencyMagnitude;
   }

   public void setFrequencyUnits(String frequencyUnits) {
      this.frequencyUnits = frequencyUnits;
   }

   public String getFrequencyUnits() {
      return this.frequencyUnits;
   }
}
