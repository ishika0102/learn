package com.example.opt.eprescriptionfhircomposition.definition;

import java.time.temporal.TemporalAccessor;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.871289289+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_DATE_TIME")
public class CourseSummaryDateAuthorisedDvDateTime2 implements RMEntity, CourseSummaryDateAuthorisedChoice {
   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * authorised/Date authorised
    * Description: Key medication event dates.
    */
   @Path("|value")
   private TemporalAccessor dateAuthorisedValue;

   public void setDateAuthorisedValue(TemporalAccessor dateAuthorisedValue) {
      this.dateAuthorisedValue = dateAuthorisedValue;
   }

   public TemporalAccessor getDateAuthorisedValue() {
      return this.dateAuthorisedValue;
   }
}
