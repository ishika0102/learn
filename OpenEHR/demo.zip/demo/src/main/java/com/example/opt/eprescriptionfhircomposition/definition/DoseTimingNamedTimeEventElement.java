package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Choice;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.839931234+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class DoseTimingNamedTimeEventElement implements LocatableEntity {
   /**
    * Path: Prescription/Medication order/Order/Tree/Dose direction/Dose
    * pattern/Dose timing/Named time event/null_flavour
    */
   @Path("/null_flavour|defining_code")
   private NullFlavour value;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Named time event
    * Description: A specific, named time event within a single day, when the
    * activity should occur.
    * Comment: e.g. before each meal, at bedtime, in the morning.
    * It is understood that these terms may not equate to the same exact times in
    * different cultures.
    */
   @Path("/value")
   @Choice
   private DoseTimingNamedTimeEventChoice value2;

   public void setValue(NullFlavour value) {
      this.value = value;
   }

   public NullFlavour getValue() {
      return this.value;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }

   public void setValue2(DoseTimingNamedTimeEventChoice value2) {
      this.value2 = value2;
   }

   public DoseTimingNamedTimeEventChoice getValue2() {
      return this.value2;
   }
}
