package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import java.lang.String;
import java.time.temporal.TemporalAmount;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.852352633+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class DirectionRepetitionSpecificEventCluster implements LocatableEntity {
   /**
    * Path: Prescription/Medication order/Order/Dose direction/Direction
    * repetition/Specific event/Event name
    * Description: The name of the event that triggers the activity to take place.
    */
   @Path("/items[at0005]/value|value")
   private String eventNameValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Dose direction/Direction
    * repetition/Specific event/Event name/null_flavour
    */
   @Path("/items[at0005]/null_flavour|defining_code")
   private NullFlavour eventNameNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Direction
    * repetition/Specific event/Start interval
    * Description: The period of time before or after the named event when the
    * activity should take place. Negative durations can be used to signifify that
    * the activity should be taken before a known event.
    * Comment: e.g. '3 days after onset of menstruation = menstrual onset + 3
    * days', '2 weeks prior to admission= admission -2 weeks'.
    */
   @Path("/items[at0009]/value|value")
   private TemporalAmount startIntervalValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Dose direction/Direction
    * repetition/Specific event/Start interval/null_flavour
    */
   @Path("/items[at0009]/null_flavour|defining_code")
   private NullFlavour startIntervalNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Direction
    * repetition/Specific event/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   public void setEventNameValue(String eventNameValue) {
      this.eventNameValue = eventNameValue;
   }

   public String getEventNameValue() {
      return this.eventNameValue;
   }

   public void setEventNameNullFlavourDefiningCode(NullFlavour eventNameNullFlavourDefiningCode) {
      this.eventNameNullFlavourDefiningCode = eventNameNullFlavourDefiningCode;
   }

   public NullFlavour getEventNameNullFlavourDefiningCode() {
      return this.eventNameNullFlavourDefiningCode;
   }

   public void setStartIntervalValue(TemporalAmount startIntervalValue) {
      this.startIntervalValue = startIntervalValue;
   }

   public TemporalAmount getStartIntervalValue() {
      return this.startIntervalValue;
   }

   public void setStartIntervalNullFlavourDefiningCode(
         NullFlavour startIntervalNullFlavourDefiningCode) {
      this.startIntervalNullFlavourDefiningCode = startIntervalNullFlavourDefiningCode;
   }

   public NullFlavour getStartIntervalNullFlavourDefiningCode() {
      return this.startIntervalNullFlavourDefiningCode;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }
}
