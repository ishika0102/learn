package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import org.ehrbase.openehr.sdk.generator.commons.aql.containment.Containment;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.AqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.SelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

public class CourseSummaryClusterContainment extends Containment {
  public SelectAqlField<CourseSummaryCluster> COURSE_SUMMARY_CLUSTER = new AqlFieldImp<CourseSummaryCluster>(
      CourseSummaryCluster.class, "", "CourseSummaryCluster", CourseSummaryCluster.class, this);

  public SelectAqlField<StatusDefiningCode> STATUS_DEFINING_CODE = new AqlFieldImp<StatusDefiningCode>(
      CourseSummaryCluster.class, "/items[at0001]/value|defining_code", "statusDefiningCode", StatusDefiningCode.class,
      this);

  public SelectAqlField<NullFlavour> STATUS_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      CourseSummaryCluster.class, "/items[at0001]/null_flavour|defining_code", "statusNullFlavourDefiningCode",
      NullFlavour.class, this);

  public SelectAqlField<FeederAudit> FEEDER_AUDIT = new AqlFieldImp<FeederAudit>(CourseSummaryCluster.class,
      "/feeder_audit", "feederAudit", FeederAudit.class, this);

  public SelectAqlField<CourseSummaryDatePrescriptionIssuedNullFlavourChoice> DATE_PRESCRIPTION_ISSUED_NULL_FLAVOUR = new AqlFieldImp<CourseSummaryDatePrescriptionIssuedNullFlavourChoice>(
      CourseSummaryCluster.class, "/items[at0002]/null_flavour", "datePrescriptionIssuedNullFlavour",
      CourseSummaryDatePrescriptionIssuedNullFlavourChoice.class, this);

  public SelectAqlField<CourseSummaryDateDiscontinuedNullFlavourChoice> DATE_DISCONTINUED_NULL_FLAVOUR = new AqlFieldImp<CourseSummaryDateDiscontinuedNullFlavourChoice>(
      CourseSummaryCluster.class, "/items[at0002]/null_flavour", "dateDiscontinuedNullFlavour",
      CourseSummaryDateDiscontinuedNullFlavourChoice.class, this);

  public SelectAqlField<CourseSummaryDateFirstDispensedNullFlavourChoice> DATE_FIRST_DISPENSED_NULL_FLAVOUR = new AqlFieldImp<CourseSummaryDateFirstDispensedNullFlavourChoice>(
      CourseSummaryCluster.class, "/items[at0002]/null_flavour", "dateFirstDispensedNullFlavour",
      CourseSummaryDateFirstDispensedNullFlavourChoice.class, this);

  public SelectAqlField<CourseSummaryDateAdministrationWithheldNullFlavourChoice> DATE_ADMINISTRATION_WITHHELD_NULL_FLAVOUR = new AqlFieldImp<CourseSummaryDateAdministrationWithheldNullFlavourChoice>(
      CourseSummaryCluster.class, "/items[at0002]/null_flavour", "dateAdministrationWithheldNullFlavour",
      CourseSummaryDateAdministrationWithheldNullFlavourChoice.class, this);

  public SelectAqlField<CourseSummaryDateAdministeredChoice> DATE_ADMINISTERED = new AqlFieldImp<CourseSummaryDateAdministeredChoice>(
      CourseSummaryCluster.class, "/items[at0002]/value", "dateAdministered", CourseSummaryDateAdministeredChoice.class,
      this);

  public SelectAqlField<CourseSummaryDateLastAuthorisedChoice> DATE_LAST_AUTHORISED = new AqlFieldImp<CourseSummaryDateLastAuthorisedChoice>(
      CourseSummaryCluster.class, "/items[at0002]/value", "dateLastAuthorised",
      CourseSummaryDateLastAuthorisedChoice.class, this);

  public SelectAqlField<CourseSummaryDateFirstPrescriptionIssuedNullFlavourChoice> DATE_FIRST_PRESCRIPTION_ISSUED_NULL_FLAVOUR = new AqlFieldImp<CourseSummaryDateFirstPrescriptionIssuedNullFlavourChoice>(
      CourseSummaryCluster.class, "/items[at0002]/null_flavour", "dateFirstPrescriptionIssuedNullFlavour",
      CourseSummaryDateFirstPrescriptionIssuedNullFlavourChoice.class, this);

  public SelectAqlField<CourseSummaryDateLastAdministeredChoice> DATE_LAST_ADMINISTERED = new AqlFieldImp<CourseSummaryDateLastAdministeredChoice>(
      CourseSummaryCluster.class, "/items[at0002]/value", "dateLastAdministered",
      CourseSummaryDateLastAdministeredChoice.class, this);

  public SelectAqlField<CourseSummaryDateLastReviewedNullFlavourChoice> DATE_LAST_REVIEWED_NULL_FLAVOUR = new AqlFieldImp<CourseSummaryDateLastReviewedNullFlavourChoice>(
      CourseSummaryCluster.class, "/items[at0002]/null_flavour", "dateLastReviewedNullFlavour",
      CourseSummaryDateLastReviewedNullFlavourChoice.class, this);

  public SelectAqlField<CourseSummaryDateAuthorisedChoice> DATE_AUTHORISED = new AqlFieldImp<CourseSummaryDateAuthorisedChoice>(
      CourseSummaryCluster.class, "/items[at0002]/value", "dateAuthorised", CourseSummaryDateAuthorisedChoice.class,
      this);

  public SelectAqlField<CourseSummaryDateChangedChoice> DATE_CHANGED = new AqlFieldImp<CourseSummaryDateChangedChoice>(
      CourseSummaryCluster.class, "/items[at0002]/value", "dateChanged", CourseSummaryDateChangedChoice.class, this);

  public SelectAqlField<CourseSummaryDateFirstAuthorisedNullFlavourChoice> DATE_FIRST_AUTHORISED_NULL_FLAVOUR = new AqlFieldImp<CourseSummaryDateFirstAuthorisedNullFlavourChoice>(
      CourseSummaryCluster.class, "/items[at0002]/null_flavour", "dateFirstAuthorisedNullFlavour",
      CourseSummaryDateFirstAuthorisedNullFlavourChoice.class, this);

  public SelectAqlField<CourseSummaryDateFirstPrescriptionIssuedChoice> DATE_FIRST_PRESCRIPTION_ISSUED = new AqlFieldImp<CourseSummaryDateFirstPrescriptionIssuedChoice>(
      CourseSummaryCluster.class, "/items[at0002]/value", "dateFirstPrescriptionIssued",
      CourseSummaryDateFirstPrescriptionIssuedChoice.class, this);

  public SelectAqlField<CourseSummaryDateOrderedRecommendedChoice> DATE_ORDERED_RECOMMENDED = new AqlFieldImp<CourseSummaryDateOrderedRecommendedChoice>(
      CourseSummaryCluster.class, "/items[at0002]/value", "dateOrderedRecommended",
      CourseSummaryDateOrderedRecommendedChoice.class, this);

  public SelectAqlField<CourseSummaryDateLastReviewedChoice> DATE_LAST_REVIEWED = new AqlFieldImp<CourseSummaryDateLastReviewedChoice>(
      CourseSummaryCluster.class, "/items[at0002]/value", "dateLastReviewed", CourseSummaryDateLastReviewedChoice.class,
      this);

  public SelectAqlField<CourseSummaryDateFirstAdministeredNullFlavourChoice> DATE_FIRST_ADMINISTERED_NULL_FLAVOUR = new AqlFieldImp<CourseSummaryDateFirstAdministeredNullFlavourChoice>(
      CourseSummaryCluster.class, "/items[at0002]/null_flavour", "dateFirstAdministeredNullFlavour",
      CourseSummaryDateFirstAdministeredNullFlavourChoice.class, this);

  public SelectAqlField<CourseSummaryDateDispensedNullFlavourChoice> DATE_DISPENSED_NULL_FLAVOUR = new AqlFieldImp<CourseSummaryDateDispensedNullFlavourChoice>(
      CourseSummaryCluster.class, "/items[at0002]/null_flavour", "dateDispensedNullFlavour",
      CourseSummaryDateDispensedNullFlavourChoice.class, this);

  public SelectAqlField<CourseSummaryDateFirstAuthorisedChoice> DATE_FIRST_AUTHORISED = new AqlFieldImp<CourseSummaryDateFirstAuthorisedChoice>(
      CourseSummaryCluster.class, "/items[at0002]/value", "dateFirstAuthorised",
      CourseSummaryDateFirstAuthorisedChoice.class, this);

  public SelectAqlField<CourseSummaryDateLastPrescriptionIssuedChoice> DATE_LAST_PRESCRIPTION_ISSUED = new AqlFieldImp<CourseSummaryDateLastPrescriptionIssuedChoice>(
      CourseSummaryCluster.class, "/items[at0002]/value", "dateLastPrescriptionIssued",
      CourseSummaryDateLastPrescriptionIssuedChoice.class, this);

  public SelectAqlField<CourseSummaryDateLastAdministeredNullFlavourChoice> DATE_LAST_ADMINISTERED_NULL_FLAVOUR = new AqlFieldImp<CourseSummaryDateLastAdministeredNullFlavourChoice>(
      CourseSummaryCluster.class, "/items[at0002]/null_flavour", "dateLastAdministeredNullFlavour",
      CourseSummaryDateLastAdministeredNullFlavourChoice.class, this);

  public SelectAqlField<CourseSummaryDateLastAuthorisedNullFlavourChoice> DATE_LAST_AUTHORISED_NULL_FLAVOUR = new AqlFieldImp<CourseSummaryDateLastAuthorisedNullFlavourChoice>(
      CourseSummaryCluster.class, "/items[at0002]/null_flavour", "dateLastAuthorisedNullFlavour",
      CourseSummaryDateLastAuthorisedNullFlavourChoice.class, this);

  public SelectAqlField<CourseSummaryDateLastDispensedChoice> DATE_LAST_DISPENSED = new AqlFieldImp<CourseSummaryDateLastDispensedChoice>(
      CourseSummaryCluster.class, "/items[at0002]/value", "dateLastDispensed",
      CourseSummaryDateLastDispensedChoice.class, this);

  public SelectAqlField<CourseSummaryDateDispensedChoice> DATE_DISPENSED = new AqlFieldImp<CourseSummaryDateDispensedChoice>(
      CourseSummaryCluster.class, "/items[at0002]/value", "dateDispensed", CourseSummaryDateDispensedChoice.class,
      this);

  public SelectAqlField<CourseSummaryDateLastDispensedNullFlavourChoice> DATE_LAST_DISPENSED_NULL_FLAVOUR = new AqlFieldImp<CourseSummaryDateLastDispensedNullFlavourChoice>(
      CourseSummaryCluster.class, "/items[at0002]/null_flavour", "dateLastDispensedNullFlavour",
      CourseSummaryDateLastDispensedNullFlavourChoice.class, this);

  public SelectAqlField<CourseSummaryDateOrderedRecommendedNullFlavourChoice> DATE_ORDERED_RECOMMENDED_NULL_FLAVOUR = new AqlFieldImp<CourseSummaryDateOrderedRecommendedNullFlavourChoice>(
      CourseSummaryCluster.class, "/items[at0002]/null_flavour", "dateOrderedRecommendedNullFlavour",
      CourseSummaryDateOrderedRecommendedNullFlavourChoice.class, this);

  public SelectAqlField<CourseSummaryDateAdministrationWithheldChoice> DATE_ADMINISTRATION_WITHHELD = new AqlFieldImp<CourseSummaryDateAdministrationWithheldChoice>(
      CourseSummaryCluster.class, "/items[at0002]/value", "dateAdministrationWithheld",
      CourseSummaryDateAdministrationWithheldChoice.class, this);

  public SelectAqlField<CourseSummaryDateFirstDispensedChoice> DATE_FIRST_DISPENSED = new AqlFieldImp<CourseSummaryDateFirstDispensedChoice>(
      CourseSummaryCluster.class, "/items[at0002]/value", "dateFirstDispensed",
      CourseSummaryDateFirstDispensedChoice.class, this);

  public SelectAqlField<CourseSummaryDateReviewedChoice> DATE_REVIEWED = new AqlFieldImp<CourseSummaryDateReviewedChoice>(
      CourseSummaryCluster.class, "/items[at0002]/value", "dateReviewed", CourseSummaryDateReviewedChoice.class, this);

  public SelectAqlField<CourseSummaryDateChangedNullFlavourChoice> DATE_CHANGED_NULL_FLAVOUR = new AqlFieldImp<CourseSummaryDateChangedNullFlavourChoice>(
      CourseSummaryCluster.class, "/items[at0002]/null_flavour", "dateChangedNullFlavour",
      CourseSummaryDateChangedNullFlavourChoice.class, this);

  public SelectAqlField<CourseSummaryDatePrescriptionIssuedChoice> DATE_PRESCRIPTION_ISSUED = new AqlFieldImp<CourseSummaryDatePrescriptionIssuedChoice>(
      CourseSummaryCluster.class, "/items[at0002]/value", "datePrescriptionIssued",
      CourseSummaryDatePrescriptionIssuedChoice.class, this);

  public SelectAqlField<CourseSummaryDateAdministeredNullFlavourChoice> DATE_ADMINISTERED_NULL_FLAVOUR = new AqlFieldImp<CourseSummaryDateAdministeredNullFlavourChoice>(
      CourseSummaryCluster.class, "/items[at0002]/null_flavour", "dateAdministeredNullFlavour",
      CourseSummaryDateAdministeredNullFlavourChoice.class, this);

  public SelectAqlField<CourseSummaryDateLastPrescriptionIssuedNullFlavourChoice> DATE_LAST_PRESCRIPTION_ISSUED_NULL_FLAVOUR = new AqlFieldImp<CourseSummaryDateLastPrescriptionIssuedNullFlavourChoice>(
      CourseSummaryCluster.class, "/items[at0002]/null_flavour", "dateLastPrescriptionIssuedNullFlavour",
      CourseSummaryDateLastPrescriptionIssuedNullFlavourChoice.class, this);

  public SelectAqlField<CourseSummaryDateReviewedNullFlavourChoice> DATE_REVIEWED_NULL_FLAVOUR = new AqlFieldImp<CourseSummaryDateReviewedNullFlavourChoice>(
      CourseSummaryCluster.class, "/items[at0002]/null_flavour", "dateReviewedNullFlavour",
      CourseSummaryDateReviewedNullFlavourChoice.class, this);

  public SelectAqlField<CourseSummaryDateAuthorisedNullFlavourChoice> DATE_AUTHORISED_NULL_FLAVOUR = new AqlFieldImp<CourseSummaryDateAuthorisedNullFlavourChoice>(
      CourseSummaryCluster.class, "/items[at0002]/null_flavour", "dateAuthorisedNullFlavour",
      CourseSummaryDateAuthorisedNullFlavourChoice.class, this);

  public SelectAqlField<CourseSummaryDateFirstAdministeredChoice> DATE_FIRST_ADMINISTERED = new AqlFieldImp<CourseSummaryDateFirstAdministeredChoice>(
      CourseSummaryCluster.class, "/items[at0002]/value", "dateFirstAdministered",
      CourseSummaryDateFirstAdministeredChoice.class, this);

  public SelectAqlField<CourseSummaryDateDiscontinuedChoice> DATE_DISCONTINUED = new AqlFieldImp<CourseSummaryDateDiscontinuedChoice>(
      CourseSummaryCluster.class, "/items[at0002]/value", "dateDiscontinued", CourseSummaryDateDiscontinuedChoice.class,
      this);

  private CourseSummaryClusterContainment() {
    super("openEHR-EHR-CLUSTER.medication_course_summary.v0");
  }

  public static CourseSummaryClusterContainment getInstance() {
    return new CourseSummaryClusterContainment();
  }
}
