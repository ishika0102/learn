package com.example.opt.eprescriptionfhircomposition.definition;

import java.lang.Double;
import java.lang.String;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.846315456+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_QUANTITY")
public class MedicationOrderDoseDvQuantity implements RMEntity, MedicationOrderDoseChoice {
   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose
    * pattern/Dose/Dose
    * Description: The value of the amount of medication as a real number.
    * Comment: For example: 1, 1.5, 0.125 or 1-2, 12.5-20.5
    */
   @Path("|magnitude")
   private Double doseMagnitude;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose
    * pattern/Dose/Dose
    * Description: The value of the amount of medication as a real number.
    * Comment: For example: 1, 1.5, 0.125 or 1-2, 12.5-20.5
    */
   @Path("|units")
   private String doseUnits;

   public void setDoseMagnitude(Double doseMagnitude) {
      this.doseMagnitude = doseMagnitude;
   }

   public Double getDoseMagnitude() {
      return this.doseMagnitude;
   }

   public void setDoseUnits(String doseUnits) {
      this.doseUnits = doseUnits;
   }

   public String getDoseUnits() {
      return this.doseUnits;
   }
}
