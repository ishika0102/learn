package com.example.opt.eprescriptionfhircomposition.definition;

import java.lang.String;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.EnumValueSet;

public enum NamedTimeEventDefiningCode implements EnumValueSet {
   AT_NIGHT("at night", "Perform the activity at night.", "local", "at0033"),

   IN_THE_MORNING("in the morning", "Perform the activity in the morning.", "local", "at0032"),

   IN_THE_MORNING_AND_AT_NIGHT("in the morning and at night", "Perform the activity in the morning and at night.",
         "local", "at0034"),

   IMMEDIATELY_STAT("immediately (stat)", "Perform the activity immediately.", "local", "at0031");

   private String value;

   private String description;

   private String terminologyId;

   private String code;

   NamedTimeEventDefiningCode(String value, String description, String terminologyId, String code) {
      this.value = value;
      this.description = description;
      this.terminologyId = terminologyId;
      this.code = code;
   }

   public String getValue() {
      return this.value;
   }

   public String getDescription() {
      return this.description;
   }

   public String getTerminologyId() {
      return this.terminologyId;
   }

   public String getCode() {
      return this.code;
   }
}
