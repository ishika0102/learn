package com.example.opt.eprescriptionfhircomposition.definition;

import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.862243602+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public interface CourseSummaryDatePrescriptionIssuedNullFlavourChoice {
    NullFlavour getDatePrescriptionIssuedNullFlavourDefiningCode();

    void setDatePrescriptionIssuedNullFlavourDefiningCode(
            NullFlavour datePrescriptionIssuedNullFlavourDefiningCode);
}
