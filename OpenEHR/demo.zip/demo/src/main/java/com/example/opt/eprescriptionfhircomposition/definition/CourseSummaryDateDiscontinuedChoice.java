package com.example.opt.eprescriptionfhircomposition.definition;

import java.time.temporal.TemporalAccessor;
import javax.annotation.processing.Generated;

@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.899304519+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public interface CourseSummaryDateDiscontinuedChoice {
  TemporalAccessor getDateDiscontinuedValue();

  void setDateDiscontinuedValue(TemporalAccessor dateDiscontinuedValue);
}
