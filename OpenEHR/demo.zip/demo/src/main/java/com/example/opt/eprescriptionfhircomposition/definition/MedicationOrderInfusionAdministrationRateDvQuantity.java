package com.example.opt.eprescriptionfhircomposition.definition;

import java.lang.Double;
import java.lang.String;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.848522620+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_QUANTITY")
public class MedicationOrderInfusionAdministrationRateDvQuantity
      implements RMEntity, MedicationOrderInfusionAdministrationRateChoice {
   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose
    * pattern/Infusion administration rate/Infusion administration rate
    * Description: The rate at which the medication infusion is to be administered.
    * Comment: For example: 1 drop per minute. Use the text data type to record
    * non- or semi-quantifiable instructions.
    */
   @Path("|magnitude")
   private Double infusionAdministrationRateMagnitude;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose
    * pattern/Infusion administration rate/Infusion administration rate
    * Description: The rate at which the medication infusion is to be administered.
    * Comment: For example: 1 drop per minute. Use the text data type to record
    * non- or semi-quantifiable instructions.
    */
   @Path("|units")
   private String infusionAdministrationRateUnits;

   public void setInfusionAdministrationRateMagnitude(Double infusionAdministrationRateMagnitude) {
      this.infusionAdministrationRateMagnitude = infusionAdministrationRateMagnitude;
   }

   public Double getInfusionAdministrationRateMagnitude() {
      return this.infusionAdministrationRateMagnitude;
   }

   public void setInfusionAdministrationRateUnits(String infusionAdministrationRateUnits) {
      this.infusionAdministrationRateUnits = infusionAdministrationRateUnits;
   }

   public String getInfusionAdministrationRateUnits() {
      return this.infusionAdministrationRateUnits;
   }
}
