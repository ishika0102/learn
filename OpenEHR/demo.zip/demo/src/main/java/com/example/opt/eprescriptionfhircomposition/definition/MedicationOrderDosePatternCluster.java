package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import com.nedap.archie.rm.datastructures.Cluster;
import java.lang.String;
import java.time.temporal.TemporalAmount;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Choice;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.836045458+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class MedicationOrderDosePatternCluster implements LocatableEntity {
   /**
    * Path: Prescription/Medication order/Order/Tree/Dose direction/Dose
    * pattern/Dose/null_flavour
    */
   @Path("/items[at0144 and name/value='Dose']/null_flavour|defining_code")
   private NullFlavour doseNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * unit
    * Description: The dose unit of the amount of medication.
    * Comment: For example: 'tablet','mg'. Coding of the dose unit with a
    * terminology is preferred, where possible.
    */
   @Path("/items[at0145]/value|value")
   private String doseUnitValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Dose direction/Dose
    * pattern/Dose unit/null_flavour
    */
   @Path("/items[at0145]/null_flavour|defining_code")
   private NullFlavour doseUnitNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing
    * Description: Structured information about the timing (intended or actual) of
    * administration or use of a medicine, other therapeutic good or other
    * intervention that is given on a scheduled basis.
    */
   @Path("/items[openEHR-EHR-CLUSTER.timing_daily.v0 and name/value='Dose timing']")
   private DoseTimingCluster doseTiming;

   /**
    * Path: Prescription/Medication order/Order/Tree/Dose direction/Dose
    * pattern/Infusion administration rate/null_flavour
    */
   @Path("/items[at0134]/null_flavour|defining_code")
   private NullFlavour infusionAdministrationRateNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * administration duration
    * Description: The period of time over which a single dose of the medication or
    * vaccine should be administered.
    * Comment: For example: 'Administer over 10 minutes'.
    */
   @Path("/items[at0102]/value|value")
   private TemporalAmount doseAdministrationDurationValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Dose direction/Dose
    * pattern/Dose administration duration/null_flavour
    */
   @Path("/items[at0102]/null_flavour|defining_code")
   private NullFlavour doseAdministrationDurationNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose
    * pattern/Conditional administration
    * Description: Details of dose amount / administration rate dependent on
    * specific conditions.
    */
   @Path("/items[at0156]")
   private Cluster<?> conditionalAdministration;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose
    * pattern/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * Description: The value of the amount of medication as a real number.
    * Comment: For example: 1, 1.5, 0.125 or 1-2, 12.5-20.5
    */
   @Path("/items[at0144 and name/value='Dose']/value")
   @Choice
   private MedicationOrderDoseChoice dose;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose
    * pattern/Infusion administration rate
    * Description: The rate at which the medication infusion is to be administered.
    * Comment: For example: 1 drop per minute. Use the text data type to record
    * non- or semi-quantifiable instructions.
    */
   @Path("/items[at0134]/value")
   @Choice
   private MedicationOrderInfusionAdministrationRateChoice infusionAdministrationRate;

   public void setDoseNullFlavourDefiningCode(NullFlavour doseNullFlavourDefiningCode) {
      this.doseNullFlavourDefiningCode = doseNullFlavourDefiningCode;
   }

   public NullFlavour getDoseNullFlavourDefiningCode() {
      return this.doseNullFlavourDefiningCode;
   }

   public void setDoseUnitValue(String doseUnitValue) {
      this.doseUnitValue = doseUnitValue;
   }

   public String getDoseUnitValue() {
      return this.doseUnitValue;
   }

   public void setDoseUnitNullFlavourDefiningCode(NullFlavour doseUnitNullFlavourDefiningCode) {
      this.doseUnitNullFlavourDefiningCode = doseUnitNullFlavourDefiningCode;
   }

   public NullFlavour getDoseUnitNullFlavourDefiningCode() {
      return this.doseUnitNullFlavourDefiningCode;
   }

   public void setDoseTiming(DoseTimingCluster doseTiming) {
      this.doseTiming = doseTiming;
   }

   public DoseTimingCluster getDoseTiming() {
      return this.doseTiming;
   }

   public void setInfusionAdministrationRateNullFlavourDefiningCode(
         NullFlavour infusionAdministrationRateNullFlavourDefiningCode) {
      this.infusionAdministrationRateNullFlavourDefiningCode = infusionAdministrationRateNullFlavourDefiningCode;
   }

   public NullFlavour getInfusionAdministrationRateNullFlavourDefiningCode() {
      return this.infusionAdministrationRateNullFlavourDefiningCode;
   }

   public void setDoseAdministrationDurationValue(TemporalAmount doseAdministrationDurationValue) {
      this.doseAdministrationDurationValue = doseAdministrationDurationValue;
   }

   public TemporalAmount getDoseAdministrationDurationValue() {
      return this.doseAdministrationDurationValue;
   }

   public void setDoseAdministrationDurationNullFlavourDefiningCode(
         NullFlavour doseAdministrationDurationNullFlavourDefiningCode) {
      this.doseAdministrationDurationNullFlavourDefiningCode = doseAdministrationDurationNullFlavourDefiningCode;
   }

   public NullFlavour getDoseAdministrationDurationNullFlavourDefiningCode() {
      return this.doseAdministrationDurationNullFlavourDefiningCode;
   }

   public void setConditionalAdministration(Cluster<?> conditionalAdministration) {
      this.conditionalAdministration = conditionalAdministration;
   }

   public Cluster<?> getConditionalAdministration() {
      return this.conditionalAdministration;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }

   public void setDose(MedicationOrderDoseChoice dose) {
      this.dose = dose;
   }

   public MedicationOrderDoseChoice getDose() {
      return this.dose;
   }

   public void setInfusionAdministrationRate(
         MedicationOrderInfusionAdministrationRateChoice infusionAdministrationRate) {
      this.infusionAdministrationRate = infusionAdministrationRate;
   }

   public MedicationOrderInfusionAdministrationRateChoice getInfusionAdministrationRate() {
      return this.infusionAdministrationRate;
   }
}
