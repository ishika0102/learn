package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import java.lang.Long;
import java.time.temporal.TemporalAccessor;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Archetype;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Archetype("openEHR-EHR-CLUSTER.medication_authorisation.v0")
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.900215452+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class AuthorisationDetailsCluster implements LocatableEntity {
   /**
    * Path: Prescription/Medication order/Order/Authorisation
    * details/numberOfRepeatsAllowed
    * Description: The number of times the expressed quantity of medicine, vaccine
    * or other therapeutic good may be refilled or redispensed without a new
    * prescription.
    */
   @Path("/items[at0025 and name/value='numberOfRepeatsAllowed']/value|magnitude")
   private Long numberofrepeatsallowedMagnitude;

   /**
    * Path: Prescription/Medication order/Order/Tree/Authorisation
    * details/numberOfRepeatsAllowed/null_flavour
    */
   @Path("/items[at0025 and name/value='numberOfRepeatsAllowed']/null_flavour|defining_code")
   private NullFlavour numberofrepeatsallowedNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Authorisation
    * details/validityPeriod
    * Description: The repeat supply authorisation has expired after this date.
    */
   @Path("/items[at0072 and name/value='validityPeriod']/value|value")
   private TemporalAccessor validityperiodValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Authorisation
    * details/validityPeriod/null_flavour
    */
   @Path("/items[at0072 and name/value='validityPeriod']/null_flavour|defining_code")
   private NullFlavour validityperiodNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Authorisation details/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   public void setNumberofrepeatsallowedMagnitude(Long numberofrepeatsallowedMagnitude) {
      this.numberofrepeatsallowedMagnitude = numberofrepeatsallowedMagnitude;
   }

   public Long getNumberofrepeatsallowedMagnitude() {
      return this.numberofrepeatsallowedMagnitude;
   }

   public void setNumberofrepeatsallowedNullFlavourDefiningCode(
         NullFlavour numberofrepeatsallowedNullFlavourDefiningCode) {
      this.numberofrepeatsallowedNullFlavourDefiningCode = numberofrepeatsallowedNullFlavourDefiningCode;
   }

   public NullFlavour getNumberofrepeatsallowedNullFlavourDefiningCode() {
      return this.numberofrepeatsallowedNullFlavourDefiningCode;
   }

   public void setValidityperiodValue(TemporalAccessor validityperiodValue) {
      this.validityperiodValue = validityperiodValue;
   }

   public TemporalAccessor getValidityperiodValue() {
      return this.validityperiodValue;
   }

   public void setValidityperiodNullFlavourDefiningCode(
         NullFlavour validityperiodNullFlavourDefiningCode) {
      this.validityperiodNullFlavourDefiningCode = validityperiodNullFlavourDefiningCode;
   }

   public NullFlavour getValidityperiodNullFlavourDefiningCode() {
      return this.validityperiodNullFlavourDefiningCode;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }
}
