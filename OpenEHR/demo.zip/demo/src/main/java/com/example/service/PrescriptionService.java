package com.example.service;

import org.ehrbase.client.openehrclient.defaultrestclient.DefaultRestClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class PrescriptionService {
        private final DefaultRestClient client;

        @Autowired
        public PrescriptionService(DefaultRestClient client) {
                this.client = client;
        }

        public UUID createEhr() {
                return client.ehrEndpoint().createEhr();
        }

}
