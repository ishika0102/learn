package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import java.lang.Double;
import java.lang.String;
import java.time.temporal.TemporalAmount;
import org.ehrbase.openehr.sdk.generator.commons.aql.containment.Containment;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.AqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.SelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

public class DispenseAmountClusterContainment extends Containment {
  public SelectAqlField<DispenseAmountCluster> DISPENSE_AMOUNT_CLUSTER = new AqlFieldImp<DispenseAmountCluster>(
      DispenseAmountCluster.class, "", "DispenseAmountCluster", DispenseAmountCluster.class, this);

  public SelectAqlField<String> AMOUNT_DESCRIPTION_VALUE = new AqlFieldImp<String>(DispenseAmountCluster.class,
      "/items[at0161]/value|value", "amountDescriptionValue", String.class, this);

  public SelectAqlField<NullFlavour> AMOUNT_DESCRIPTION_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      DispenseAmountCluster.class, "/items[at0161]/null_flavour|defining_code",
      "amountDescriptionNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<Double> AMOUNT_MAGNITUDE = new AqlFieldImp<Double>(DispenseAmountCluster.class,
      "/items[at0131]/value|magnitude", "amountMagnitude", Double.class, this);

  public SelectAqlField<String> AMOUNT_UNITS = new AqlFieldImp<String>(DispenseAmountCluster.class,
      "/items[at0131]/value|units", "amountUnits", String.class, this);

  public SelectAqlField<NullFlavour> AMOUNT_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      DispenseAmountCluster.class, "/items[at0131]/null_flavour|defining_code", "amountNullFlavourDefiningCode",
      NullFlavour.class, this);

  public SelectAqlField<String> UNITS_VALUE = new AqlFieldImp<String>(DispenseAmountCluster.class,
      "/items[at0147]/value|value", "unitsValue", String.class, this);

  public SelectAqlField<NullFlavour> UNITS_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      DispenseAmountCluster.class, "/items[at0147]/null_flavour|defining_code", "unitsNullFlavourDefiningCode",
      NullFlavour.class, this);

  public SelectAqlField<TemporalAmount> DURATION_OF_SUPPLY_VALUE = new AqlFieldImp<TemporalAmount>(
      DispenseAmountCluster.class, "/items[at0142]/value|value", "durationOfSupplyValue", TemporalAmount.class, this);

  public SelectAqlField<NullFlavour> DURATION_OF_SUPPLY_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      DispenseAmountCluster.class, "/items[at0142]/null_flavour|defining_code",
      "durationOfSupplyNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<FeederAudit> FEEDER_AUDIT = new AqlFieldImp<FeederAudit>(DispenseAmountCluster.class,
      "/feeder_audit", "feederAudit", FeederAudit.class, this);

  private DispenseAmountClusterContainment() {
    super("openEHR-EHR-CLUSTER.medication_supply_amount.v0");
  }

  public static DispenseAmountClusterContainment getInstance() {
    return new DispenseAmountClusterContainment();
  }
}
