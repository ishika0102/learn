package com.example.opt.eprescriptionfhircomposition.definition;

import java.lang.String;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.840345843+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_TEXT")
public class DoseTimingNamedTimeEventDvText implements RMEntity, DoseTimingNamedTimeEventChoice {
   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Named time event/Named time event
    * Description: A specific, named time event within a single day, when the
    * activity should occur.
    * Comment: e.g. before each meal, at bedtime, in the morning.
    * It is understood that these terms may not equate to the same exact times in
    * different cultures.
    */
   @Path("|value")
   private String namedTimeEventValue;

   public void setNamedTimeEventValue(String namedTimeEventValue) {
      this.namedTimeEventValue = namedTimeEventValue;
   }

   public String getNamedTimeEventValue() {
      return this.namedTimeEventValue;
   }
}
