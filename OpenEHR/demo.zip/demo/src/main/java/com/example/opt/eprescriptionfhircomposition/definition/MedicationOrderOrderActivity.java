package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import com.nedap.archie.rm.datastructures.Cluster;
import com.nedap.archie.rm.datavalues.encapsulated.DvParsable;
import java.lang.Double;
import java.lang.String;
import java.time.temporal.TemporalAmount;
import java.util.List;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.808738232+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class MedicationOrderOrderActivity implements LocatableEntity {
   /**
    * Path: Prescription/Medication order/Order/Medication item
    * Description: Identification of the medication, vaccine or other therapeutic
    * item being ordered.
    * Comment: It is strongly recommended that the 'Medication item' be coded with
    * a terminology capable of triggering decision support, where possible. The
    * extent of coding may vary from the simple name of the medication item through
    * to structured details about the actual medication pack to be used. Free text
    * entry should only be used if there is no appropriate terminology available.
    */
   @Path("/description[at0002]/items[at0070]/value|value")
   private String medicationItemValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Medication item/null_flavour
    */
   @Path("/description[at0002]/items[at0070]/null_flavour|defining_code")
   private NullFlavour medicationItemNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Preparation
    * Description: The strength and form of the medication substance, including
    * details of specific ingredients where required by an ad-hoc preparation or
    * infusion.
    * Comment: This is commonly carried as part of the medicine name and provided
    * by the medicines terminology but in some cases must be specified separately.
    */
   @Path("/description[at0002]/items[openEHR-EHR-CLUSTER.medication_substance.v0 and name/value='Preparation']")
   private PreparationCluster preparation;

   /**
    * Path: Prescription/Medication order/Order/Route
    * Description: The route of administration.
    * Comment: For example: 'oral', 'intravenous', or 'topical'.
    * Coding of the route with a terminology is preferred, where possible. Multiple
    * potential routes may be specified.
    */
   @Path("/description[at0002]/items[at0091]")
   private List<MedicationOrderRouteElement> route;

   /**
    * Path: Prescription/Medication order/Order/dosageInstructions
    * Description: Complete narrative description about how the medication is to be
    * used.
    * Comment: Including the amount, when to take it and additional instructions
    * for use. Where the medication dose directions are fully carried by the
    * structured, computable dose directions, this element should carry the
    * narrative equivalent, generally auto-generated. If it is not possible to
    * represent the intended dosage directions fully in computable form, partial
    * representation is not recommended, and the directions should be only recorded
    * in narrative form using this data element.
    */
   @Path("/description[at0002]/items[at0009 and name/value='dosageInstructions']/value|value")
   private String dosageinstructionsValue;

   /**
    * Path: Prescription/Medication
    * order/Order/Tree/dosageInstructions/null_flavour
    */
   @Path("/description[at0002]/items[at0009 and name/value='dosageInstructions']/null_flavour|defining_code")
   private NullFlavour dosageinstructionsNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Dose direction
    * Description: Details about a dose direction for the medication order.
    * Comment: For example: '1 tab in the morning, 1 tab at night, for 3 weeks, on
    * Mondays, Wednesdays and Fridays'. This cluster allows multiple occurrences to
    * enable representation of a complete set of dose directions for a single
    * medication order.
    */
   @Path("/description[at0002]/items[at0056]")
   private List<MedicationOrderDoseDirectionCluster> doseDirection;

   /**
    * Path: Prescription/Medication order/Order/Medication
    * safety/maxDosePerPeriod/Maximum amount
    * Description: The maximum amount of medication allowed in the allowed period.
    * Comment: For example: 1, 1.5, 0.125.
    */
   @Path("/description[at0002]/items[at0062]/items[at0051 and name/value='maxDosePerPeriod']/items[at0130]/value|magnitude")
   private Double maximumAmountMagnitude;

   /**
    * Path: Prescription/Medication order/Order/Medication
    * safety/maxDosePerPeriod/Maximum amount
    * Description: The maximum amount of medication allowed in the allowed period.
    * Comment: For example: 1, 1.5, 0.125.
    */
   @Path("/description[at0002]/items[at0062]/items[at0051 and name/value='maxDosePerPeriod']/items[at0130]/value|units")
   private String maximumAmountUnits;

   /**
    * Path: Prescription/Medication order/Order/Tree/Medication
    * safety/maxDosePerPeriod/Maximum amount/null_flavour
    */
   @Path("/description[at0002]/items[at0062]/items[at0051 and name/value='maxDosePerPeriod']/items[at0130]/null_flavour|defining_code")
   private NullFlavour maximumAmountNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Medication
    * safety/maxDosePerPeriod/Maximum amount dose unit
    * Description: The dose unit for the maximum amount allowed.
    * Comment: For example: 'tablet','mg'. Coding of the dose unit with a
    * terminology is preferred, where possible.
    */
   @Path("/description[at0002]/items[at0062]/items[at0051 and name/value='maxDosePerPeriod']/items[at0146]/value|value")
   private String maximumAmountDoseUnitValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Medication
    * safety/maxDosePerPeriod/Maximum amount dose unit/null_flavour
    */
   @Path("/description[at0002]/items[at0062]/items[at0051 and name/value='maxDosePerPeriod']/items[at0146]/null_flavour|defining_code")
   private NullFlavour maximumAmountDoseUnitNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Medication
    * safety/maxDosePerPeriod/Allowed period
    * Description: The period of time during which the maximum dose is calculated.
    */
   @Path("/description[at0002]/items[at0062]/items[at0051 and name/value='maxDosePerPeriod']/items[at0053]/value|value")
   private TemporalAmount allowedPeriodValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Medication
    * safety/maxDosePerPeriod/Allowed period/null_flavour
    */
   @Path("/description[at0002]/items[at0062]/items[at0051 and name/value='maxDosePerPeriod']/items[at0053]/null_flavour|defining_code")
   private NullFlavour allowedPeriodNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Medication safety/Override reason
    * Description: The reason for a maximum dose override.
    * Comment: For example: 'Not responsive at maximum recommended dose. Critical
    * situation.'
    */
   @Path("/description[at0002]/items[at0062]/items[at0162]/value|value")
   private String overrideReasonValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Medication safety/Override
    * reason/null_flavour
    */
   @Path("/description[at0002]/items[at0062]/items[at0162]/null_flavour|defining_code")
   private NullFlavour overrideReasonNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/additionalInstructions
    * Description: An additional instruction on how to use the medication, vaccine
    * or other therapeutic good.
    * Comment: For example: precautions as 'take with food', 'Avoid grapefruit',
    * 'Dissolve in water'. This data element allows multiple occurrences and should
    * be coded with a reference terminology, where possible.
    */
   @Path("/description[at0002]/items[at0044 and name/value='additionalInstructions']/value|value")
   private String additionalinstructionsValue;

   /**
    * Path: Prescription/Medication
    * order/Order/Tree/additionalInstructions/null_flavour
    */
   @Path("/description[at0002]/items[at0044 and name/value='additionalInstructions']/null_flavour|defining_code")
   private NullFlavour additionalinstructionsNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/reason
    * Description: The clinical reason for ordering the medication, vaccine or
    * other therapeutic good.
    * Comment: For example: 'Angina'. Coding of the clinical indication with a
    * terminology is preferred, where possible. This data element allows multiple
    * occurrences.
    */
   @Path("/description[at0002]/items[at0018 and name/value='reason']/value|value")
   private String reasonValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/reason/null_flavour
    */
   @Path("/description[at0002]/items[at0018 and name/value='reason']/null_flavour|defining_code")
   private NullFlavour reasonNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary
    * Description: Overall summary of the medication course.
    */
   @Path("/description[at0002]/items[at0113]/items[openEHR-EHR-CLUSTER.medication_course_summary.v0 and name/value='Course summary']")
   private CourseSummaryCluster courseSummary;

   /**
    * Path: Prescription/Medication order/Order/Authorisation details
    * Description: Details of the authorisation of a medicine, vaccine or other
    * therapeutic good.
    */
   @Path("/description[at0002]/items[openEHR-EHR-CLUSTER.medication_authorisation.v0 and name/value='Authorisation details']")
   private AuthorisationDetailsCluster authorisationDetails;

   /**
    * Path: Prescription/Medication order/Order/Dispense directions/Dispense
    * instruction
    * Description: An additional instruction directed primarily at the person
    * dispensing the medication, vaccine or therapeutic good.
    */
   @Path("/description[at0002]/items[at0129]/items[at0106]")
   private List<MedicationOrderDispenseInstructionElement> dispenseInstruction;

   /**
    * Path: Prescription/Medication order/Order/Dispense directions/Dispense amount
    * Description: Details related to the amount of a medication, vaccine or other
    * therapeutic item to be supplied or supplied to the patient, as part of
    * authorisation, dispensing or administration.
    */
   @Path("/description[at0002]/items[at0129]/items[openEHR-EHR-CLUSTER.medication_supply_amount.v0 and name/value='Dispense amount']")
   private DispenseAmountCluster dispenseAmount;

   /**
    * Path: Prescription/Medication order/Order/Dispense directions/Dispense
    * details
    * Description: Further details related to dispense directions.
    * Comment: This SLOT allows for local variation in the different jurisdictions
    * regarding medication dispensing.
    */
   @Path("/description[at0002]/items[at0129]/items[at0170]")
   private List<Cluster<?>> dispenseDetails;

   /**
    * Path: Prescription/Medication order/Order/Additional details
    * Description: Additional structured details about the medication order not
    * captured in other fields.
    */
   @Path("/description[at0002]/items[at0166]")
   private List<Cluster<?>> additionalDetails;

   /**
    * Path: Prescription/Medication order/Order/Comment
    * Description: Additional narrative about the medication order not captured in
    * other fields.
    */
   @Path("/description[at0002]/items[at0167]/value|value")
   private String commentValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Comment/null_flavour
    */
   @Path("/description[at0002]/items[at0167]/null_flavour|defining_code")
   private NullFlavour commentNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/timing
    */
   @Path("/timing")
   private DvParsable timing;

   /**
    * Path: Prescription/Medication order/Order/action_archetype_id
    */
   @Path("/action_archetype_id")
   private String actionArchetypeId;

   /**
    * Path: Prescription/Medication order/Order/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   public void setMedicationItemValue(String medicationItemValue) {
      this.medicationItemValue = medicationItemValue;
   }

   public String getMedicationItemValue() {
      return this.medicationItemValue;
   }

   public void setMedicationItemNullFlavourDefiningCode(
         NullFlavour medicationItemNullFlavourDefiningCode) {
      this.medicationItemNullFlavourDefiningCode = medicationItemNullFlavourDefiningCode;
   }

   public NullFlavour getMedicationItemNullFlavourDefiningCode() {
      return this.medicationItemNullFlavourDefiningCode;
   }

   public void setPreparation(PreparationCluster preparation) {
      this.preparation = preparation;
   }

   public PreparationCluster getPreparation() {
      return this.preparation;
   }

   public void setRoute(List<MedicationOrderRouteElement> route) {
      this.route = route;
   }

   public List<MedicationOrderRouteElement> getRoute() {
      return this.route;
   }

   public void setDosageinstructionsValue(String dosageinstructionsValue) {
      this.dosageinstructionsValue = dosageinstructionsValue;
   }

   public String getDosageinstructionsValue() {
      return this.dosageinstructionsValue;
   }

   public void setDosageinstructionsNullFlavourDefiningCode(
         NullFlavour dosageinstructionsNullFlavourDefiningCode) {
      this.dosageinstructionsNullFlavourDefiningCode = dosageinstructionsNullFlavourDefiningCode;
   }

   public NullFlavour getDosageinstructionsNullFlavourDefiningCode() {
      return this.dosageinstructionsNullFlavourDefiningCode;
   }

   public void setDoseDirection(List<MedicationOrderDoseDirectionCluster> doseDirection) {
      this.doseDirection = doseDirection;
   }

   public List<MedicationOrderDoseDirectionCluster> getDoseDirection() {
      return this.doseDirection;
   }

   public void setMaximumAmountMagnitude(Double maximumAmountMagnitude) {
      this.maximumAmountMagnitude = maximumAmountMagnitude;
   }

   public Double getMaximumAmountMagnitude() {
      return this.maximumAmountMagnitude;
   }

   public void setMaximumAmountUnits(String maximumAmountUnits) {
      this.maximumAmountUnits = maximumAmountUnits;
   }

   public String getMaximumAmountUnits() {
      return this.maximumAmountUnits;
   }

   public void setMaximumAmountNullFlavourDefiningCode(
         NullFlavour maximumAmountNullFlavourDefiningCode) {
      this.maximumAmountNullFlavourDefiningCode = maximumAmountNullFlavourDefiningCode;
   }

   public NullFlavour getMaximumAmountNullFlavourDefiningCode() {
      return this.maximumAmountNullFlavourDefiningCode;
   }

   public void setMaximumAmountDoseUnitValue(String maximumAmountDoseUnitValue) {
      this.maximumAmountDoseUnitValue = maximumAmountDoseUnitValue;
   }

   public String getMaximumAmountDoseUnitValue() {
      return this.maximumAmountDoseUnitValue;
   }

   public void setMaximumAmountDoseUnitNullFlavourDefiningCode(
         NullFlavour maximumAmountDoseUnitNullFlavourDefiningCode) {
      this.maximumAmountDoseUnitNullFlavourDefiningCode = maximumAmountDoseUnitNullFlavourDefiningCode;
   }

   public NullFlavour getMaximumAmountDoseUnitNullFlavourDefiningCode() {
      return this.maximumAmountDoseUnitNullFlavourDefiningCode;
   }

   public void setAllowedPeriodValue(TemporalAmount allowedPeriodValue) {
      this.allowedPeriodValue = allowedPeriodValue;
   }

   public TemporalAmount getAllowedPeriodValue() {
      return this.allowedPeriodValue;
   }

   public void setAllowedPeriodNullFlavourDefiningCode(
         NullFlavour allowedPeriodNullFlavourDefiningCode) {
      this.allowedPeriodNullFlavourDefiningCode = allowedPeriodNullFlavourDefiningCode;
   }

   public NullFlavour getAllowedPeriodNullFlavourDefiningCode() {
      return this.allowedPeriodNullFlavourDefiningCode;
   }

   public void setOverrideReasonValue(String overrideReasonValue) {
      this.overrideReasonValue = overrideReasonValue;
   }

   public String getOverrideReasonValue() {
      return this.overrideReasonValue;
   }

   public void setOverrideReasonNullFlavourDefiningCode(
         NullFlavour overrideReasonNullFlavourDefiningCode) {
      this.overrideReasonNullFlavourDefiningCode = overrideReasonNullFlavourDefiningCode;
   }

   public NullFlavour getOverrideReasonNullFlavourDefiningCode() {
      return this.overrideReasonNullFlavourDefiningCode;
   }

   public void setAdditionalinstructionsValue(String additionalinstructionsValue) {
      this.additionalinstructionsValue = additionalinstructionsValue;
   }

   public String getAdditionalinstructionsValue() {
      return this.additionalinstructionsValue;
   }

   public void setAdditionalinstructionsNullFlavourDefiningCode(
         NullFlavour additionalinstructionsNullFlavourDefiningCode) {
      this.additionalinstructionsNullFlavourDefiningCode = additionalinstructionsNullFlavourDefiningCode;
   }

   public NullFlavour getAdditionalinstructionsNullFlavourDefiningCode() {
      return this.additionalinstructionsNullFlavourDefiningCode;
   }

   public void setReasonValue(String reasonValue) {
      this.reasonValue = reasonValue;
   }

   public String getReasonValue() {
      return this.reasonValue;
   }

   public void setReasonNullFlavourDefiningCode(NullFlavour reasonNullFlavourDefiningCode) {
      this.reasonNullFlavourDefiningCode = reasonNullFlavourDefiningCode;
   }

   public NullFlavour getReasonNullFlavourDefiningCode() {
      return this.reasonNullFlavourDefiningCode;
   }

   public void setCourseSummary(CourseSummaryCluster courseSummary) {
      this.courseSummary = courseSummary;
   }

   public CourseSummaryCluster getCourseSummary() {
      return this.courseSummary;
   }

   public void setAuthorisationDetails(AuthorisationDetailsCluster authorisationDetails) {
      this.authorisationDetails = authorisationDetails;
   }

   public AuthorisationDetailsCluster getAuthorisationDetails() {
      return this.authorisationDetails;
   }

   public void setDispenseInstruction(
         List<MedicationOrderDispenseInstructionElement> dispenseInstruction) {
      this.dispenseInstruction = dispenseInstruction;
   }

   public List<MedicationOrderDispenseInstructionElement> getDispenseInstruction() {
      return this.dispenseInstruction;
   }

   public void setDispenseAmount(DispenseAmountCluster dispenseAmount) {
      this.dispenseAmount = dispenseAmount;
   }

   public DispenseAmountCluster getDispenseAmount() {
      return this.dispenseAmount;
   }

   public void setDispenseDetails(List<Cluster<?>> dispenseDetails) {
      this.dispenseDetails = dispenseDetails;
   }

   public List<Cluster<?>> getDispenseDetails() {
      return this.dispenseDetails;
   }

   public void setAdditionalDetails(List<Cluster<?>> additionalDetails) {
      this.additionalDetails = additionalDetails;
   }

   public List<Cluster<?>> getAdditionalDetails() {
      return this.additionalDetails;
   }

   public void setCommentValue(String commentValue) {
      this.commentValue = commentValue;
   }

   public String getCommentValue() {
      return this.commentValue;
   }

   public void setCommentNullFlavourDefiningCode(NullFlavour commentNullFlavourDefiningCode) {
      this.commentNullFlavourDefiningCode = commentNullFlavourDefiningCode;
   }

   public NullFlavour getCommentNullFlavourDefiningCode() {
      return this.commentNullFlavourDefiningCode;
   }

   public void setTiming(DvParsable timing) {
      this.timing = timing;
   }

   public DvParsable getTiming() {
      return this.timing;
   }

   public void setActionArchetypeId(String actionArchetypeId) {
      this.actionArchetypeId = actionArchetypeId;
   }

   public String getActionArchetypeId() {
      return this.actionArchetypeId;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }
}
