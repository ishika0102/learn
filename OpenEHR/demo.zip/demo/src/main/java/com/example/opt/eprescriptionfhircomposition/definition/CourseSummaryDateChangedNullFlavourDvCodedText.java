package com.example.opt.eprescriptionfhircomposition.definition;

import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.894205741+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_CODED_TEXT")
public class CourseSummaryDateChangedNullFlavourDvCodedText
    implements RMEntity, CourseSummaryDateChangedNullFlavourChoice {
  /**
   * Path: Prescription/Medication order/Order/Tree/Order details/Course
   * summary/Date changed/null_flavour/null_flavour
   */
  @Path("|defining_code")
  private NullFlavour dateChangedNullFlavourDefiningCode;

  public void setDateChangedNullFlavourDefiningCode(
      NullFlavour dateChangedNullFlavourDefiningCode) {
    this.dateChangedNullFlavourDefiningCode = dateChangedNullFlavourDefiningCode;
  }

  public NullFlavour getDateChangedNullFlavourDefiningCode() {
    return this.dateChangedNullFlavourDefiningCode;
  }
}
