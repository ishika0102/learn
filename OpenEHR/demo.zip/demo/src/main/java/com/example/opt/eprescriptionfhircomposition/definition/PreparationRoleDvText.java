package com.example.opt.eprescriptionfhircomposition.definition;

import java.lang.String;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.824302791+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_TEXT")
public class PreparationRoleDvText implements RMEntity, PreparationRoleChoice {
   /**
    * Path: Prescription/Medication order/Order/Preparation/Ingredient/Role/Role
    * Description: The role of the ingredient within the mixture or infusion.
    */
   @Path("|value")
   private String roleValue;

   public void setRoleValue(String roleValue) {
      this.roleValue = roleValue;
   }

   public String getRoleValue() {
      return this.roleValue;
   }
}
