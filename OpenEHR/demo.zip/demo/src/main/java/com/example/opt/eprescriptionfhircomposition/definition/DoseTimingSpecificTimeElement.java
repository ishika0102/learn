package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Choice;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.837698031+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class DoseTimingSpecificTimeElement implements LocatableEntity {
   /**
    * Path: Prescription/Medication order/Order/Tree/Dose direction/Dose
    * pattern/Dose timing/Specific time/null_flavour
    */
   @Path("/null_flavour|defining_code")
   private NullFlavour value;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Specific time
    * Description: A specific time or interval of time during a single day when the
    * activity should occur.
    * Comment: e.g "at 0800, 1400, 15.25."
    */
   @Path("/value")
   @Choice
   private DoseTimingSpecificTimeChoice value2;

   public void setValue(NullFlavour value) {
      this.value = value;
   }

   public NullFlavour getValue() {
      return this.value;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }

   public void setValue2(DoseTimingSpecificTimeChoice value2) {
      this.value2 = value2;
   }

   public DoseTimingSpecificTimeChoice getValue2() {
      return this.value2;
   }
}
