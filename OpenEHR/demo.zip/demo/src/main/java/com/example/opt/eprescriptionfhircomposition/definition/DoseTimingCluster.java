package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import java.lang.Boolean;
import java.lang.String;
import java.time.temporal.TemporalAmount;
import java.util.List;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Archetype;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Choice;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Archetype("openEHR-EHR-CLUSTER.timing_daily.v0")
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.836979202+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class DoseTimingCluster implements LocatableEntity {
   /**
    * Path: Prescription/Medication order/Order/Tree/Dose direction/Dose
    * pattern/Dose timing/Frequency/null_flavour
    */
   @Path("/items[at0003]/null_flavour|defining_code")
   private NullFlavour frequencyNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Interval
    * Description: The time interval or minimum and maximum range of an interval
    * between each scheduled activity, limited to a single day.
    * Comment: e.g. "Every 4 hours" or "Every 4 to 6 hours".
    */
   @Path("/items[at0014]/value|value")
   private TemporalAmount intervalValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Dose direction/Dose
    * pattern/Dose timing/Interval/null_flavour
    */
   @Path("/items[at0014]/null_flavour|defining_code")
   private NullFlavour intervalNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Specific time
    * Description: A specific time or interval of time during a single day when the
    * activity should occur.
    * Comment: e.g "at 0800, 1400, 15.25."
    */
   @Path("/items[at0004]")
   private List<DoseTimingSpecificTimeElement> specificTime;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Named time event
    * Description: A specific, named time event within a single day, when the
    * activity should occur.
    * Comment: e.g. before each meal, at bedtime, in the morning.
    * It is understood that these terms may not equate to the same exact times in
    * different cultures.
    */
   @Path("/items[at0026]")
   private List<DoseTimingNamedTimeEventElement> namedTimeEvent;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Exact timing critical
    * Description: Is exact timing of the activity critical to patient safety or
    * wellbeing?
    */
   @Path("/items[at0023]/value|value")
   private Boolean exactTimingCriticalValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Dose direction/Dose
    * pattern/Dose timing/Exact timing critical/null_flavour
    */
   @Path("/items[at0023]/null_flavour|defining_code")
   private NullFlavour exactTimingCriticalNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/As required
    * Description: The activity should only occur when the "as required" trigger
    * condition is met.
    * Comment: Termed 'PRN' in some cultures.
    */
   @Path("/items[at0024]/value|value")
   private Boolean asRequiredValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Dose direction/Dose
    * pattern/Dose timing/As required/null_flavour
    */
   @Path("/items[at0024]/null_flavour|defining_code")
   private NullFlavour asRequiredNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/As required criterion
    * Description: The condition which triggers an 'as required' activity.
    * Comment: e.g. as required for pain.
    */
   @Path("/items[at0025]/value|value")
   private String asRequiredCriterionValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Dose direction/Dose
    * pattern/Dose timing/As required criterion/null_flavour
    */
   @Path("/items[at0025]/null_flavour|defining_code")
   private NullFlavour asRequiredCriterionNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Frequency
    * Description: The frequency as number of times per time period (limited to a
    * single day) that the activity is to take place.
    * Comment: e.g. "4 times per day" or ""3 to 4 times per hour"
    */
   @Path("/items[at0003]/value")
   @Choice
   private DoseTimingFrequencyChoice frequency;

   public void setFrequencyNullFlavourDefiningCode(NullFlavour frequencyNullFlavourDefiningCode) {
      this.frequencyNullFlavourDefiningCode = frequencyNullFlavourDefiningCode;
   }

   public NullFlavour getFrequencyNullFlavourDefiningCode() {
      return this.frequencyNullFlavourDefiningCode;
   }

   public void setIntervalValue(TemporalAmount intervalValue) {
      this.intervalValue = intervalValue;
   }

   public TemporalAmount getIntervalValue() {
      return this.intervalValue;
   }

   public void setIntervalNullFlavourDefiningCode(NullFlavour intervalNullFlavourDefiningCode) {
      this.intervalNullFlavourDefiningCode = intervalNullFlavourDefiningCode;
   }

   public NullFlavour getIntervalNullFlavourDefiningCode() {
      return this.intervalNullFlavourDefiningCode;
   }

   public void setSpecificTime(List<DoseTimingSpecificTimeElement> specificTime) {
      this.specificTime = specificTime;
   }

   public List<DoseTimingSpecificTimeElement> getSpecificTime() {
      return this.specificTime;
   }

   public void setNamedTimeEvent(List<DoseTimingNamedTimeEventElement> namedTimeEvent) {
      this.namedTimeEvent = namedTimeEvent;
   }

   public List<DoseTimingNamedTimeEventElement> getNamedTimeEvent() {
      return this.namedTimeEvent;
   }

   public void setExactTimingCriticalValue(Boolean exactTimingCriticalValue) {
      this.exactTimingCriticalValue = exactTimingCriticalValue;
   }

   public Boolean isExactTimingCriticalValue() {
      return this.exactTimingCriticalValue;
   }

   public void setExactTimingCriticalNullFlavourDefiningCode(
         NullFlavour exactTimingCriticalNullFlavourDefiningCode) {
      this.exactTimingCriticalNullFlavourDefiningCode = exactTimingCriticalNullFlavourDefiningCode;
   }

   public NullFlavour getExactTimingCriticalNullFlavourDefiningCode() {
      return this.exactTimingCriticalNullFlavourDefiningCode;
   }

   public void setAsRequiredValue(Boolean asRequiredValue) {
      this.asRequiredValue = asRequiredValue;
   }

   public Boolean isAsRequiredValue() {
      return this.asRequiredValue;
   }

   public void setAsRequiredNullFlavourDefiningCode(NullFlavour asRequiredNullFlavourDefiningCode) {
      this.asRequiredNullFlavourDefiningCode = asRequiredNullFlavourDefiningCode;
   }

   public NullFlavour getAsRequiredNullFlavourDefiningCode() {
      return this.asRequiredNullFlavourDefiningCode;
   }

   public void setAsRequiredCriterionValue(String asRequiredCriterionValue) {
      this.asRequiredCriterionValue = asRequiredCriterionValue;
   }

   public String getAsRequiredCriterionValue() {
      return this.asRequiredCriterionValue;
   }

   public void setAsRequiredCriterionNullFlavourDefiningCode(
         NullFlavour asRequiredCriterionNullFlavourDefiningCode) {
      this.asRequiredCriterionNullFlavourDefiningCode = asRequiredCriterionNullFlavourDefiningCode;
   }

   public NullFlavour getAsRequiredCriterionNullFlavourDefiningCode() {
      return this.asRequiredCriterionNullFlavourDefiningCode;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }

   public void setFrequency(DoseTimingFrequencyChoice frequency) {
      this.frequency = frequency;
   }

   public DoseTimingFrequencyChoice getFrequency() {
      return this.frequency;
   }
}
