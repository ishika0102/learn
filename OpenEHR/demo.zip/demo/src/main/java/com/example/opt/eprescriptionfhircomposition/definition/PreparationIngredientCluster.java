package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import java.lang.Double;
import java.lang.String;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Choice;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.814971295+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class PreparationIngredientCluster implements LocatableEntity {
   /**
    * Path: Prescription/Medication order/Order/Preparation/Ingredient/Ingredient
    * substance
    * Description: The strength and form of the medication substance, including
    * details of specific ingredients where required by an ad-hoc preparation or
    * infusion.
    * Comment: This is commonly carried as part of the medicine name and provided
    * by the medicines terminology but in some cases must be specified separately.
    */
   @Path("/items[openEHR-EHR-CLUSTER.medication_substance.v0 and name/value='Ingredient substance']")
   private IngredientSubstanceCluster ingredientSubstance;

   /**
    * Path: Prescription/Medication order/Order/Preparation/Ingredient/Ingredient
    * amount
    * Description: The value of the amount of the ingredient as a real number.
    * Comment: e.g. 1, 1.5, 0.125
    */
   @Path("/items[at0139]/value|magnitude")
   private Double ingredientAmountMagnitude;

   /**
    * Path: Prescription/Medication order/Order/Preparation/Ingredient/Ingredient
    * amount
    * Description: The value of the amount of the ingredient as a real number.
    * Comment: e.g. 1, 1.5, 0.125
    */
   @Path("/items[at0139]/value|units")
   private String ingredientAmountUnits;

   /**
    * Path: Prescription/Medication
    * order/Order/Tree/Preparation/Ingredient/Ingredient amount/null_flavour
    */
   @Path("/items[at0139]/null_flavour|defining_code")
   private NullFlavour ingredientAmountNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Preparation/Ingredient/Ingredient
    * amount unit
    * Description: The dose unit of the ingredient amount.
    * Comment: e.g 'tablet','mg'. Often coded using a reference terminology such as
    * SNOMED CT.
    */
   @Path("/items[at0140]/value|value")
   private String ingredientAmountUnitValue;

   /**
    * Path: Prescription/Medication
    * order/Order/Tree/Preparation/Ingredient/Ingredient amount unit/null_flavour
    */
   @Path("/items[at0140]/null_flavour|defining_code")
   private NullFlavour ingredientAmountUnitNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication
    * order/Order/Tree/Preparation/Ingredient/Role/null_flavour
    */
   @Path("/items[at0127]/null_flavour|defining_code")
   private NullFlavour roleNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Preparation/Ingredient/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   /**
    * Path: Prescription/Medication order/Order/Preparation/Ingredient/Role
    * Description: The role of the ingredient within the mixture or infusion.
    */
   @Path("/items[at0127]/value")
   @Choice
   private PreparationRoleChoice role;

   public void setIngredientSubstance(IngredientSubstanceCluster ingredientSubstance) {
      this.ingredientSubstance = ingredientSubstance;
   }

   public IngredientSubstanceCluster getIngredientSubstance() {
      return this.ingredientSubstance;
   }

   public void setIngredientAmountMagnitude(Double ingredientAmountMagnitude) {
      this.ingredientAmountMagnitude = ingredientAmountMagnitude;
   }

   public Double getIngredientAmountMagnitude() {
      return this.ingredientAmountMagnitude;
   }

   public void setIngredientAmountUnits(String ingredientAmountUnits) {
      this.ingredientAmountUnits = ingredientAmountUnits;
   }

   public String getIngredientAmountUnits() {
      return this.ingredientAmountUnits;
   }

   public void setIngredientAmountNullFlavourDefiningCode(
         NullFlavour ingredientAmountNullFlavourDefiningCode) {
      this.ingredientAmountNullFlavourDefiningCode = ingredientAmountNullFlavourDefiningCode;
   }

   public NullFlavour getIngredientAmountNullFlavourDefiningCode() {
      return this.ingredientAmountNullFlavourDefiningCode;
   }

   public void setIngredientAmountUnitValue(String ingredientAmountUnitValue) {
      this.ingredientAmountUnitValue = ingredientAmountUnitValue;
   }

   public String getIngredientAmountUnitValue() {
      return this.ingredientAmountUnitValue;
   }

   public void setIngredientAmountUnitNullFlavourDefiningCode(
         NullFlavour ingredientAmountUnitNullFlavourDefiningCode) {
      this.ingredientAmountUnitNullFlavourDefiningCode = ingredientAmountUnitNullFlavourDefiningCode;
   }

   public NullFlavour getIngredientAmountUnitNullFlavourDefiningCode() {
      return this.ingredientAmountUnitNullFlavourDefiningCode;
   }

   public void setRoleNullFlavourDefiningCode(NullFlavour roleNullFlavourDefiningCode) {
      this.roleNullFlavourDefiningCode = roleNullFlavourDefiningCode;
   }

   public NullFlavour getRoleNullFlavourDefiningCode() {
      return this.roleNullFlavourDefiningCode;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }

   public void setRole(PreparationRoleChoice role) {
      this.role = role;
   }

   public PreparationRoleChoice getRole() {
      return this.role;
   }
}
