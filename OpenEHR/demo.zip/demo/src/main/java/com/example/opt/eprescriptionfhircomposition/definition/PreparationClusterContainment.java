package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import com.nedap.archie.rm.datastructures.Cluster;
import java.lang.Double;
import java.lang.String;
import org.ehrbase.openehr.sdk.generator.commons.aql.containment.Containment;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.AqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.ListAqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.ListSelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.SelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

public class PreparationClusterContainment extends Containment {
    public SelectAqlField<PreparationCluster> PREPARATION_CLUSTER = new AqlFieldImp<PreparationCluster>(
            PreparationCluster.class, "", "PreparationCluster", PreparationCluster.class, this);

    public SelectAqlField<String> SUBSTANCE_NAME_VALUE = new AqlFieldImp<String>(PreparationCluster.class,
            "/items[at0132]/value|value", "substanceNameValue", String.class, this);

    public SelectAqlField<NullFlavour> SUBSTANCE_NAME_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
            PreparationCluster.class, "/items[at0132]/null_flavour|defining_code",
            "substanceNameNullFlavourDefiningCode",
            NullFlavour.class, this);

    public ListSelectAqlField<PreparationFormElement> FORM = new ListAqlFieldImp<PreparationFormElement>(
            PreparationCluster.class, "/items[at0071]", "form", PreparationFormElement.class, this);

    public SelectAqlField<Double> STRENGTH_MAGNITUDE = new AqlFieldImp<Double>(PreparationCluster.class,
            "/items[at0115]/value|magnitude", "strengthMagnitude", Double.class, this);

    public SelectAqlField<String> STRENGTH_UNITS = new AqlFieldImp<String>(PreparationCluster.class,
            "/items[at0115]/value|units", "strengthUnits", String.class, this);

    public SelectAqlField<NullFlavour> STRENGTH_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
            PreparationCluster.class, "/items[at0115]/null_flavour|defining_code", "strengthNullFlavourDefiningCode",
            NullFlavour.class, this);

    public SelectAqlField<String> STRENGTH_UNIT_VALUE = new AqlFieldImp<String>(PreparationCluster.class,
            "/items[at0116]/value|value", "strengthUnitValue", String.class, this);

    public SelectAqlField<NullFlavour> STRENGTH_UNIT_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
            PreparationCluster.class, "/items[at0116]/null_flavour|defining_code",
            "strengthUnitNullFlavourDefiningCode",
            NullFlavour.class, this);

    public SelectAqlField<Double> DILUENT_AMOUNT_MAGNITUDE = new AqlFieldImp<Double>(PreparationCluster.class,
            "/items[at0117]/items[at0124]/value|magnitude", "diluentAmountMagnitude", Double.class, this);

    public SelectAqlField<String> DILUENT_AMOUNT_UNITS = new AqlFieldImp<String>(PreparationCluster.class,
            "/items[at0117]/items[at0124]/value|units", "diluentAmountUnits", String.class, this);

    public SelectAqlField<NullFlavour> DILUENT_AMOUNT_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
            PreparationCluster.class, "/items[at0117]/items[at0124]/null_flavour|defining_code",
            "diluentAmountNullFlavourDefiningCode", NullFlavour.class, this);

    public SelectAqlField<String> DILUENT_UNIT_VALUE = new AqlFieldImp<String>(PreparationCluster.class,
            "/items[at0117]/items[at0125]/value|value", "diluentUnitValue", String.class, this);

    public SelectAqlField<NullFlavour> DILUENT_UNIT_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
            PreparationCluster.class, "/items[at0117]/items[at0125]/null_flavour|defining_code",
            "diluentUnitNullFlavourDefiningCode", NullFlavour.class, this);

    public ListSelectAqlField<PreparationIngredientCluster> INGREDIENT = new ListAqlFieldImp<PreparationIngredientCluster>(
            PreparationCluster.class, "/items[at0126]", "ingredient", PreparationIngredientCluster.class, this);

    public SelectAqlField<String> DESCRIPTION_VALUE = new AqlFieldImp<String>(PreparationCluster.class,
            "/items[at0133]/value|value", "descriptionValue", String.class, this);

    public SelectAqlField<NullFlavour> DESCRIPTION_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
            PreparationCluster.class, "/items[at0133]/null_flavour|defining_code", "descriptionNullFlavourDefiningCode",
            NullFlavour.class, this);

    public ListSelectAqlField<Cluster> SUBSTANCE_DETAILS = new ListAqlFieldImp<Cluster>(PreparationCluster.class,
            "/items[at0141]", "substanceDetails", Cluster.class, this);

    public SelectAqlField<FeederAudit> FEEDER_AUDIT = new AqlFieldImp<FeederAudit>(PreparationCluster.class,
            "/feeder_audit", "feederAudit", FeederAudit.class, this);

    private PreparationClusterContainment() {
        super("openEHR-EHR-CLUSTER.medication_substance.v0");
    }

    public static PreparationClusterContainment getInstance() {
        return new PreparationClusterContainment();
    }
}
