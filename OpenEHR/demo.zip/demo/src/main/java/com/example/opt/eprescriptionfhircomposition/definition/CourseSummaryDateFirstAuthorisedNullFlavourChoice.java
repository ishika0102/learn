package com.example.opt.eprescriptionfhircomposition.definition;

import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.873226323+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public interface CourseSummaryDateFirstAuthorisedNullFlavourChoice {
    NullFlavour getDateFirstAuthorisedNullFlavourDefiningCode();

    void setDateFirstAuthorisedNullFlavourDefiningCode(
            NullFlavour dateFirstAuthorisedNullFlavourDefiningCode);
}
