package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import java.util.List;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Choice;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.835647982+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class MedicationOrderDoseDirectionCluster implements LocatableEntity {
   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern
    * Description: The combination of a medication amount associated with a single
    * medication timing.
    * Comment: For example: '2 tablets at 6pm' or '20mg three times per day'.
    * Please note: this cluster allows multiple occurrences to enable
    * representation of a complete set of dose patterns for a single dose
    * direction.
    */
   @Path("/items[at0058]")
   private List<MedicationOrderDosePatternCluster> dosePattern;

   /**
    * Path: Prescription/Medication order/Order/Tree/Dose direction/Direction
    * duration/null_flavour
    */
   @Path("/items[at0066]/null_flavour|defining_code")
   private NullFlavour directionDurationNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Direction repetition
    * Description: Details of timing schedules repeating over periods longer than a
    * single day.
    */
   @Path("/items[openEHR-EHR-CLUSTER.timing_repetition.v0 and name/value='Direction repetition']")
   private DirectionRepetitionCluster directionRepetition;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Direction duration
    * Description: The duration of this dose direction.
    * Comment: For example: 'for 7 days','Indefinite'.
    */
   @Path("/items[at0066]/value")
   @Choice
   private MedicationOrderDirectionDurationChoice directionDuration;

   public void setDosePattern(List<MedicationOrderDosePatternCluster> dosePattern) {
      this.dosePattern = dosePattern;
   }

   public List<MedicationOrderDosePatternCluster> getDosePattern() {
      return this.dosePattern;
   }

   public void setDirectionDurationNullFlavourDefiningCode(
         NullFlavour directionDurationNullFlavourDefiningCode) {
      this.directionDurationNullFlavourDefiningCode = directionDurationNullFlavourDefiningCode;
   }

   public NullFlavour getDirectionDurationNullFlavourDefiningCode() {
      return this.directionDurationNullFlavourDefiningCode;
   }

   public void setDirectionRepetition(DirectionRepetitionCluster directionRepetition) {
      this.directionRepetition = directionRepetition;
   }

   public DirectionRepetitionCluster getDirectionRepetition() {
      return this.directionRepetition;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }

   public void setDirectionDuration(MedicationOrderDirectionDurationChoice directionDuration) {
      this.directionDuration = directionDuration;
   }

   public MedicationOrderDirectionDurationChoice getDirectionDuration() {
      return this.directionDuration;
   }
}
