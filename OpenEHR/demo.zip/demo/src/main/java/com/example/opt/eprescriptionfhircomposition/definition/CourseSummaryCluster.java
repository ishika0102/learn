package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Archetype;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Choice;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Archetype("openEHR-EHR-CLUSTER.medication_course_summary.v0")
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.859359383+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class CourseSummaryCluster implements LocatableEntity {
   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Status
    * Description: The overall status of this order.
    */
   @Path("/items[at0001 and name/value='Status']/value|defining_code")
   private StatusDefiningCode statusDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Status/null_flavour
    */
   @Path("/items[at0001 and name/value='Status']/null_flavour|defining_code")
   private NullFlavour statusNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course
    * summary/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Date prescription issued/null_flavour
    */
   @Path("/items[at0002 and name/value='Date prescription issued']/null_flavour")
   @Choice
   private CourseSummaryDatePrescriptionIssuedNullFlavourChoice datePrescriptionIssuedNullFlavour;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Date discontinued/null_flavour
    */
   @Path("/items[at0002 and name/value='Date discontinued']/null_flavour")
   @Choice
   private CourseSummaryDateDiscontinuedNullFlavourChoice dateDiscontinuedNullFlavour;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Date first dispensed/null_flavour
    */
   @Path("/items[at0002 and name/value='Date first dispensed']/null_flavour")
   @Choice
   private CourseSummaryDateFirstDispensedNullFlavourChoice dateFirstDispensedNullFlavour;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Date administration withheld/null_flavour
    */
   @Path("/items[at0002 and name/value='Date administration withheld']/null_flavour")
   @Choice
   private CourseSummaryDateAdministrationWithheldNullFlavourChoice dateAdministrationWithheldNullFlavour;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * administered
    * Description: Key medication event dates.
    */
   @Path("/items[at0002 and name/value='Date administered']/value")
   @Choice
   private CourseSummaryDateAdministeredChoice dateAdministered;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * last authorised
    * Description: Key medication event dates.
    */
   @Path("/items[at0002 and name/value='Date last authorised']/value")
   @Choice
   private CourseSummaryDateLastAuthorisedChoice dateLastAuthorised;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Date first prescription issued/null_flavour
    */
   @Path("/items[at0002 and name/value='Date first prescription issued']/null_flavour")
   @Choice
   private CourseSummaryDateFirstPrescriptionIssuedNullFlavourChoice dateFirstPrescriptionIssuedNullFlavour;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * last administered
    * Description: Key medication event dates.
    */
   @Path("/items[at0002 and name/value='Date last administered']/value")
   @Choice
   private CourseSummaryDateLastAdministeredChoice dateLastAdministered;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Date last reviewed/null_flavour
    */
   @Path("/items[at0002 and name/value='Date last reviewed']/null_flavour")
   @Choice
   private CourseSummaryDateLastReviewedNullFlavourChoice dateLastReviewedNullFlavour;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * authorised
    * Description: Key medication event dates.
    */
   @Path("/items[at0002 and name/value='Date authorised']/value")
   @Choice
   private CourseSummaryDateAuthorisedChoice dateAuthorised;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * changed
    * Description: Key medication event dates.
    */
   @Path("/items[at0002 and name/value='Date changed']/value")
   @Choice
   private CourseSummaryDateChangedChoice dateChanged;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Date first authorised/null_flavour
    */
   @Path("/items[at0002 and name/value='Date first authorised']/null_flavour")
   @Choice
   private CourseSummaryDateFirstAuthorisedNullFlavourChoice dateFirstAuthorisedNullFlavour;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * first prescription issued
    * Description: Key medication event dates.
    */
   @Path("/items[at0002 and name/value='Date first prescription issued']/value")
   @Choice
   private CourseSummaryDateFirstPrescriptionIssuedChoice dateFirstPrescriptionIssued;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * ordered/recommended
    * Description: Key medication event dates.
    */
   @Path("/items[at0002 and name/value='Date ordered/recommended']/value")
   @Choice
   private CourseSummaryDateOrderedRecommendedChoice dateOrderedRecommended;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * last reviewed
    * Description: Key medication event dates.
    */
   @Path("/items[at0002 and name/value='Date last reviewed']/value")
   @Choice
   private CourseSummaryDateLastReviewedChoice dateLastReviewed;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Date first administered/null_flavour
    */
   @Path("/items[at0002 and name/value='Date first administered']/null_flavour")
   @Choice
   private CourseSummaryDateFirstAdministeredNullFlavourChoice dateFirstAdministeredNullFlavour;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Date dispensed/null_flavour
    */
   @Path("/items[at0002 and name/value='Date dispensed']/null_flavour")
   @Choice
   private CourseSummaryDateDispensedNullFlavourChoice dateDispensedNullFlavour;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * first authorised
    * Description: Key medication event dates.
    */
   @Path("/items[at0002 and name/value='Date first authorised']/value")
   @Choice
   private CourseSummaryDateFirstAuthorisedChoice dateFirstAuthorised;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * last prescription issued
    * Description: Key medication event dates.
    */
   @Path("/items[at0002 and name/value='Date last prescription issued']/value")
   @Choice
   private CourseSummaryDateLastPrescriptionIssuedChoice dateLastPrescriptionIssued;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Date last administered/null_flavour
    */
   @Path("/items[at0002 and name/value='Date last administered']/null_flavour")
   @Choice
   private CourseSummaryDateLastAdministeredNullFlavourChoice dateLastAdministeredNullFlavour;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Date last authorised/null_flavour
    */
   @Path("/items[at0002 and name/value='Date last authorised']/null_flavour")
   @Choice
   private CourseSummaryDateLastAuthorisedNullFlavourChoice dateLastAuthorisedNullFlavour;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * last dispensed
    * Description: Key medication event dates.
    */
   @Path("/items[at0002 and name/value='Date last dispensed']/value")
   @Choice
   private CourseSummaryDateLastDispensedChoice dateLastDispensed;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * dispensed
    * Description: Key medication event dates.
    */
   @Path("/items[at0002 and name/value='Date dispensed']/value")
   @Choice
   private CourseSummaryDateDispensedChoice dateDispensed;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Date last dispensed/null_flavour
    */
   @Path("/items[at0002 and name/value='Date last dispensed']/null_flavour")
   @Choice
   private CourseSummaryDateLastDispensedNullFlavourChoice dateLastDispensedNullFlavour;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Date ordered/recommended/null_flavour
    */
   @Path("/items[at0002 and name/value='Date ordered/recommended']/null_flavour")
   @Choice
   private CourseSummaryDateOrderedRecommendedNullFlavourChoice dateOrderedRecommendedNullFlavour;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * administration withheld
    * Description: Key medication event dates.
    */
   @Path("/items[at0002 and name/value='Date administration withheld']/value")
   @Choice
   private CourseSummaryDateAdministrationWithheldChoice dateAdministrationWithheld;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * first dispensed
    * Description: Key medication event dates.
    */
   @Path("/items[at0002 and name/value='Date first dispensed']/value")
   @Choice
   private CourseSummaryDateFirstDispensedChoice dateFirstDispensed;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * reviewed
    * Description: Key medication event dates.
    */
   @Path("/items[at0002 and name/value='Date reviewed']/value")
   @Choice
   private CourseSummaryDateReviewedChoice dateReviewed;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Date changed/null_flavour
    */
   @Path("/items[at0002 and name/value='Date changed']/null_flavour")
   @Choice
   private CourseSummaryDateChangedNullFlavourChoice dateChangedNullFlavour;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * prescription issued
    * Description: Key medication event dates.
    */
   @Path("/items[at0002 and name/value='Date prescription issued']/value")
   @Choice
   private CourseSummaryDatePrescriptionIssuedChoice datePrescriptionIssued;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Date administered/null_flavour
    */
   @Path("/items[at0002 and name/value='Date administered']/null_flavour")
   @Choice
   private CourseSummaryDateAdministeredNullFlavourChoice dateAdministeredNullFlavour;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Date last prescription issued/null_flavour
    */
   @Path("/items[at0002 and name/value='Date last prescription issued']/null_flavour")
   @Choice
   private CourseSummaryDateLastPrescriptionIssuedNullFlavourChoice dateLastPrescriptionIssuedNullFlavour;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Date reviewed/null_flavour
    */
   @Path("/items[at0002 and name/value='Date reviewed']/null_flavour")
   @Choice
   private CourseSummaryDateReviewedNullFlavourChoice dateReviewedNullFlavour;

   /**
    * Path: Prescription/Medication order/Order/Tree/Order details/Course
    * summary/Date authorised/null_flavour
    */
   @Path("/items[at0002 and name/value='Date authorised']/null_flavour")
   @Choice
   private CourseSummaryDateAuthorisedNullFlavourChoice dateAuthorisedNullFlavour;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * first administered
    * Description: Key medication event dates.
    */
   @Path("/items[at0002 and name/value='Date first administered']/value")
   @Choice
   private CourseSummaryDateFirstAdministeredChoice dateFirstAdministered;

   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * discontinued
    * Description: Key medication event dates.
    */
   @Path("/items[at0002 and name/value='Date discontinued']/value")
   @Choice
   private CourseSummaryDateDiscontinuedChoice dateDiscontinued;

   public void setStatusDefiningCode(StatusDefiningCode statusDefiningCode) {
      this.statusDefiningCode = statusDefiningCode;
   }

   public StatusDefiningCode getStatusDefiningCode() {
      return this.statusDefiningCode;
   }

   public void setStatusNullFlavourDefiningCode(NullFlavour statusNullFlavourDefiningCode) {
      this.statusNullFlavourDefiningCode = statusNullFlavourDefiningCode;
   }

   public NullFlavour getStatusNullFlavourDefiningCode() {
      return this.statusNullFlavourDefiningCode;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }

   public void setDatePrescriptionIssuedNullFlavour(
         CourseSummaryDatePrescriptionIssuedNullFlavourChoice datePrescriptionIssuedNullFlavour) {
      this.datePrescriptionIssuedNullFlavour = datePrescriptionIssuedNullFlavour;
   }

   public CourseSummaryDatePrescriptionIssuedNullFlavourChoice getDatePrescriptionIssuedNullFlavour() {
      return this.datePrescriptionIssuedNullFlavour;
   }

   public void setDateDiscontinuedNullFlavour(
         CourseSummaryDateDiscontinuedNullFlavourChoice dateDiscontinuedNullFlavour) {
      this.dateDiscontinuedNullFlavour = dateDiscontinuedNullFlavour;
   }

   public CourseSummaryDateDiscontinuedNullFlavourChoice getDateDiscontinuedNullFlavour() {
      return this.dateDiscontinuedNullFlavour;
   }

   public void setDateFirstDispensedNullFlavour(
         CourseSummaryDateFirstDispensedNullFlavourChoice dateFirstDispensedNullFlavour) {
      this.dateFirstDispensedNullFlavour = dateFirstDispensedNullFlavour;
   }

   public CourseSummaryDateFirstDispensedNullFlavourChoice getDateFirstDispensedNullFlavour() {
      return this.dateFirstDispensedNullFlavour;
   }

   public void setDateAdministrationWithheldNullFlavour(
         CourseSummaryDateAdministrationWithheldNullFlavourChoice dateAdministrationWithheldNullFlavour) {
      this.dateAdministrationWithheldNullFlavour = dateAdministrationWithheldNullFlavour;
   }

   public CourseSummaryDateAdministrationWithheldNullFlavourChoice getDateAdministrationWithheldNullFlavour() {
      return this.dateAdministrationWithheldNullFlavour;
   }

   public void setDateAdministered(CourseSummaryDateAdministeredChoice dateAdministered) {
      this.dateAdministered = dateAdministered;
   }

   public CourseSummaryDateAdministeredChoice getDateAdministered() {
      return this.dateAdministered;
   }

   public void setDateLastAuthorised(CourseSummaryDateLastAuthorisedChoice dateLastAuthorised) {
      this.dateLastAuthorised = dateLastAuthorised;
   }

   public CourseSummaryDateLastAuthorisedChoice getDateLastAuthorised() {
      return this.dateLastAuthorised;
   }

   public void setDateFirstPrescriptionIssuedNullFlavour(
         CourseSummaryDateFirstPrescriptionIssuedNullFlavourChoice dateFirstPrescriptionIssuedNullFlavour) {
      this.dateFirstPrescriptionIssuedNullFlavour = dateFirstPrescriptionIssuedNullFlavour;
   }

   public CourseSummaryDateFirstPrescriptionIssuedNullFlavourChoice getDateFirstPrescriptionIssuedNullFlavour() {
      return this.dateFirstPrescriptionIssuedNullFlavour;
   }

   public void setDateLastAdministered(
         CourseSummaryDateLastAdministeredChoice dateLastAdministered) {
      this.dateLastAdministered = dateLastAdministered;
   }

   public CourseSummaryDateLastAdministeredChoice getDateLastAdministered() {
      return this.dateLastAdministered;
   }

   public void setDateLastReviewedNullFlavour(
         CourseSummaryDateLastReviewedNullFlavourChoice dateLastReviewedNullFlavour) {
      this.dateLastReviewedNullFlavour = dateLastReviewedNullFlavour;
   }

   public CourseSummaryDateLastReviewedNullFlavourChoice getDateLastReviewedNullFlavour() {
      return this.dateLastReviewedNullFlavour;
   }

   public void setDateAuthorised(CourseSummaryDateAuthorisedChoice dateAuthorised) {
      this.dateAuthorised = dateAuthorised;
   }

   public CourseSummaryDateAuthorisedChoice getDateAuthorised() {
      return this.dateAuthorised;
   }

   public void setDateChanged(CourseSummaryDateChangedChoice dateChanged) {
      this.dateChanged = dateChanged;
   }

   public CourseSummaryDateChangedChoice getDateChanged() {
      return this.dateChanged;
   }

   public void setDateFirstAuthorisedNullFlavour(
         CourseSummaryDateFirstAuthorisedNullFlavourChoice dateFirstAuthorisedNullFlavour) {
      this.dateFirstAuthorisedNullFlavour = dateFirstAuthorisedNullFlavour;
   }

   public CourseSummaryDateFirstAuthorisedNullFlavourChoice getDateFirstAuthorisedNullFlavour() {
      return this.dateFirstAuthorisedNullFlavour;
   }

   public void setDateFirstPrescriptionIssued(
         CourseSummaryDateFirstPrescriptionIssuedChoice dateFirstPrescriptionIssued) {
      this.dateFirstPrescriptionIssued = dateFirstPrescriptionIssued;
   }

   public CourseSummaryDateFirstPrescriptionIssuedChoice getDateFirstPrescriptionIssued() {
      return this.dateFirstPrescriptionIssued;
   }

   public void setDateOrderedRecommended(
         CourseSummaryDateOrderedRecommendedChoice dateOrderedRecommended) {
      this.dateOrderedRecommended = dateOrderedRecommended;
   }

   public CourseSummaryDateOrderedRecommendedChoice getDateOrderedRecommended() {
      return this.dateOrderedRecommended;
   }

   public void setDateLastReviewed(CourseSummaryDateLastReviewedChoice dateLastReviewed) {
      this.dateLastReviewed = dateLastReviewed;
   }

   public CourseSummaryDateLastReviewedChoice getDateLastReviewed() {
      return this.dateLastReviewed;
   }

   public void setDateFirstAdministeredNullFlavour(
         CourseSummaryDateFirstAdministeredNullFlavourChoice dateFirstAdministeredNullFlavour) {
      this.dateFirstAdministeredNullFlavour = dateFirstAdministeredNullFlavour;
   }

   public CourseSummaryDateFirstAdministeredNullFlavourChoice getDateFirstAdministeredNullFlavour() {
      return this.dateFirstAdministeredNullFlavour;
   }

   public void setDateDispensedNullFlavour(
         CourseSummaryDateDispensedNullFlavourChoice dateDispensedNullFlavour) {
      this.dateDispensedNullFlavour = dateDispensedNullFlavour;
   }

   public CourseSummaryDateDispensedNullFlavourChoice getDateDispensedNullFlavour() {
      return this.dateDispensedNullFlavour;
   }

   public void setDateFirstAuthorised(CourseSummaryDateFirstAuthorisedChoice dateFirstAuthorised) {
      this.dateFirstAuthorised = dateFirstAuthorised;
   }

   public CourseSummaryDateFirstAuthorisedChoice getDateFirstAuthorised() {
      return this.dateFirstAuthorised;
   }

   public void setDateLastPrescriptionIssued(
         CourseSummaryDateLastPrescriptionIssuedChoice dateLastPrescriptionIssued) {
      this.dateLastPrescriptionIssued = dateLastPrescriptionIssued;
   }

   public CourseSummaryDateLastPrescriptionIssuedChoice getDateLastPrescriptionIssued() {
      return this.dateLastPrescriptionIssued;
   }

   public void setDateLastAdministeredNullFlavour(
         CourseSummaryDateLastAdministeredNullFlavourChoice dateLastAdministeredNullFlavour) {
      this.dateLastAdministeredNullFlavour = dateLastAdministeredNullFlavour;
   }

   public CourseSummaryDateLastAdministeredNullFlavourChoice getDateLastAdministeredNullFlavour() {
      return this.dateLastAdministeredNullFlavour;
   }

   public void setDateLastAuthorisedNullFlavour(
         CourseSummaryDateLastAuthorisedNullFlavourChoice dateLastAuthorisedNullFlavour) {
      this.dateLastAuthorisedNullFlavour = dateLastAuthorisedNullFlavour;
   }

   public CourseSummaryDateLastAuthorisedNullFlavourChoice getDateLastAuthorisedNullFlavour() {
      return this.dateLastAuthorisedNullFlavour;
   }

   public void setDateLastDispensed(CourseSummaryDateLastDispensedChoice dateLastDispensed) {
      this.dateLastDispensed = dateLastDispensed;
   }

   public CourseSummaryDateLastDispensedChoice getDateLastDispensed() {
      return this.dateLastDispensed;
   }

   public void setDateDispensed(CourseSummaryDateDispensedChoice dateDispensed) {
      this.dateDispensed = dateDispensed;
   }

   public CourseSummaryDateDispensedChoice getDateDispensed() {
      return this.dateDispensed;
   }

   public void setDateLastDispensedNullFlavour(
         CourseSummaryDateLastDispensedNullFlavourChoice dateLastDispensedNullFlavour) {
      this.dateLastDispensedNullFlavour = dateLastDispensedNullFlavour;
   }

   public CourseSummaryDateLastDispensedNullFlavourChoice getDateLastDispensedNullFlavour() {
      return this.dateLastDispensedNullFlavour;
   }

   public void setDateOrderedRecommendedNullFlavour(
         CourseSummaryDateOrderedRecommendedNullFlavourChoice dateOrderedRecommendedNullFlavour) {
      this.dateOrderedRecommendedNullFlavour = dateOrderedRecommendedNullFlavour;
   }

   public CourseSummaryDateOrderedRecommendedNullFlavourChoice getDateOrderedRecommendedNullFlavour() {
      return this.dateOrderedRecommendedNullFlavour;
   }

   public void setDateAdministrationWithheld(
         CourseSummaryDateAdministrationWithheldChoice dateAdministrationWithheld) {
      this.dateAdministrationWithheld = dateAdministrationWithheld;
   }

   public CourseSummaryDateAdministrationWithheldChoice getDateAdministrationWithheld() {
      return this.dateAdministrationWithheld;
   }

   public void setDateFirstDispensed(CourseSummaryDateFirstDispensedChoice dateFirstDispensed) {
      this.dateFirstDispensed = dateFirstDispensed;
   }

   public CourseSummaryDateFirstDispensedChoice getDateFirstDispensed() {
      return this.dateFirstDispensed;
   }

   public void setDateReviewed(CourseSummaryDateReviewedChoice dateReviewed) {
      this.dateReviewed = dateReviewed;
   }

   public CourseSummaryDateReviewedChoice getDateReviewed() {
      return this.dateReviewed;
   }

   public void setDateChangedNullFlavour(
         CourseSummaryDateChangedNullFlavourChoice dateChangedNullFlavour) {
      this.dateChangedNullFlavour = dateChangedNullFlavour;
   }

   public CourseSummaryDateChangedNullFlavourChoice getDateChangedNullFlavour() {
      return this.dateChangedNullFlavour;
   }

   public void setDatePrescriptionIssued(
         CourseSummaryDatePrescriptionIssuedChoice datePrescriptionIssued) {
      this.datePrescriptionIssued = datePrescriptionIssued;
   }

   public CourseSummaryDatePrescriptionIssuedChoice getDatePrescriptionIssued() {
      return this.datePrescriptionIssued;
   }

   public void setDateAdministeredNullFlavour(
         CourseSummaryDateAdministeredNullFlavourChoice dateAdministeredNullFlavour) {
      this.dateAdministeredNullFlavour = dateAdministeredNullFlavour;
   }

   public CourseSummaryDateAdministeredNullFlavourChoice getDateAdministeredNullFlavour() {
      return this.dateAdministeredNullFlavour;
   }

   public void setDateLastPrescriptionIssuedNullFlavour(
         CourseSummaryDateLastPrescriptionIssuedNullFlavourChoice dateLastPrescriptionIssuedNullFlavour) {
      this.dateLastPrescriptionIssuedNullFlavour = dateLastPrescriptionIssuedNullFlavour;
   }

   public CourseSummaryDateLastPrescriptionIssuedNullFlavourChoice getDateLastPrescriptionIssuedNullFlavour() {
      return this.dateLastPrescriptionIssuedNullFlavour;
   }

   public void setDateReviewedNullFlavour(
         CourseSummaryDateReviewedNullFlavourChoice dateReviewedNullFlavour) {
      this.dateReviewedNullFlavour = dateReviewedNullFlavour;
   }

   public CourseSummaryDateReviewedNullFlavourChoice getDateReviewedNullFlavour() {
      return this.dateReviewedNullFlavour;
   }

   public void setDateAuthorisedNullFlavour(
         CourseSummaryDateAuthorisedNullFlavourChoice dateAuthorisedNullFlavour) {
      this.dateAuthorisedNullFlavour = dateAuthorisedNullFlavour;
   }

   public CourseSummaryDateAuthorisedNullFlavourChoice getDateAuthorisedNullFlavour() {
      return this.dateAuthorisedNullFlavour;
   }

   public void setDateFirstAdministered(
         CourseSummaryDateFirstAdministeredChoice dateFirstAdministered) {
      this.dateFirstAdministered = dateFirstAdministered;
   }

   public CourseSummaryDateFirstAdministeredChoice getDateFirstAdministered() {
      return this.dateFirstAdministered;
   }

   public void setDateDiscontinued(CourseSummaryDateDiscontinuedChoice dateDiscontinued) {
      this.dateDiscontinued = dateDiscontinued;
   }

   public CourseSummaryDateDiscontinuedChoice getDateDiscontinued() {
      return this.dateDiscontinued;
   }
}
