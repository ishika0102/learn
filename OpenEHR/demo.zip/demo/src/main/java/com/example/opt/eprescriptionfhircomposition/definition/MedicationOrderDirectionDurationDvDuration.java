package com.example.opt.eprescriptionfhircomposition.definition;

import java.time.temporal.TemporalAmount;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.853986812+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_DURATION")
public class MedicationOrderDirectionDurationDvDuration implements RMEntity, MedicationOrderDirectionDurationChoice {
   /**
    * Path: Prescription/Medication order/Order/Dose direction/Direction
    * duration/Direction duration
    * Description: The duration of this dose direction.
    * Comment: For example: 'for 7 days','Indefinite'.
    */
   @Path("|value")
   private TemporalAmount directionDurationValue;

   public void setDirectionDurationValue(TemporalAmount directionDurationValue) {
      this.directionDurationValue = directionDurationValue;
   }

   public TemporalAmount getDirectionDurationValue() {
      return this.directionDurationValue;
   }
}
