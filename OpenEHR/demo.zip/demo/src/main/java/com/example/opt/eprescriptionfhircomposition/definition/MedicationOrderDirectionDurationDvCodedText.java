package com.example.opt.eprescriptionfhircomposition.definition;

import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.853537650+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_CODED_TEXT")
public class MedicationOrderDirectionDurationDvCodedText implements RMEntity, MedicationOrderDirectionDurationChoice {
  /**
   * Path: Prescription/Medication order/Order/Dose direction/Direction
   * duration/Direction duration
   * Description: The duration of this dose direction.
   * Comment: For example: 'for 7 days','Indefinite'.
   */
  @Path("|defining_code")
  private DirectionDurationDefiningCode directionDurationDefiningCode;

  public void setDirectionDurationDefiningCode(
      DirectionDurationDefiningCode directionDurationDefiningCode) {
    this.directionDurationDefiningCode = directionDurationDefiningCode;
  }

  public DirectionDurationDefiningCode getDirectionDurationDefiningCode() {
    return this.directionDurationDefiningCode;
  }
}
