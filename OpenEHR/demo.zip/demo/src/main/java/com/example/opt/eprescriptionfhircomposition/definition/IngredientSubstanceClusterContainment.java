package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import com.nedap.archie.rm.datastructures.Cluster;
import java.lang.Double;
import java.lang.String;
import org.ehrbase.openehr.sdk.generator.commons.aql.containment.Containment;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.AqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.ListAqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.ListSelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.SelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

public class IngredientSubstanceClusterContainment extends Containment {
    public SelectAqlField<IngredientSubstanceCluster> INGREDIENT_SUBSTANCE_CLUSTER = new AqlFieldImp<IngredientSubstanceCluster>(
            IngredientSubstanceCluster.class, "", "IngredientSubstanceCluster", IngredientSubstanceCluster.class, this);

    public SelectAqlField<String> SUBSTANCE_NAME_VALUE = new AqlFieldImp<String>(IngredientSubstanceCluster.class,
            "/items[at0132]/value|value", "substanceNameValue", String.class, this);

    public SelectAqlField<NullFlavour> SUBSTANCE_NAME_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
            IngredientSubstanceCluster.class, "/items[at0132]/null_flavour|defining_code",
            "substanceNameNullFlavourDefiningCode", NullFlavour.class, this);

    public ListSelectAqlField<PreparationFormElement> FORM = new ListAqlFieldImp<PreparationFormElement>(
            IngredientSubstanceCluster.class, "/items[at0071]", "form", PreparationFormElement.class, this);

    public SelectAqlField<CategoryDefiningCode> CATEGORY_DEFINING_CODE = new AqlFieldImp<CategoryDefiningCode>(
            IngredientSubstanceCluster.class, "/items[at0142]/value|defining_code", "categoryDefiningCode",
            CategoryDefiningCode.class, this);

    public SelectAqlField<NullFlavour> CATEGORY_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
            IngredientSubstanceCluster.class, "/items[at0142]/null_flavour|defining_code",
            "categoryNullFlavourDefiningCode",
            NullFlavour.class, this);

    public SelectAqlField<Double> STRENGTH_MAGNITUDE = new AqlFieldImp<Double>(IngredientSubstanceCluster.class,
            "/items[at0115]/value|magnitude", "strengthMagnitude", Double.class, this);

    public SelectAqlField<String> STRENGTH_UNITS = new AqlFieldImp<String>(IngredientSubstanceCluster.class,
            "/items[at0115]/value|units", "strengthUnits", String.class, this);

    public SelectAqlField<NullFlavour> STRENGTH_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
            IngredientSubstanceCluster.class, "/items[at0115]/null_flavour|defining_code",
            "strengthNullFlavourDefiningCode",
            NullFlavour.class, this);

    public SelectAqlField<String> STRENGTH_UNIT_VALUE = new AqlFieldImp<String>(IngredientSubstanceCluster.class,
            "/items[at0116]/value|value", "strengthUnitValue", String.class, this);

    public SelectAqlField<NullFlavour> STRENGTH_UNIT_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
            IngredientSubstanceCluster.class, "/items[at0116]/null_flavour|defining_code",
            "strengthUnitNullFlavourDefiningCode", NullFlavour.class, this);

    public SelectAqlField<String> DESCRIPTION_VALUE = new AqlFieldImp<String>(IngredientSubstanceCluster.class,
            "/items[at0133]/value|value", "descriptionValue", String.class, this);

    public SelectAqlField<NullFlavour> DESCRIPTION_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
            IngredientSubstanceCluster.class, "/items[at0133]/null_flavour|defining_code",
            "descriptionNullFlavourDefiningCode", NullFlavour.class, this);

    public ListSelectAqlField<Cluster> SUBSTANCE_DETAILS = new ListAqlFieldImp<Cluster>(
            IngredientSubstanceCluster.class, "/items[at0141]", "substanceDetails", Cluster.class, this);

    public SelectAqlField<FeederAudit> FEEDER_AUDIT = new AqlFieldImp<FeederAudit>(IngredientSubstanceCluster.class,
            "/feeder_audit", "feederAudit", FeederAudit.class, this);

    private IngredientSubstanceClusterContainment() {
        super("openEHR-EHR-CLUSTER.medication_substance.v0");
    }

    public static IngredientSubstanceClusterContainment getInstance() {
        return new IngredientSubstanceClusterContainment();
    }
}
