package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import com.nedap.archie.rm.datavalues.DvIdentifier;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.800695231+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class PrescriptionPrescriptionIdentifierElement implements LocatableEntity {
   /**
    * Path: Prescription/context/Prescription identifier
    * Description: An identifier for the prescription as a whole.
    */
   @Path("/value")
   private DvIdentifier value;

   /**
    * Path: Prescription/context/Tree/Prescription identifier/null_flavour
    */
   @Path("/null_flavour|defining_code")
   private NullFlavour value2;

   /**
    * Path: Prescription/context/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   public void setValue(DvIdentifier value) {
      this.value = value;
   }

   public DvIdentifier getValue() {
      return this.value;
   }

   public void setValue2(NullFlavour value2) {
      this.value2 = value2;
   }

   public NullFlavour getValue2() {
      return this.value2;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }
}
