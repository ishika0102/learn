package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import java.lang.Double;
import java.lang.String;
import java.time.temporal.TemporalAmount;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Archetype;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Archetype("openEHR-EHR-CLUSTER.medication_supply_amount.v0")
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.901424475+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class DispenseAmountCluster implements LocatableEntity {
   /**
    * Path: Prescription/Medication order/Order/Dispense directions/Dispense
    * amount/Amount description
    * Description: A narrative representation of the amount The amount of
    * medication, vaccine or therapeutic good intended to be supplied or actually
    * supplied.
    */
   @Path("/items[at0161]/value|value")
   private String amountDescriptionValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Dispense directions/Dispense
    * amount/Amount description/null_flavour
    */
   @Path("/items[at0161]/null_flavour|defining_code")
   private NullFlavour amountDescriptionNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Dispense directions/Dispense
    * amount/Amount
    * Description: The amount of medication, vaccine or therapeutic good intended
    * to be supplied or actually supplied.
    * Comment: For example: 1, 1.5, or 0.125.
    */
   @Path("/items[at0131]/value|magnitude")
   private Double amountMagnitude;

   /**
    * Path: Prescription/Medication order/Order/Dispense directions/Dispense
    * amount/Amount
    * Description: The amount of medication, vaccine or therapeutic good intended
    * to be supplied or actually supplied.
    * Comment: For example: 1, 1.5, or 0.125.
    */
   @Path("/items[at0131]/value|units")
   private String amountUnits;

   /**
    * Path: Prescription/Medication order/Order/Tree/Dispense directions/Dispense
    * amount/Amount/null_flavour
    */
   @Path("/items[at0131]/null_flavour|defining_code")
   private NullFlavour amountNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Dispense directions/Dispense
    * amount/Units
    * Description: The dose unit or pack unit associated with the dispense amount.
    * Comment: For example: 'tablets', 'packs', ml'.
    */
   @Path("/items[at0147]/value|value")
   private String unitsValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Dispense directions/Dispense
    * amount/Units/null_flavour
    */
   @Path("/items[at0147]/null_flavour|defining_code")
   private NullFlavour unitsNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Dispense directions/Dispense
    * amount/Duration of supply
    * Description: The period of time for which the medication should be dispensed
    * or for which a suppy was dispensed.
    * Comment: The dispenser is asked to supply sufficient quantity of medication
    * to cover the defined period.
    */
   @Path("/items[at0142]/value|value")
   private TemporalAmount durationOfSupplyValue;

   /**
    * Path: Prescription/Medication order/Order/Tree/Dispense directions/Dispense
    * amount/Duration of supply/null_flavour
    */
   @Path("/items[at0142]/null_flavour|defining_code")
   private NullFlavour durationOfSupplyNullFlavourDefiningCode;

   /**
    * Path: Prescription/Medication order/Order/Dispense directions/Dispense
    * amount/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   public void setAmountDescriptionValue(String amountDescriptionValue) {
      this.amountDescriptionValue = amountDescriptionValue;
   }

   public String getAmountDescriptionValue() {
      return this.amountDescriptionValue;
   }

   public void setAmountDescriptionNullFlavourDefiningCode(
         NullFlavour amountDescriptionNullFlavourDefiningCode) {
      this.amountDescriptionNullFlavourDefiningCode = amountDescriptionNullFlavourDefiningCode;
   }

   public NullFlavour getAmountDescriptionNullFlavourDefiningCode() {
      return this.amountDescriptionNullFlavourDefiningCode;
   }

   public void setAmountMagnitude(Double amountMagnitude) {
      this.amountMagnitude = amountMagnitude;
   }

   public Double getAmountMagnitude() {
      return this.amountMagnitude;
   }

   public void setAmountUnits(String amountUnits) {
      this.amountUnits = amountUnits;
   }

   public String getAmountUnits() {
      return this.amountUnits;
   }

   public void setAmountNullFlavourDefiningCode(NullFlavour amountNullFlavourDefiningCode) {
      this.amountNullFlavourDefiningCode = amountNullFlavourDefiningCode;
   }

   public NullFlavour getAmountNullFlavourDefiningCode() {
      return this.amountNullFlavourDefiningCode;
   }

   public void setUnitsValue(String unitsValue) {
      this.unitsValue = unitsValue;
   }

   public String getUnitsValue() {
      return this.unitsValue;
   }

   public void setUnitsNullFlavourDefiningCode(NullFlavour unitsNullFlavourDefiningCode) {
      this.unitsNullFlavourDefiningCode = unitsNullFlavourDefiningCode;
   }

   public NullFlavour getUnitsNullFlavourDefiningCode() {
      return this.unitsNullFlavourDefiningCode;
   }

   public void setDurationOfSupplyValue(TemporalAmount durationOfSupplyValue) {
      this.durationOfSupplyValue = durationOfSupplyValue;
   }

   public TemporalAmount getDurationOfSupplyValue() {
      return this.durationOfSupplyValue;
   }

   public void setDurationOfSupplyNullFlavourDefiningCode(
         NullFlavour durationOfSupplyNullFlavourDefiningCode) {
      this.durationOfSupplyNullFlavourDefiningCode = durationOfSupplyNullFlavourDefiningCode;
   }

   public NullFlavour getDurationOfSupplyNullFlavourDefiningCode() {
      return this.durationOfSupplyNullFlavourDefiningCode;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }
}
