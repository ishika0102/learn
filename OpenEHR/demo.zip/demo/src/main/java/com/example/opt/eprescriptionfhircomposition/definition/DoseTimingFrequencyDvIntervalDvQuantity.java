package com.example.opt.eprescriptionfhircomposition.definition;

import java.lang.Boolean;
import java.lang.Double;
import java.lang.String;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.843279590+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_INTERVAL<DV_QUANTITY>")
public class DoseTimingFrequencyDvIntervalDvQuantity implements RMEntity, DoseTimingFrequencyChoice {
   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Frequency/upper
    */
   @Path("/upper|magnitude")
   private Double upperMagnitude;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Frequency/upper
    */
   @Path("/upper|units")
   private String upperUnits;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Frequency/lower
    */
   @Path("/lower|magnitude")
   private Double lowerMagnitude;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Frequency/lower
    */
   @Path("/lower|units")
   private String lowerUnits;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Frequency/lower_included
    */
   @Path("/lower_included")
   private Boolean lowerIncluded;

   /**
    * Path: Prescription/Medication order/Order/Dose direction/Dose pattern/Dose
    * timing/Frequency/upper_included
    */
   @Path("/upper_included")
   private Boolean upperIncluded;

   public void setUpperMagnitude(Double upperMagnitude) {
      this.upperMagnitude = upperMagnitude;
   }

   public Double getUpperMagnitude() {
      return this.upperMagnitude;
   }

   public void setUpperUnits(String upperUnits) {
      this.upperUnits = upperUnits;
   }

   public String getUpperUnits() {
      return this.upperUnits;
   }

   public void setLowerMagnitude(Double lowerMagnitude) {
      this.lowerMagnitude = lowerMagnitude;
   }

   public Double getLowerMagnitude() {
      return this.lowerMagnitude;
   }

   public void setLowerUnits(String lowerUnits) {
      this.lowerUnits = lowerUnits;
   }

   public String getLowerUnits() {
      return this.lowerUnits;
   }

   public void setLowerIncluded(Boolean lowerIncluded) {
      this.lowerIncluded = lowerIncluded;
   }

   public Boolean isLowerIncluded() {
      return this.lowerIncluded;
   }

   public void setUpperIncluded(Boolean upperIncluded) {
      this.upperIncluded = upperIncluded;
   }

   public Boolean isUpperIncluded() {
      return this.upperIncluded;
   }
}
