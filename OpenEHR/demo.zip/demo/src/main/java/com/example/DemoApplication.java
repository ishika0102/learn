package com.example;

// import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.Language;
// import org.ehrbase.openehr.sdk.serialisation.jsonencoding.CanonicalJson;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// import com.example.opt.eprescriptionfhircomposition.EPrescriptionFHIRComposition;

@SpringBootApplication
public class DemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);

        // EPrescriptionFHIRComposition composition = new
        // EPrescriptionFHIRComposition();
        // composition.setLanguage(Language.EN);

        // CanonicalJson json = new CanonicalJson();
        // System.out.println(json.marshal(composition));
        // // System.out.println(actualFlat);
        // System.out.println(composition.getLanguage());
    }

}