package com.example.opt.eprescriptionfhircomposition.definition;

import javax.annotation.processing.Generated;

@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.849028408+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public interface MedicationOrderInfusionAdministrationRateChoice {
}
