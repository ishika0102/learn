package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import java.time.temporal.TemporalAmount;
import org.ehrbase.openehr.sdk.generator.commons.aql.containment.Containment;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.AqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.ListAqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.ListSelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.SelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

public class DirectionRepetitionClusterContainment extends Containment {
  public SelectAqlField<DirectionRepetitionCluster> DIRECTION_REPETITION_CLUSTER = new AqlFieldImp<DirectionRepetitionCluster>(
      DirectionRepetitionCluster.class, "", "DirectionRepetitionCluster", DirectionRepetitionCluster.class, this);

  public SelectAqlField<TemporalAmount> REPETITION_INTERVAL_VALUE = new AqlFieldImp<TemporalAmount>(
      DirectionRepetitionCluster.class, "/items[at0002]/value|value", "repetitionIntervalValue", TemporalAmount.class,
      this);

  public SelectAqlField<NullFlavour> REPETITION_INTERVAL_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      DirectionRepetitionCluster.class, "/items[at0002]/null_flavour|defining_code",
      "repetitionIntervalNullFlavourDefiningCode", NullFlavour.class, this);

  public ListSelectAqlField<DirectionRepetitionSpecificDateElement> SPECIFIC_DATE = new ListAqlFieldImp<DirectionRepetitionSpecificDateElement>(
      DirectionRepetitionCluster.class, "/items[at0001]", "specificDate", DirectionRepetitionSpecificDateElement.class,
      this);

  public ListSelectAqlField<DirectionRepetitionSpecificDayOfWeekElement> SPECIFIC_DAY_OF_WEEK = new ListAqlFieldImp<DirectionRepetitionSpecificDayOfWeekElement>(
      DirectionRepetitionCluster.class, "/items[at0003]", "specificDayOfWeek",
      DirectionRepetitionSpecificDayOfWeekElement.class, this);

  public ListSelectAqlField<DirectionRepetitionSpecificDayOfMonthElement> SPECIFIC_DAY_OF_MONTH = new ListAqlFieldImp<DirectionRepetitionSpecificDayOfMonthElement>(
      DirectionRepetitionCluster.class, "/items[at0004]", "specificDayOfMonth",
      DirectionRepetitionSpecificDayOfMonthElement.class, this);

  public ListSelectAqlField<DirectionRepetitionSpecificEventCluster> SPECIFIC_EVENT = new ListAqlFieldImp<DirectionRepetitionSpecificEventCluster>(
      DirectionRepetitionCluster.class, "/items[at0006]", "specificEvent",
      DirectionRepetitionSpecificEventCluster.class, this);

  public SelectAqlField<FeederAudit> FEEDER_AUDIT = new AqlFieldImp<FeederAudit>(DirectionRepetitionCluster.class,
      "/feeder_audit", "feederAudit", FeederAudit.class, this);

  private DirectionRepetitionClusterContainment() {
    super("openEHR-EHR-CLUSTER.timing_repetition.v0");
  }

  public static DirectionRepetitionClusterContainment getInstance() {
    return new DirectionRepetitionClusterContainment();
  }
}
