package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import java.lang.Long;
import java.time.temporal.TemporalAccessor;
import org.ehrbase.openehr.sdk.generator.commons.aql.containment.Containment;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.AqlFieldImp;
import org.ehrbase.openehr.sdk.generator.commons.aql.field.SelectAqlField;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

public class AuthorisationDetailsClusterContainment extends Containment {
  public SelectAqlField<AuthorisationDetailsCluster> AUTHORISATION_DETAILS_CLUSTER = new AqlFieldImp<AuthorisationDetailsCluster>(
      AuthorisationDetailsCluster.class, "", "AuthorisationDetailsCluster", AuthorisationDetailsCluster.class, this);

  public SelectAqlField<Long> NUMBEROFREPEATSALLOWED_MAGNITUDE = new AqlFieldImp<Long>(
      AuthorisationDetailsCluster.class, "/items[at0025]/value|magnitude", "numberofrepeatsallowedMagnitude",
      Long.class, this);

  public SelectAqlField<NullFlavour> NUMBEROFREPEATSALLOWED_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      AuthorisationDetailsCluster.class, "/items[at0025]/null_flavour|defining_code",
      "numberofrepeatsallowedNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<TemporalAccessor> VALIDITYPERIOD_VALUE = new AqlFieldImp<TemporalAccessor>(
      AuthorisationDetailsCluster.class, "/items[at0072]/value|value", "validityperiodValue", TemporalAccessor.class,
      this);

  public SelectAqlField<NullFlavour> VALIDITYPERIOD_NULL_FLAVOUR_DEFINING_CODE = new AqlFieldImp<NullFlavour>(
      AuthorisationDetailsCluster.class, "/items[at0072]/null_flavour|defining_code",
      "validityperiodNullFlavourDefiningCode", NullFlavour.class, this);

  public SelectAqlField<FeederAudit> FEEDER_AUDIT = new AqlFieldImp<FeederAudit>(AuthorisationDetailsCluster.class,
      "/feeder_audit", "feederAudit", FeederAudit.class, this);

  private AuthorisationDetailsClusterContainment() {
    super("openEHR-EHR-CLUSTER.medication_authorisation.v0");
  }

  public static AuthorisationDetailsClusterContainment getInstance() {
    return new AuthorisationDetailsClusterContainment();
  }
}
