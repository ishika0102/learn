package com.example.opt.eprescriptionfhircomposition.definition;

import java.lang.String;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.EnumValueSet;

public enum RoleDefiningCode implements EnumValueSet {
   DILUENT("Diluent", "Inert diluent.", "local", "at0084"),

   PRESERVATIVE("Preservative", "The ingredient is present to prolong the life of the substance.", "local", "at0086"),

   PROPELLENT("Propellent", "Inert propellent.", "local", "at0085"),

   COLOURING("Colouring", "The ingredient is used to colour the substance.", "local", "at0087"),

   ADJUVANT("Adjuvant", "The chemical is active but aids the therapeutic effect of another ingredient.", "local",
         "at0083"),

   THERAPEUTIC("Therapeutic", "The chemical has a known and desired effect which is positive.", "local", "at0080"),

   TOXIC("Toxic", "This chemical is toxic and has no therapeutic effect.", "local", "at0082"),

   INGREDIENT("Ingredient", "Details of an ingredient used to make up a mixed preparation or infuson.", "local",
         "at0074"),

   ELECTROLYTE("Electrolyte", "This ingredient is an electrolyte.", "local", "at0081");

   private String value;

   private String description;

   private String terminologyId;

   private String code;

   RoleDefiningCode(String value, String description, String terminologyId, String code) {
      this.value = value;
      this.description = description;
      this.terminologyId = terminologyId;
      this.code = code;
   }

   public String getValue() {
      return this.value;
   }

   public String getDescription() {
      return this.description;
   }

   public String getTerminologyId() {
      return this.terminologyId;
   }

   public String getCode() {
      return this.code;
   }
}
