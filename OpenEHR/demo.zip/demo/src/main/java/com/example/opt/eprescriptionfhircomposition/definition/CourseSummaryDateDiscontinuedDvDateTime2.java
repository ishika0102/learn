package com.example.opt.eprescriptionfhircomposition.definition;

import java.time.temporal.TemporalAccessor;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.OptionFor;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.RMEntity;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.899188374+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
@OptionFor("DV_DATE_TIME")
public class CourseSummaryDateDiscontinuedDvDateTime2 implements RMEntity, CourseSummaryDateDiscontinuedChoice {
   /**
    * Path: Prescription/Medication order/Order/Order details/Course summary/Date
    * discontinued/Date discontinued
    * Description: Key medication event dates.
    */
   @Path("|value")
   private TemporalAccessor dateDiscontinuedValue;

   public void setDateDiscontinuedValue(TemporalAccessor dateDiscontinuedValue) {
      this.dateDiscontinuedValue = dateDiscontinuedValue;
   }

   public TemporalAccessor getDateDiscontinuedValue() {
      return this.dateDiscontinuedValue;
   }
}
