package com.example.opt.eprescriptionfhircomposition.definition;

import com.nedap.archie.rm.archetyped.FeederAudit;
import java.lang.String;
import javax.annotation.processing.Generated;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Entity;
import org.ehrbase.openehr.sdk.generator.commons.annotations.Path;
import org.ehrbase.openehr.sdk.generator.commons.interfaces.LocatableEntity;
import org.ehrbase.openehr.sdk.generator.commons.shareddefinition.NullFlavour;

@Entity
@Generated(value = "org.ehrbase.openehr.sdk.generator.ClassGenerator", date = "2024-07-04T14:33:43.811357558+05:30", comments = "https://github.com/ehrbase/openEHR_SDK Version: 2.14.0-SNAPSHOT")
public class PreparationFormElement implements LocatableEntity {
   /**
    * Path: Prescription/Medication order/Order/Preparation/Form
    * Description: The formulation or presentation of the medication.
    * Comment: e.g. 'Tablet', 'Capsule', 'Liquid'.
    */
   @Path("/value|value")
   private String value;

   /**
    * Path: Prescription/Medication order/Order/Tree/Preparation/Form/null_flavour
    */
   @Path("/null_flavour|defining_code")
   private NullFlavour value2;

   /**
    * Path: Prescription/Medication order/Order/Preparation/feeder_audit
    */
   @Path("/feeder_audit")
   private FeederAudit feederAudit;

   public void setValue(String value) {
      this.value = value;
   }

   public String getValue() {
      return this.value;
   }

   public void setValue2(NullFlavour value2) {
      this.value2 = value2;
   }

   public NullFlavour getValue2() {
      return this.value2;
   }

   public void setFeederAudit(FeederAudit feederAudit) {
      this.feederAudit = feederAudit;
   }

   public FeederAudit getFeederAudit() {
      return this.feederAudit;
   }
}
